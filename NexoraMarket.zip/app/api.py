"""API REST. Cada ruta declara el permiso que exige.

Formato de ruta: (metodo, patron, permiso, funcion)
El patron admite comodines: /api/productos/{id}
La funcion recibe (ctx) con: usuario, params, query, body.
"""
from __future__ import annotations

from . import audit, db, security
from .db import ErrorNegocio
from .services import (backup, caja, compras, config, facturacion, precios,
                       productos, proveedores, reportes, stock, ventas)


class Ctx:
    def __init__(self, usuario, params, query, body):
        self.usuario = usuario
        self.params = params
        self.query = query
        self.body = body or {}

    def req(self, campo):
        if campo not in self.body or self.body[campo] in ("", None):
            raise ErrorNegocio(f"Falta el dato obligatorio: {campo}")
        return self.body[campo]

    def qint(self, campo, default=None):
        v = self.query.get(campo)
        return int(v) if v not in (None, "") else default


# ------------------------------ handlers ------------------------------
def h_login(c):
    return security.login(c.req("usuario"), c.req("password"))


def h_logout(c):
    security.logout(c.body.get("token") or "")
    return {"ok": True}


def h_me(c):
    if not c.usuario:
        raise ErrorNegocio("Sesion no iniciada", 401)
    return c.usuario


def h_config_get(c):
    return {"valores": config.obtener_todo(), "descripciones": config.descripciones()}


def h_config_put(c):
    return {"valores": config.guardar(c.body, c.usuario)}


def h_productos(c):
    return {"productos": productos.listar(
        texto=c.query.get("q", ""), categoria_id=c.qint("categoria_id"),
        proveedor_id=c.qint("proveedor_id"), estado=c.query.get("estado", "activos"),
        orden=c.query.get("orden", "nombre"), limite=c.qint("limite", 300))}


def h_producto_codigo(c):
    p = productos.buscar_por_codigo(c.query.get("codigo", ""))
    if not p:
        raise ErrorNegocio("No se encontro un producto con ese codigo", 404)
    return p


def h_producto_get(c):
    p = productos.obtener(int(c.params["id"]))
    p["compras"] = compras.historial_producto(p["id"], 20)
    p["precios"] = precios.historial(p["id"], limite=30)
    p["movimientos"] = stock.movimientos(p["id"], limite=30)
    return p


def h_producto_post(c):
    return productos.crear(c.body, c.usuario)


def h_producto_put(c):
    return productos.actualizar(int(c.params["id"]), c.body, c.usuario)


def h_producto_delete(c):
    return productos.desactivar(int(c.params["id"]), c.usuario)


def h_producto_imagen(c):
    return productos.guardar_imagen(int(c.params["id"]), c.body.get("imagen"),
                                    c.usuario)


def h_producto_imagen_auto(c):
    return productos.buscar_imagen_internet(int(c.params["id"]), c.usuario)


def h_ingreso_rapido(c):
    return productos.ingreso_rapido(
        c.req("codigo"), float(c.req("cantidad")), c.body.get("costo"),
        c.body.get("precio"), c.body.get("datos_nuevo"), c.body.get("proveedor_id"),
        c.usuario)


def h_categorias(c):
    return {"categorias": productos.categorias(),
            "subcategorias": productos.subcategorias(),
            "marcas": productos.marcas(), "unidades": productos.unidades()}


def h_categoria_post(c):
    return productos.crear_categoria(c.req("nombre"), c.body.get("margen"), c.usuario)


def h_categoria_put(c):
    return productos.actualizar_categoria(int(c.params["id"]), c.body.get("nombre"),
                                          c.body.get("margen"), c.usuario)


def h_subcategoria_post(c):
    return productos.crear_subcategoria(int(c.req("categoria_id")), c.req("nombre"),
                                        c.usuario)


def h_marca_post(c):
    return productos.crear_marca(c.req("nombre"), c.body.get("margen"), c.usuario)


def h_proveedores(c):
    return {"proveedores": proveedores.listar(
        c.query.get("q", ""), c.query.get("inactivos") == "1")}


def h_proveedor_get(c):
    return proveedores.obtener(int(c.params["id"]))


def h_proveedor_post(c):
    return proveedores.guardar(c.body, usuario=c.usuario)


def h_proveedor_put(c):
    return proveedores.guardar(c.body, int(c.params["id"]), c.usuario)


def h_compras(c):
    return {"compras": compras.listar(c.query.get("desde"), c.query.get("hasta"),
                                      c.qint("proveedor_id"), c.qint("limite", 200))}


def h_compra_get(c):
    return compras.obtener(int(c.params["id"]))


def h_compra_post(c):
    return compras.registrar(c.body, c.usuario)


def h_ventas(c):
    return {"ventas": ventas.listar(c.query.get("desde"), c.query.get("hasta"),
                                    c.qint("limite", 200))}


def h_venta_get(c):
    return ventas.obtener(int(c.params["id"]))


def h_venta_post(c):
    venta = ventas.registrar(c.body, c.usuario)
    if c.body.get("facturar") or config.obtener_bool("factura.impresora_auto", False):
        try:
            venta["comprobante"] = facturacion.emitir(
                venta["id"], c.body.get("tipo_comprobante"), c.usuario)
        except ErrorNegocio as e:
            venta["aviso_facturacion"] = e.mensaje
    return venta


def h_venta_anular(c):
    return ventas.anular(int(c.params["id"]), c.body.get("motivo", ""), c.usuario)


def h_formas_pago(c):
    return {"formas_pago": ventas.formas_pago(activas=c.query.get("todas") != "1")}


def h_forma_pago_post(c):
    return ventas.guardar_forma_pago(c.req("nombre"), c.body.get("recargo", 0),
                                     c.body.get("id"), c.body.get("activo", True),
                                     c.usuario)


def h_stock_ajuste(c):
    return stock.ajustar(int(c.req("producto_id")), c.body.get("cantidad_final"),
                         c.body.get("delta"), c.body.get("motivo", ""), c.usuario)


def h_stock_devolucion(c):
    return stock.devolucion(int(c.req("producto_id")), float(c.req("cantidad")),
                            c.body.get("motivo", ""), c.usuario)


def h_movimientos(c):
    return {"movimientos": stock.movimientos(
        c.qint("producto_id"), c.query.get("desde"), c.query.get("hasta"),
        c.query.get("tipo"), c.qint("limite", 500))}


def h_precios_preview(c):
    return precios.previsualizar(
        c.req("porcentaje"), c.body.get("aplicar_a", "ambos"),
        c.body.get("alcance", "todos"), ids=c.body.get("ids"),
        categoria_id=c.body.get("categoria_id"),
        proveedor_id=c.body.get("proveedor_id"), marca_id=c.body.get("marca_id"))


def h_precios_aplicar(c):
    return precios.aplicar(
        c.req("porcentaje"), c.body.get("aplicar_a", "ambos"),
        c.body.get("alcance", "todos"), c.body.get("motivo", ""), c.usuario,
        ids=c.body.get("ids"), categoria_id=c.body.get("categoria_id"),
        proveedor_id=c.body.get("proveedor_id"), marca_id=c.body.get("marca_id"))


def h_precios_recalcular(c):
    return precios.recalcular_precios_por_margen(
        c.body.get("alcance", "todos"), c.usuario, ids=c.body.get("ids"),
        categoria_id=c.body.get("categoria_id"),
        proveedor_id=c.body.get("proveedor_id"), marca_id=c.body.get("marca_id"))


def h_precios_historial(c):
    return {"historial": precios.historial(c.qint("producto_id"),
                                           c.query.get("lote_id"),
                                           c.qint("limite", 200))}


def h_dashboard(c):
    return reportes.dashboard()


def h_alertas(c):
    return {"alertas": stock.alertas()}


def h_margenes(c):
    return {"categorias": reportes.margen_por_categoria(c.query.get("desde"),
                                                        c.query.get("hasta"))}


def h_caja(c):
    return caja.estado()


def h_caja_abrir(c):
    return caja.abrir(c.body.get("monto_inicial", 0), c.usuario)


def h_caja_cerrar(c):
    return caja.cerrar(c.body.get("monto_contado", 0),
                       c.body.get("observaciones", ""), c.usuario)


def h_caja_historial(c):
    return {"cajas": caja.historial(c.qint("limite", 30))}


def h_resumen(c):
    d, h = reportes.rango(c.query.get("periodo", "mes"), c.query.get("desde"),
                          c.query.get("hasta"))
    return {"ventas": ventas.resumen(d, h), "inventario": stock.resumen_inventario(),
            "desde": d, "hasta": h}


def h_auditoria(c):
    return {"auditoria": audit.listar(c.qint("limite", 200), c.query.get("entidad"),
                                      c.query.get("desde"), c.query.get("hasta"))}


def h_backup_crear(c):
    return backup.crear(c.body.get("motivo", "manual"), c.usuario)


def h_backup_listar(c):
    return {"backups": backup.listar(), "directorio": str(backup.directorio())}


def h_backup_restaurar(c):
    return backup.restaurar(c.req("nombre"), c.usuario)


def h_usuarios(c):
    filas = db.q("SELECT u.id, u.usuario, u.nombre, u.activo, u.creado,"
                 " u.ultimo_acceso, r.nombre AS rol FROM usuarios u"
                 " JOIN roles r ON r.id = u.rol_id ORDER BY u.usuario")
    roles = db.filas_dict(db.q("SELECT * FROM roles ORDER BY id"))
    for r in roles:
        r["permisos"] = [f["permiso_codigo"] for f in db.q(
            "SELECT permiso_codigo FROM rol_permiso WHERE rol_id = ?", (r["id"],))]
    return {"usuarios": db.filas_dict(filas), "roles": roles,
            "permisos": security.PERMISOS}


def h_usuario_post(c):
    uid = security.crear_usuario(c.req("usuario"), c.body.get("nombre", ""),
                                 c.req("password"), c.req("rol"),
                                 c.body.get("activo", True))
    audit.registrar(c.usuario, "usuario.crear", "usuario", uid, c.body["usuario"])
    return {"id": uid}


def h_usuario_put(c):
    uid = int(c.params["id"])
    with db.transaccion() as con:
        if c.body.get("nombre"):
            con.execute("UPDATE usuarios SET nombre = ? WHERE id = ?",
                        (c.body["nombre"], uid))
        if "activo" in c.body:
            con.execute("UPDATE usuarios SET activo = ? WHERE id = ?",
                        (1 if c.body["activo"] else 0, uid))
        if c.body.get("rol"):
            fila = con.execute("SELECT id FROM roles WHERE nombre = ?",
                               (c.body["rol"],)).fetchone()
            if not fila:
                raise ErrorNegocio("Rol inexistente", 404)
            con.execute("UPDATE usuarios SET rol_id = ? WHERE id = ?", (fila["id"], uid))
        audit.registrar(c.usuario, "usuario.editar", "usuario", uid,
                        str(c.body), con=con)
    if c.body.get("password"):
        security.cambiar_password(uid, c.body["password"])
    return {"ok": True}


def h_rol_permisos(c):
    rol_id = int(c.params["id"])
    permisos = c.body.get("permisos") or []
    desconocidos = [p for p in permisos if p not in security.PERMISOS]
    if desconocidos:
        raise ErrorNegocio(f"Permisos desconocidos: {', '.join(desconocidos)}")
    with db.transaccion() as con:
        con.execute("DELETE FROM rol_permiso WHERE rol_id = ?", (rol_id,))
        for p in permisos:
            con.execute("INSERT INTO rol_permiso (rol_id, permiso_codigo) VALUES (?,?)",
                        (rol_id, p))
        audit.registrar(c.usuario, "rol.permisos", "rol", rol_id,
                        ", ".join(permisos), con=con)
    return {"ok": True}


def h_facturacion_info(c):
    return {"adaptadores": facturacion.listar_adaptadores(),
            "activo": config.obtener("factura.adaptador"),
            "prueba": facturacion.probar_configuracion()}


def h_facturacion_emitir(c):
    return facturacion.emitir(int(c.req("venta_id")), c.body.get("tipo"), c.usuario)


def h_ticket(c):
    return {"texto": facturacion.ticket_texto(int(c.params["id"]))}


# ------------------------------ rutas ---------------------------------
RUTAS = [
    ("POST", "/api/login", None, h_login),
    ("POST", "/api/logout", None, h_logout),
    ("GET", "/api/me", None, h_me),

    ("GET", "/api/config", None, h_config_get),
    ("PUT", "/api/config", "config.editar", h_config_put),

    ("GET", "/api/productos", "producto.ver", h_productos),
    ("GET", "/api/productos/codigo", "producto.ver", h_producto_codigo),
    ("POST", "/api/productos", "producto.editar", h_producto_post),
    ("POST", "/api/productos/ingreso-rapido", "compra.crear", h_ingreso_rapido),
    ("GET", "/api/productos/{id}", "producto.ver", h_producto_get),
    ("PUT", "/api/productos/{id}", "producto.editar", h_producto_put),
    ("DELETE", "/api/productos/{id}", "producto.editar", h_producto_delete),
    ("PUT", "/api/productos/{id}/imagen", "producto.editar", h_producto_imagen),
    ("POST", "/api/productos/{id}/imagen-auto", "producto.editar", h_producto_imagen_auto),

    ("GET", "/api/catalogos", "producto.ver", h_categorias),
    ("POST", "/api/categorias", "producto.editar", h_categoria_post),
    ("PUT", "/api/categorias/{id}", "producto.editar", h_categoria_put),
    ("POST", "/api/subcategorias", "producto.editar", h_subcategoria_post),
    ("POST", "/api/marcas", "producto.editar", h_marca_post),

    ("GET", "/api/proveedores", "producto.ver", h_proveedores),
    ("GET", "/api/proveedores/{id}", "producto.ver", h_proveedor_get),
    ("POST", "/api/proveedores", "proveedor.editar", h_proveedor_post),
    ("PUT", "/api/proveedores/{id}", "proveedor.editar", h_proveedor_put),

    ("GET", "/api/compras", "reporte.ver", h_compras),
    ("GET", "/api/compras/{id}", "reporte.ver", h_compra_get),
    ("POST", "/api/compras", "compra.crear", h_compra_post),

    ("GET", "/api/ventas", "reporte.ver", h_ventas),
    ("POST", "/api/ventas", "venta.crear", h_venta_post),
    ("GET", "/api/ventas/{id}", "producto.ver", h_venta_get),
    ("GET", "/api/ventas/{id}/ticket", "producto.ver", h_ticket),
    ("POST", "/api/ventas/{id}/anular", "venta.anular", h_venta_anular),
    ("GET", "/api/formas-pago", None, h_formas_pago),
    ("POST", "/api/formas-pago", "config.editar", h_forma_pago_post),

    ("POST", "/api/stock/ajuste", "stock.ajustar", h_stock_ajuste),
    ("POST", "/api/stock/devolucion", "stock.ajustar", h_stock_devolucion),
    ("GET", "/api/stock/movimientos", "producto.ver", h_movimientos),

    ("POST", "/api/precios/preview", "precio.editar", h_precios_preview),
    ("POST", "/api/precios/aplicar", "precio.editar", h_precios_aplicar),
    ("POST", "/api/precios/recalcular", "precio.editar", h_precios_recalcular),
    ("GET", "/api/precios/historial", "producto.ver", h_precios_historial),

    ("GET", "/api/dashboard", "producto.ver", h_dashboard),
    ("GET", "/api/alertas", "producto.ver", h_alertas),
    ("GET", "/api/caja", "caja.gestion", h_caja),
    ("POST", "/api/caja/abrir", "caja.gestion", h_caja_abrir),
    ("POST", "/api/caja/cerrar", "caja.gestion", h_caja_cerrar),
    ("GET", "/api/caja/historial", "caja.gestion", h_caja_historial),
    ("GET", "/api/reportes/margenes", "reporte.ver", h_margenes),
    ("GET", "/api/reportes/resumen", "reporte.ver", h_resumen),
    ("GET", "/api/auditoria", "auditoria.ver", h_auditoria),

    ("GET", "/api/backups", "backup.ejecutar", h_backup_listar),
    ("POST", "/api/backups", "backup.ejecutar", h_backup_crear),
    ("POST", "/api/backups/restaurar", "backup.ejecutar", h_backup_restaurar),

    ("GET", "/api/usuarios", "usuario.editar", h_usuarios),
    ("POST", "/api/usuarios", "usuario.editar", h_usuario_post),
    ("PUT", "/api/usuarios/{id}", "usuario.editar", h_usuario_put),
    ("PUT", "/api/roles/{id}/permisos", "usuario.editar", h_rol_permisos),

    ("GET", "/api/facturacion", "producto.ver", h_facturacion_info),
    ("POST", "/api/facturacion/emitir", "venta.crear", h_facturacion_emitir),
]


def resolver(metodo: str, ruta: str):
    """Devuelve (permiso, handler, params) o (None, None, None)."""
    partes = [p for p in ruta.split("/") if p != ""]
    candidatos = []
    for m, patron, permiso, fn in RUTAS:
        if m != metodo:
            continue
        pp = [p for p in patron.split("/") if p != ""]
        if len(pp) != len(partes):
            continue
        params, ok, comodines = {}, True, 0
        for esperado, real in zip(pp, partes):
            if esperado.startswith("{") and esperado.endswith("}"):
                params[esperado[1:-1]] = real
                comodines += 1
            elif esperado != real:
                ok = False
                break
        if ok:
            candidatos.append((comodines, permiso, fn, params))
    if not candidatos:
        return None, None, None
    candidatos.sort(key=lambda x: x[0])   # rutas literales antes que comodines
    _, permiso, fn, params = candidatos[0]
    return permiso, fn, params
