"""Proveedores y su historial de compras."""
from __future__ import annotations

from .. import audit, db
from ..db import ErrorNegocio, a_pesos


def listar(texto: str = "", incluir_inactivos: bool = False) -> list[dict]:
    sql = "SELECT * FROM proveedores WHERE 1=1"
    par: list = []
    if not incluir_inactivos:
        sql += " AND activo = 1"
    if texto:
        sql += " AND (nombre LIKE ? OR cuit LIKE ? OR email LIKE ?)"
        par.extend([f"%{texto}%"] * 3)
    return db.filas_dict(db.q(sql + " ORDER BY nombre", par))


def obtener(proveedor_id: int) -> dict:
    fila = db.q1("SELECT * FROM proveedores WHERE id = ?", (proveedor_id,))
    if not fila:
        raise ErrorNegocio("El proveedor no existe", 404)
    p = dict(fila)
    p["productos"] = db.filas_dict(db.q(
        "SELECT id, nombre, codigo_barras, stock, costo, precio FROM productos"
        " WHERE proveedor_id = ? AND activo = 1 ORDER BY nombre", (proveedor_id,)))
    for prod in p["productos"]:
        prod["costo_pesos"] = a_pesos(prod["costo"])
        prod["precio_pesos"] = a_pesos(prod["precio"])
    compras = db.filas_dict(db.q(
        "SELECT id, fecha, comprobante, total FROM compras WHERE proveedor_id = ?"
        " ORDER BY id DESC LIMIT 50", (proveedor_id,)))
    for c in compras:
        c["total_pesos"] = a_pesos(c["total"])
    p["compras"] = compras
    p["ultimos_precios"] = db.filas_dict(db.q(
        "SELECT p.nombre, ci.costo_unit, MAX(c.fecha) AS fecha FROM compra_items ci"
        " JOIN compras c ON c.id = ci.compra_id JOIN productos p ON p.id = ci.producto_id"
        " WHERE c.proveedor_id = ? GROUP BY ci.producto_id ORDER BY p.nombre",
        (proveedor_id,)))
    for u in p["ultimos_precios"]:
        u["costo_unit_pesos"] = a_pesos(u["costo_unit"])
    return p


def guardar(datos: dict, proveedor_id: int = None, usuario=None) -> dict:
    nombre = (datos.get("nombre") or "").strip()
    if not nombre:
        raise ErrorNegocio("El nombre del proveedor es obligatorio")
    campos = ("nombre", "cuit", "telefono", "email", "direccion", "notas")
    valores = [datos.get(c) for c in campos]
    with db.transaccion() as con:
        if proveedor_id:
            anterior = db.fila_dict(db.q1("SELECT * FROM proveedores WHERE id = ?",
                                          (proveedor_id,)))
            con.execute(
                "UPDATE proveedores SET nombre=?, cuit=?, telefono=?, email=?,"
                " direccion=?, notas=?, activo=? WHERE id = ?",
                valores + [1 if datos.get("activo", True) else 0, proveedor_id])
            audit.registrar(usuario, "proveedor.editar", "proveedor", proveedor_id,
                            nombre, anterior, datos, con=con)
        else:
            if db.q1("SELECT id FROM proveedores WHERE nombre = ?", (nombre,)):
                raise ErrorNegocio("Ya existe un proveedor con ese nombre", 409)
            cur = con.execute(
                "INSERT INTO proveedores (nombre, cuit, telefono, email, direccion,"
                " notas) VALUES (?,?,?,?,?,?)", valores)
            proveedor_id = cur.lastrowid
            audit.registrar(usuario, "proveedor.crear", "proveedor", proveedor_id,
                            nombre, None, datos, con=con)
    return obtener(proveedor_id)
