"""Apertura y cierre de caja: control del efectivo del dia.

Cada venta registrada mientras hay una caja abierta queda asociada a esa
caja (`ventas.caja_id`). Al cerrar se compara lo que deberia haber
(== fondo inicial + ventas en efectivo del turno) con lo que el dueno conto
fisicamente, y se guarda la diferencia.
"""
from __future__ import annotations

from .. import audit, db
from ..db import ErrorNegocio, a_centavos, a_pesos

CAMPOS_PESOS = ("monto_inicial", "ventas_total", "monto_esperado",
                "monto_contado", "diferencia")


def abierta_actual(con=None) -> dict | None:
    sql = "SELECT * FROM cajas WHERE estado = 'abierta' ORDER BY id DESC LIMIT 1"
    fila = con.execute(sql).fetchone() if con is not None else db.q1(sql)
    return dict(fila) if fila else None


def resumen_turno(caja_id: int, con=None) -> dict:
    con = con or db.conexion()
    f = con.execute(
        "SELECT COUNT(*) AS cantidad, COALESCE(SUM(total),0) AS total,"
        " COALESCE(SUM(costo_total),0) AS costo FROM ventas"
        " WHERE caja_id = ? AND estado = 'confirmada'", (caja_id,)).fetchone()
    return {"cantidad": f["cantidad"], "total": int(f["total"] or 0),
            "costo": int(f["costo"] or 0)}


def estado() -> dict:
    """Estado actual: si hay caja abierta, que vendio hasta ahora y esperado."""
    caja = abierta_actual()
    if not caja:
        return {"abierta": False, "caja": None, "ventas": None}
    ventas = resumen_turno(caja["id"])
    caja["ventas_total"] = ventas["total"]
    caja = _a_pesos(caja)
    return {"abierta": True, "caja": caja, "ventas": ventas}


def abrir(monto_inicial=0, usuario: dict | None = None) -> dict:
    if abierta_actual():
        raise ErrorNegocio("Ya hay una caja abierta. Cerrala antes de abrir otra.")
    monto = a_centavos(monto_inicial)
    if monto < 0:
        raise ErrorNegocio("El monto inicial no puede ser negativo")
    with db.transaccion() as con:
        cur = con.execute(
            "INSERT INTO cajas (estado, monto_inicial, usuario_abre_id)"
            " VALUES ('abierta', ?, ?)", (monto, (usuario or {}).get("id")))
        audit.registrar(usuario, "caja.abrir", "caja", cur.lastrowid,
                        f"Fondo inicial {a_pesos(monto)}", con=con)
    return estado()


def cerrar(monto_contado=0, observaciones: str = "", usuario: dict | None = None) -> dict:
    caja = abierta_actual()
    if not caja:
        raise ErrorNegocio("No hay ninguna caja abierta")
    contado = a_centavos(monto_contado)
    if contado < 0:
        raise ErrorNegocio("El monto contado no puede ser negativo")
    res = resumen_turno(caja["id"])
    esperado = caja["monto_inicial"] + res["total"]
    diferencia = contado - esperado
    with db.transaccion() as con:
        con.execute(
            "UPDATE cajas SET estado = 'cerrada',"
            " cerrada_en = datetime('now','localtime'),"
            " ventas_total = ?, monto_esperado = ?, monto_contado = ?,"
            " diferencia = ?, usuario_cierra_id = ?, observaciones = ?"
            " WHERE id = ?",
            (res["total"], esperado, contado, diferencia,
             (usuario or {}).get("id"), observaciones, caja["id"]))
        audit.registrar(
            usuario, "caja.cerrar", "caja", caja["id"],
            f"Esperado {a_pesos(esperado)} - contado {a_pesos(contado)}"
            f" - diferencia {a_pesos(diferencia)}",
            con=con)
    return cerrar_resumen(caja["id"])


def cerrar_resumen(caja_id: int) -> dict:
    f = db.q1(
        "SELECT c.*, ua.usuario AS abre, uc.usuario AS cierra FROM cajas c"
        " JOIN usuarios ua ON ua.id = c.usuario_abre_id"
        " LEFT JOIN usuarios uc ON uc.id = c.usuario_cierra_id"
        " WHERE c.id = ?", (caja_id,))
    return _a_pesos(dict(f))


def historial(limite: int = 30) -> list[dict]:
    filas = db.q(
        "SELECT c.*, ua.usuario AS abre, uc.usuario AS cierra FROM cajas c"
        " LEFT JOIN usuarios ua ON ua.id = c.usuario_abre_id"
        " LEFT JOIN usuarios uc ON uc.id = c.usuario_cierra_id"
        " ORDER BY c.id DESC LIMIT ?", (int(limite),))
    res = []
    for f in filas:
        c = dict(f)
        if c["estado"] == "abierta":
            v = resumen_turno(c["id"])
            c["ventas_total"] = v["total"]
            c["monto_esperado"] = c["monto_inicial"] + v["total"]
        res.append(_a_pesos(c))
    return res


def _a_pesos(c: dict) -> dict:
    for campo in CAMPOS_PESOS:
        c[campo + "_pesos"] = a_pesos(c.get(campo) or 0)
    return c