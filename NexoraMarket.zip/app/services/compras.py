"""Compras a proveedores. Una compra siempre: suma stock, deja movimiento,
actualiza el ultimo costo y (si corresponde) recalcula el precio de venta.
Todo dentro de una sola transaccion."""
from __future__ import annotations

from .. import audit, db
from ..db import ErrorNegocio, a_centavos, a_pesos
from . import precios, stock


def registrar(datos: dict, usuario: dict | None = None) -> dict:
    items = datos.get("items") or []
    if not items:
        raise ErrorNegocio("La compra no tiene productos")

    proveedor_id = datos.get("proveedor_id") or None
    if proveedor_id and not db.q1("SELECT id FROM proveedores WHERE id = ?",
                                  (proveedor_id,)):
        raise ErrorNegocio("El proveedor no existe", 404)

    with db.transaccion() as con:
        cur = con.execute(
            "INSERT INTO compras (proveedor_id, comprobante, total, usuario_id, notas)"
            " VALUES (?,?,0,?,?)",
            (proveedor_id, datos.get("comprobante"), (usuario or {}).get("id"),
             datos.get("notas")))
        compra_id = cur.lastrowid
        total = 0

        for it in items:
            pid = it.get("producto_id")
            if not pid and it.get("codigo"):
                fila = con.execute(
                    "SELECT id FROM productos WHERE codigo_barras = ? OR codigo_qr = ?",
                    (it["codigo"], it["codigo"])).fetchone()
                if not fila:
                    raise ErrorNegocio(f"No existe un producto con codigo {it['codigo']}",
                                       404)
                pid = fila["id"]
            producto = con.execute("SELECT * FROM productos WHERE id = ?",
                                   (pid,)).fetchone()
            if not producto:
                raise ErrorNegocio("Producto inexistente en la compra", 404)
            producto = dict(producto)

            cantidad = float(it.get("cantidad") or 0)
            if cantidad <= 0:
                raise ErrorNegocio(
                    f"Cantidad invalida para '{producto['nombre']}'")
            costo_unit = (a_centavos(it["costo_unit"])
                          if it.get("costo_unit") not in (None, "")
                          else producto["costo"])
            subtotal = int(round(cantidad * costo_unit))
            total += subtotal

            con.execute(
                "INSERT INTO compra_items (compra_id, producto_id, cantidad,"
                " costo_unit, subtotal) VALUES (?,?,?,?,?)",
                (compra_id, pid, cantidad, costo_unit, subtotal))
            stock.mover(con, pid, "compra", cantidad, f"COMPRA:{compra_id}",
                        "Ingreso por compra", usuario)

            # costo / precio de venta
            precio_manual = it.get("precio_venta")
            if costo_unit != producto["costo"] or precio_manual not in (None, ""):
                precios.set_precio_manual(
                    pid, costo=a_pesos(costo_unit),
                    precio=precio_manual if precio_manual not in (None, "") else None,
                    usuario=usuario, motivo=f"Compra #{compra_id}", con=con)
            if producto["proveedor_id"] is None and proveedor_id:
                con.execute("UPDATE productos SET proveedor_id = ? WHERE id = ?",
                            (proveedor_id, pid))

        con.execute("UPDATE compras SET total = ? WHERE id = ?", (total, compra_id))
        audit.registrar(usuario, "compra.registrar", "compra", compra_id,
                        f"{len(items)} item(s) - total {a_pesos(total)}", con=con)

    return obtener(compra_id)


def obtener(compra_id: int) -> dict:
    fila = db.q1("SELECT c.*, pr.nombre AS proveedor, u.usuario FROM compras c"
                 " LEFT JOIN proveedores pr ON pr.id = c.proveedor_id"
                 " LEFT JOIN usuarios u ON u.id = c.usuario_id WHERE c.id = ?",
                 (compra_id,))
    if not fila:
        raise ErrorNegocio("La compra no existe", 404)
    compra = dict(fila)
    compra["total_pesos"] = a_pesos(compra["total"])
    compra["items"] = []
    for it in db.q("SELECT ci.*, p.nombre, p.codigo_barras FROM compra_items ci"
                   " JOIN productos p ON p.id = ci.producto_id WHERE ci.compra_id = ?",
                   (compra_id,)):
        d = dict(it)
        d["costo_unit_pesos"] = a_pesos(d["costo_unit"])
        d["subtotal_pesos"] = a_pesos(d["subtotal"])
        compra["items"].append(d)
    return compra


def listar(desde: str = None, hasta: str = None, proveedor_id=None,
           limite: int = 200) -> list[dict]:
    sql = ("SELECT c.*, pr.nombre AS proveedor, u.usuario,"
           " (SELECT COUNT(*) FROM compra_items ci WHERE ci.compra_id = c.id) AS items"
           " FROM compras c LEFT JOIN proveedores pr ON pr.id = c.proveedor_id"
           " LEFT JOIN usuarios u ON u.id = c.usuario_id WHERE 1=1")
    par: list = []
    if desde:
        sql += " AND date(c.fecha) >= date(?)"
        par.append(desde)
    if hasta:
        sql += " AND date(c.fecha) <= date(?)"
        par.append(hasta)
    if proveedor_id:
        sql += " AND c.proveedor_id = ?"
        par.append(proveedor_id)
    sql += " ORDER BY c.id DESC LIMIT ?"
    par.append(limite)
    filas = db.filas_dict(db.q(sql, par))
    for f in filas:
        f["total_pesos"] = a_pesos(f["total"])
    return filas


def historial_producto(producto_id: int, limite: int = 50) -> list[dict]:
    """Cuanto se pago antes por este producto y a quien."""
    filas = db.filas_dict(db.q(
        "SELECT ci.cantidad, ci.costo_unit, ci.subtotal, c.fecha, c.id AS compra_id,"
        " pr.nombre AS proveedor FROM compra_items ci JOIN compras c ON c.id = ci.compra_id"
        " LEFT JOIN proveedores pr ON pr.id = c.proveedor_id"
        " WHERE ci.producto_id = ? ORDER BY c.id DESC LIMIT ?", (producto_id, limite)))
    for f in filas:
        f["costo_unit_pesos"] = a_pesos(f["costo_unit"])
        f["subtotal_pesos"] = a_pesos(f["subtotal"])
    return filas
