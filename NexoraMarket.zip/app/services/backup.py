"""Copias de seguridad de la base de datos.

Usa la API de backup en linea de SQLite: se puede copiar la base con el
sistema en uso, sin cerrar el negocio. Nunca borra una copia salvo que la
politica de retencion configurada lo indique.
"""
from __future__ import annotations

import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

from .. import audit, db
from ..db import BASE_DIR, ErrorNegocio
from . import config

DIR_DEFAULT = BASE_DIR / "datos" / "backups"


def directorio() -> Path:
    ruta = (config.obtener("backup.directorio") or "").strip()
    d = Path(ruta) if ruta else DIR_DEFAULT
    d.mkdir(parents=True, exist_ok=True)
    return d


def crear(motivo: str = "manual", usuario: dict | None = None) -> dict:
    destino = directorio() / (
        f"minimarket-{datetime.now().strftime('%Y%m%d-%H%M%S')}-{motivo}.db")
    origen = db.conexion()
    copia = sqlite3.connect(str(destino))
    try:
        origen.backup(copia)
    finally:
        copia.close()
    audit.registrar(usuario, "backup.crear", "backup", destino.name, motivo)
    aplicar_retencion()
    return {"archivo": str(destino), "nombre": destino.name,
            "bytes": destino.stat().st_size,
            "fecha": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}


def listar() -> list[dict]:
    d = directorio()
    filas = []
    for f in sorted(d.glob("minimarket-*.db"), reverse=True):
        st = f.stat()
        filas.append({"nombre": f.name, "archivo": str(f), "bytes": st.st_size,
                      "fecha": datetime.fromtimestamp(st.st_mtime)
                      .strftime("%Y-%m-%d %H:%M:%S")})
    return filas


def aplicar_retencion() -> int:
    """Conserva las N copias mas nuevas segun `backup.retencion` (0 = todas)."""
    try:
        n = int(float(config.obtener("backup.retencion", 30)))
    except (TypeError, ValueError):
        n = 30
    if n <= 0:
        return 0
    copias = listar()
    borradas = 0
    for c in copias[n:]:
        try:
            Path(c["archivo"]).unlink()
            borradas += 1
        except OSError:
            pass
    return borradas


def restaurar(nombre: str, usuario: dict | None = None) -> dict:
    origen = directorio() / Path(nombre).name
    if not origen.exists():
        raise ErrorNegocio("No se encontro esa copia de seguridad", 404)
    # Verifica que el archivo sea una base valida antes de tocar nada
    prueba = sqlite3.connect(f"file:{origen}?mode=ro", uri=True)
    try:
        prueba.execute("SELECT COUNT(*) FROM productos").fetchone()
    except sqlite3.Error as e:
        raise ErrorNegocio(f"La copia esta danada o no es valida: {e}")
    finally:
        prueba.close()

    seguridad = crear("previo-restauracion", usuario)
    actual = db.get_db_path()
    db.cerrar()
    for sufijo in ("-wal", "-shm"):
        extra = Path(str(actual) + sufijo)
        if extra.exists():
            extra.unlink()
    shutil.copy2(origen, actual)
    db.conexion()
    audit.registrar(usuario, "backup.restaurar", "backup", origen.name,
                    f"copia previa: {seguridad['nombre']}")
    return {"restaurado": origen.name, "copia_previa": seguridad["nombre"]}


def backup_diario_si_corresponde() -> dict | None:
    """Copia automatica: una por dia al iniciar el sistema."""
    if not config.obtener_bool("backup.automatico", True):
        return None
    hoy = datetime.now().strftime("%Y%m%d")
    if any(c["nombre"].startswith(f"minimarket-{hoy}") and "automatico" in c["nombre"]
           for c in listar()):
        return None
    return crear("automatico")
