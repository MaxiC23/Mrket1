"""Inventario: movimientos, ajustes, devoluciones y consultas de stock.

Regla de oro: el stock SOLO cambia a traves de `mover()`, siempre dentro de
una transaccion y dejando el movimiento registrado. Asi el historial y el
stock nunca pueden quedar desincronizados.
"""
from __future__ import annotations

from .. import audit, db
from ..db import ErrorNegocio, a_pesos
from . import config

TIPOS = ("compra", "venta", "ajuste", "devolucion", "anulacion", "alta")


def mover(con, producto_id: int, tipo: str, cantidad: float,
          referencia: str = None, motivo: str = None,
          usuario: dict | None = None) -> float:
    """Aplica un movimiento de stock. cantidad > 0 entra, cantidad < 0 sale."""
    if tipo not in TIPOS:
        raise ErrorNegocio(f"Tipo de movimiento invalido: {tipo}")
    cantidad = float(cantidad)
    if cantidad == 0:
        raise ErrorNegocio("La cantidad del movimiento no puede ser cero")

    fila = con.execute("SELECT id, nombre, stock FROM productos WHERE id = ?",
                       (producto_id,)).fetchone()
    if not fila:
        raise ErrorNegocio("El producto no existe", 404)

    nuevo = round(float(fila["stock"]) + cantidad, 4)
    if nuevo < 0:
        raise ErrorNegocio(
            f"Stock insuficiente de '{fila['nombre']}': hay {fila['stock']:g} "
            f"y se necesitan {abs(cantidad):g}", 409)

    con.execute("UPDATE productos SET stock = ?,"
                " modificado = datetime('now','localtime') WHERE id = ?",
                (nuevo, producto_id))
    con.execute(
        "INSERT INTO movimientos_stock (producto_id, tipo, entrada, salida,"
        " stock_result, referencia, motivo, usuario_id) VALUES (?,?,?,?,?,?,?,?)",
        (producto_id, tipo, cantidad if cantidad > 0 else 0,
         -cantidad if cantidad < 0 else 0, nuevo, referencia, motivo,
         (usuario or {}).get("id")))
    return nuevo


def ajustar(producto_id: int, cantidad_final: float = None, delta: float = None,
            motivo: str = "", usuario: dict | None = None) -> dict:
    """Ajuste manual: se indica el stock contado (cantidad_final) o el delta."""
    if not motivo:
        raise ErrorNegocio("Indica el motivo del ajuste")
    with db.transaccion() as con:
        fila = con.execute("SELECT stock, nombre FROM productos WHERE id = ?",
                           (producto_id,)).fetchone()
        if not fila:
            raise ErrorNegocio("El producto no existe", 404)
        if cantidad_final is not None:
            delta = round(float(cantidad_final) - float(fila["stock"]), 4)
        if delta is None or delta == 0:
            raise ErrorNegocio("El ajuste no cambia el stock")
        nuevo = mover(con, producto_id, "ajuste", delta, "AJUSTE", motivo, usuario)
        audit.registrar(usuario, "stock.ajuste", "producto", producto_id,
                        motivo, fila["stock"], nuevo, con=con)
    return {"producto_id": producto_id, "stock": nuevo, "delta": delta}


def devolucion(producto_id: int, cantidad: float, motivo: str = "",
               usuario: dict | None = None) -> dict:
    """Devolucion de un cliente: la mercaderia vuelve al stock."""
    cantidad = float(cantidad)
    if cantidad <= 0:
        raise ErrorNegocio("La cantidad devuelta debe ser mayor a cero")
    with db.transaccion() as con:
        nuevo = mover(con, producto_id, "devolucion", cantidad, "DEVOLUCION",
                      motivo or "Devolucion de cliente", usuario)
        audit.registrar(usuario, "stock.devolucion", "producto", producto_id,
                        f"+{cantidad:g}", None, nuevo, con=con)
    return {"producto_id": producto_id, "stock": nuevo}


def movimientos(producto_id: int = None, desde: str = None, hasta: str = None,
                tipo: str = None, limite: int = 500) -> list[dict]:
    sql = ("SELECT m.*, p.nombre AS producto, p.codigo_barras, u.usuario"
           " FROM movimientos_stock m JOIN productos p ON p.id = m.producto_id"
           " LEFT JOIN usuarios u ON u.id = m.usuario_id WHERE 1=1")
    par: list = []
    if producto_id:
        sql += " AND m.producto_id = ?"
        par.append(producto_id)
    if desde:
        sql += " AND date(m.fecha) >= date(?)"
        par.append(desde)
    if hasta:
        sql += " AND date(m.fecha) <= date(?)"
        par.append(hasta)
    if tipo:
        sql += " AND m.tipo = ?"
        par.append(tipo)
    sql += " ORDER BY m.id DESC LIMIT ?"
    par.append(limite)
    return db.filas_dict(db.q(sql, par))


def resumen_inventario() -> dict:
    fila = db.q1(
        "SELECT COUNT(*) AS productos,"
        " COALESCE(SUM(stock * costo),0) AS valor_costo,"
        " COALESCE(SUM(stock * precio),0) AS valor_venta,"
        " COALESCE(SUM(CASE WHEN stock <= 0 THEN 1 ELSE 0 END),0) AS sin_stock,"
        " COALESCE(SUM(CASE WHEN stock > 0 AND stock <= stock_minimo THEN 1 ELSE 0 END),0)"
        " AS stock_bajo FROM productos WHERE activo = 1")
    return {
        "productos": fila["productos"],
        "valor_inventario_costo": a_pesos(fila["valor_costo"]),
        "valor_inventario_venta": a_pesos(fila["valor_venta"]),
        "ganancia_potencial": a_pesos(fila["valor_venta"] - fila["valor_costo"]),
        "sin_stock": fila["sin_stock"],
        "stock_bajo": fila["stock_bajo"],
    }


def alertas() -> list[dict]:
    """Avisos operativos: stock, precios faltantes, datos inconsistentes."""
    res: list[dict] = []
    if config.obtener_bool("alertas.stock_bajo", True):
        for f in db.q("SELECT id, nombre, stock, stock_minimo FROM productos"
                      " WHERE activo = 1 AND stock <= 0 ORDER BY nombre LIMIT 100"):
            res.append({"nivel": "alta", "tipo": "sin_stock", "producto_id": f["id"],
                        "mensaje": f"{f['nombre']}: sin stock"})
        for f in db.q("SELECT id, nombre, stock, stock_minimo FROM productos"
                      " WHERE activo = 1 AND stock > 0 AND stock <= stock_minimo"
                      " ORDER BY stock LIMIT 100"):
            res.append({"nivel": "media", "tipo": "stock_bajo", "producto_id": f["id"],
                        "mensaje": f"{f['nombre']}: quedan {f['stock']:g} "
                                   f"(minimo {f['stock_minimo']:g})"})
    for f in db.q("SELECT id, nombre FROM productos WHERE activo = 1"
                  " AND (precio IS NULL OR precio = 0) LIMIT 100"):
        res.append({"nivel": "alta", "tipo": "sin_precio", "producto_id": f["id"],
                    "mensaje": f"{f['nombre']}: no tiene precio de venta"})
    for f in db.q("SELECT id, nombre FROM productos WHERE activo = 1"
                  " AND (codigo_barras IS NULL OR codigo_barras = '') LIMIT 100"):
        res.append({"nivel": "baja", "tipo": "sin_codigo", "producto_id": f["id"],
                    "mensaje": f"{f['nombre']}: no tiene codigo de barras"})
    for f in db.q("SELECT id, nombre FROM productos WHERE activo = 1"
                  " AND precio > 0 AND costo > 0 AND precio < costo LIMIT 100"):
        res.append({"nivel": "alta", "tipo": "precio_bajo_costo", "producto_id": f["id"],
                    "mensaje": f"{f['nombre']}: se vende por debajo del costo"})
    umbral = config.obtener_float("alertas.suba_costo", 15)
    if umbral > 0:
        for f in db.q(
                "SELECT h.producto_id, p.nombre, h.porcentaje, h.fecha"
                " FROM precios_historial h JOIN productos p ON p.id = h.producto_id"
                " WHERE h.tipo = 'costo' AND h.porcentaje >= ?"
                " AND date(h.fecha) >= date('now','localtime','-7 day')"
                " ORDER BY h.id DESC LIMIT 20", (umbral,)):
            res.append({"nivel": "media", "tipo": "suba_costo",
                        "producto_id": f["producto_id"],
                        "mensaje": f"{f['nombre']}: el costo subio {f['porcentaje']:g}% "
                                   f"el {f['fecha'][:10]}"})
    return res
