"""Productos: alta rapida, busqueda por codigo, edicion y catalogos."""
from __future__ import annotations

from .. import audit, db
from ..db import ErrorNegocio, a_centavos, a_pesos
from . import config, precios, stock

CAMPOS_TEXTO = ("nombre", "descripcion", "codigo_barras", "codigo_qr", "unidad")


def _normalizar_codigo(codigo) -> str | None:
    if codigo is None:
        return None
    codigo = str(codigo).strip()
    return codigo or None


def _expandir(fila: dict) -> dict:
    p = dict(fila)
    p["costo_pesos"] = a_pesos(p["costo"])
    p["precio_pesos"] = a_pesos(p["precio"])
    p["margen_actual"] = precios.margen_de(p["costo"], p["precio"])
    p["ganancia_unitaria"] = a_pesos(p["precio"] - p["costo"])
    p["valor_stock_costo"] = a_pesos(int(round(p["stock"] * p["costo"])))
    p["valor_stock_venta"] = a_pesos(int(round(p["stock"] * p["precio"])))
    p["ganancia_potencial"] = a_pesos(int(round(p["stock"] * (p["precio"] - p["costo"]))))
    p["estado_stock"] = ("sin_stock" if p["stock"] <= 0
                         else "bajo" if p["stock"] <= p["stock_minimo"] else "ok")
    return p


SELECT_BASE = (
    "SELECT p.*, c.nombre AS categoria, sc.nombre AS subcategoria,"
    " m.nombre AS marca, pr.nombre AS proveedor"
    " FROM productos p"
    " LEFT JOIN categorias c ON c.id = p.categoria_id"
    " LEFT JOIN subcategorias sc ON sc.id = p.subcategoria_id"
    " LEFT JOIN marcas m ON m.id = p.marca_id"
    " LEFT JOIN proveedores pr ON pr.id = p.proveedor_id")


def obtener(producto_id: int) -> dict:
    fila = db.q1(SELECT_BASE + " WHERE p.id = ?", (producto_id,))
    if not fila:
        raise ErrorNegocio("El producto no existe", 404)
    return _expandir(dict(fila))


def buscar_por_codigo(codigo: str) -> dict | None:
    """Lo que usa el lector de codigos de barras / QR."""
    codigo = _normalizar_codigo(codigo)
    if not codigo:
        return None
    fila = db.q1(SELECT_BASE + " WHERE p.codigo_barras = ? OR p.codigo_qr = ?",
                 (codigo, codigo))
    return _expandir(dict(fila)) if fila else None


def listar(texto: str = "", categoria_id=None, proveedor_id=None, estado="activos",
           orden="nombre", limite: int = 300) -> list[dict]:
    sql = SELECT_BASE + " WHERE 1=1"
    par: list = []
    if estado == "activos":
        sql += " AND p.activo = 1"
    elif estado == "inactivos":
        sql += " AND p.activo = 0"
    if texto:
        sql += (" AND (p.nombre LIKE ? OR p.descripcion LIKE ?"
                " OR p.codigo_barras LIKE ? OR p.codigo_qr LIKE ? OR m.nombre LIKE ?)")
        like = f"%{texto.strip()}%"
        par.extend([like] * 5)
    if categoria_id:
        sql += " AND p.categoria_id = ?"
        par.append(categoria_id)
    if proveedor_id:
        sql += " AND p.proveedor_id = ?"
        par.append(proveedor_id)
    if estado == "sin_stock":
        sql += " AND p.stock <= 0"
    elif estado == "stock_bajo":
        sql += " AND p.stock > 0 AND p.stock <= p.stock_minimo"
    ordenes = {"nombre": "p.nombre", "stock": "p.stock",
               "precio": "p.precio", "reciente": "p.id DESC"}
    sql += f" ORDER BY {ordenes.get(orden, 'p.nombre')} LIMIT ?"
    par.append(int(limite))
    return [_expandir(dict(f)) for f in db.q(sql, par)]


def crear(datos: dict, usuario: dict | None = None) -> dict:
    nombre = (datos.get("nombre") or "").strip()
    if not nombre:
        raise ErrorNegocio("El nombre del producto es obligatorio")
    cb = _normalizar_codigo(datos.get("codigo_barras"))
    qr = _normalizar_codigo(datos.get("codigo_qr"))
    for campo, valor in (("codigo_barras", cb), ("codigo_qr", qr)):
        if valor and db.q1(f"SELECT id FROM productos WHERE {campo} = ?", (valor,)):
            raise ErrorNegocio(f"Ya existe un producto con ese {campo.replace('_',' ')}",
                               409)

    costo = a_centavos(datos.get("costo", 0))
    margen = datos.get("margen")
    margen = float(margen) if margen not in (None, "") else None
    margen_auto = 1 if datos.get("margen_auto", True) else 0
    if datos.get("precio") not in (None, ""):
        precio = a_centavos(datos["precio"])
    else:
        base = margen if margen is not None else precios.margen_efectivo(
            {"categoria_id": datos.get("categoria_id"), "marca_id": datos.get("marca_id")})
        precio = precios.precio_desde_costo(costo, base)

    stock_inicial = float(datos.get("stock") or 0)
    if stock_inicial < 0:
        raise ErrorNegocio("El stock inicial no puede ser negativo")

    with db.transaccion() as con:
        cur = con.execute(
            "INSERT INTO productos (codigo_barras, codigo_qr, nombre, descripcion,"
            " imagen, marca_id, categoria_id, subcategoria_id, unidad, stock,"
            " stock_minimo, stock_maximo, costo, precio, margen, margen_auto, iva,"
            " proveedor_id, activo)"
            " VALUES (?,?,?,?,?,?,?,?,?,0,?,?,?,?,?,?,?,?,?)",
            (cb, qr, nombre, datos.get("descripcion"), datos.get("imagen"),
             datos.get("marca_id") or None,
             datos.get("categoria_id") or None, datos.get("subcategoria_id") or None,
             datos.get("unidad") or "UN", float(datos.get("stock_minimo") or 0),
             float(datos["stock_maximo"]) if datos.get("stock_maximo") else None,
             costo, precio, margen, margen_auto,
             float(datos.get("iva", config.obtener_float("precios.iva_default", 21))),
             datos.get("proveedor_id") or None,
             1 if datos.get("activo", True) else 0))
        pid = cur.lastrowid
        if stock_inicial:
            stock.mover(con, pid, "alta", stock_inicial, f"PRODUCTO:{pid}",
                        "Stock inicial", usuario)
        if costo or precio:
            precios.registrar_cambio(con, pid, "costo", 0, costo, None, "Alta", usuario)
            precios.registrar_cambio(con, pid, "venta", 0, precio, None, "Alta", usuario)
        audit.registrar(usuario, "producto.crear", "producto", pid, nombre,
                        None, {"codigo": cb, "costo": a_pesos(costo),
                               "precio": a_pesos(precio)}, con=con)
    return obtener(pid)


def actualizar(producto_id: int, datos: dict, usuario: dict | None = None) -> dict:
    actual = db.q1("SELECT * FROM productos WHERE id = ?", (producto_id,))
    if not actual:
        raise ErrorNegocio("El producto no existe", 404)
    actual = dict(actual)

    campos, valores = [], []
    editables = {
        "nombre": str, "descripcion": str, "marca_id": int, "categoria_id": int,
        "subcategoria_id": int, "unidad": str, "stock_minimo": float,
        "stock_maximo": float, "iva": float, "proveedor_id": int, "activo": int,
        "margen_auto": int, "codigo_barras": str, "codigo_qr": str,
    }
    for campo, tipo in editables.items():
        if campo not in datos:
            continue
        valor = datos[campo]
        if valor in ("", None) and campo not in ("nombre",):
            valor = None
        elif tipo is int:
            valor = int(valor)
        elif tipo is float:
            valor = float(valor)
        else:
            valor = str(valor).strip()
        if campo in ("codigo_barras", "codigo_qr") and valor:
            dup = db.q1(f"SELECT id FROM productos WHERE {campo} = ? AND id <> ?",
                        (valor, producto_id))
            if dup:
                raise ErrorNegocio("Ese codigo ya pertenece a otro producto", 409)
        campos.append(f"{campo} = ?")
        valores.append(valor)

    with db.transaccion() as con:
        if campos:
            valores.append(producto_id)
            con.execute(f"UPDATE productos SET {', '.join(campos)},"
                        " modificado = datetime('now','localtime') WHERE id = ?",
                        valores)
        if any(k in datos for k in ("costo", "precio", "margen")):
            precios.set_precio_manual(
                producto_id,
                costo=datos.get("costo"), precio=datos.get("precio"),
                margen=datos.get("margen"), usuario=usuario, con=con)
        if "stock" in datos and datos["stock"] not in ("", None):
            delta = round(float(datos["stock"]) - float(actual["stock"]), 4)
            if delta:
                stock.mover(con, producto_id, "ajuste", delta, "EDICION",
                            datos.get("motivo_stock", "Ajuste desde ficha de producto"),
                            usuario)
        audit.registrar(usuario, "producto.editar", "producto", producto_id,
                        actual["nombre"],
                        {k: actual.get(k) for k in datos if k in actual},
                        {k: v for k, v in datos.items() if k in actual}, con=con)
    return obtener(producto_id)


def desactivar(producto_id: int, usuario: dict | None = None) -> dict:
    p = obtener(producto_id)
    with db.transaccion() as con:
        con.execute("UPDATE productos SET activo = 0,"
                    " modificado = datetime('now','localtime') WHERE id = ?",
                    (producto_id,))
        audit.registrar(usuario, "producto.desactivar", "producto", producto_id,
                        p["nombre"], 1, 0, con=con)
    return obtener(producto_id)


def ingreso_rapido(codigo: str, cantidad: float, costo=None, precio=None,
                   datos_nuevo: dict = None, proveedor_id=None,
                   usuario: dict | None = None) -> dict:
    """Escanear -> cargar. Si el producto existe suma stock y actualiza
    costo/precio; si no existe, lo crea con los datos minimos."""
    from . import compras
    p = buscar_por_codigo(codigo)
    if not p:
        datos = dict(datos_nuevo or {})
        datos.setdefault("nombre", f"Producto {codigo}")
        datos["codigo_barras"] = codigo
        datos["costo"] = costo if costo is not None else datos.get("costo", 0)
        if precio is not None:
            datos["precio"] = precio
        datos["proveedor_id"] = proveedor_id or datos.get("proveedor_id")
        p = crear(datos, usuario)
    return compras.registrar(
        {"proveedor_id": proveedor_id or p.get("proveedor_id"),
         "items": [{"producto_id": p["id"], "cantidad": cantidad,
                    "costo_unit": costo if costo is not None else p["costo_pesos"],
                    "precio_venta": precio}]}, usuario)


# ------------------------------ catalogos -----------------------------
def categorias() -> list[dict]:
    return db.filas_dict(db.q("SELECT * FROM categorias ORDER BY nombre"))


def crear_categoria(nombre: str, margen=None, usuario=None) -> dict:
    nombre = (nombre or "").strip()
    if not nombre:
        raise ErrorNegocio("El nombre de la categoria es obligatorio")
    with db.transaccion() as con:
        try:
            cur = con.execute("INSERT INTO categorias (nombre, margen) VALUES (?,?)",
                              (nombre, float(margen) if margen not in (None, "") else None))
        except db.sqlite3.IntegrityError:
            raise ErrorNegocio("Esa categoria ya existe", 409)
        audit.registrar(usuario, "categoria.crear", "categoria", cur.lastrowid,
                        nombre, con=con)
        return {"id": cur.lastrowid, "nombre": nombre}


def actualizar_categoria(cid: int, nombre=None, margen=None, usuario=None) -> dict:
    with db.transaccion() as con:
        if nombre:
            con.execute("UPDATE categorias SET nombre = ? WHERE id = ?", (nombre, cid))
        con.execute("UPDATE categorias SET margen = ? WHERE id = ?",
                    (float(margen) if margen not in (None, "") else None, cid))
        audit.registrar(usuario, "categoria.editar", "categoria", cid,
                        f"margen={margen}", con=con)
    return db.fila_dict(db.q1("SELECT * FROM categorias WHERE id = ?", (cid,)))


def subcategorias(categoria_id=None) -> list[dict]:
    if categoria_id:
        return db.filas_dict(db.q(
            "SELECT * FROM subcategorias WHERE categoria_id = ? ORDER BY nombre",
            (categoria_id,)))
    return db.filas_dict(db.q("SELECT * FROM subcategorias ORDER BY nombre"))


def crear_subcategoria(categoria_id: int, nombre: str, usuario=None) -> dict:
    if not categoria_id or not (nombre or "").strip():
        raise ErrorNegocio("Indica categoria y nombre")
    with db.transaccion() as con:
        cur = con.execute(
            "INSERT OR IGNORE INTO subcategorias (categoria_id, nombre) VALUES (?,?)",
            (categoria_id, nombre.strip()))
        audit.registrar(usuario, "subcategoria.crear", "subcategoria",
                        cur.lastrowid, nombre, con=con)
    return {"id": cur.lastrowid, "categoria_id": categoria_id, "nombre": nombre.strip()}


def marcas() -> list[dict]:
    return db.filas_dict(db.q("SELECT * FROM marcas ORDER BY nombre"))


def crear_marca(nombre: str, margen=None, usuario=None) -> dict:
    nombre = (nombre or "").strip()
    if not nombre:
        raise ErrorNegocio("El nombre de la marca es obligatorio")
    with db.transaccion() as con:
        try:
            cur = con.execute("INSERT INTO marcas (nombre, margen) VALUES (?,?)",
                              (nombre, float(margen) if margen not in (None, "") else None))
        except db.sqlite3.IntegrityError:
            raise ErrorNegocio("Esa marca ya existe", 409)
        audit.registrar(usuario, "marca.crear", "marca", cur.lastrowid, nombre, con=con)
    return {"id": cur.lastrowid, "nombre": nombre}


def unidades() -> list[dict]:
    return db.filas_dict(db.q("SELECT * FROM unidades ORDER BY codigo"))


# ------------------------------ imagenes ------------------------------
MAX_IMAGEN = 1_500_000  # ~1,5 MB de data URL


def guardar_imagen(producto_id: int, imagen, usuario: dict | None = None) -> dict:
    """Guarda (o quita, si llega None) la imagen data URL del producto."""
    obtener(producto_id)  # valida que exista
    if imagen not in (None, ""):
        imagen = str(imagen).strip()
        if not imagen.startswith("data:image/"):
            raise ErrorNegocio("La imagen debe ser un data URL valido (data:image/...)")
        if len(imagen) > MAX_IMAGEN:
            raise ErrorNegocio("La imagen es demasiado grande (maximo 1,5 MB)")
    else:
        imagen = None
    with db.transaccion() as con:
        con.execute("UPDATE productos SET imagen = ? WHERE id = ?", (imagen, producto_id))
        audit.registrar(usuario, "producto.imagen", "producto", producto_id,
                        "Imagen " + ("asignada" if imagen else "eliminada"), con=con)
    return obtener(producto_id)


def buscar_imagen_internet(producto_id: int, usuario: dict | None = None) -> dict:
    """Busca la foto del producto en Open Food Facts usando su codigo de barras.

    Si el equipo no tiene internet o el codigo no figura, responde un error
    claro y simple (nunca deja la app colgada).
    """
    import base64
    import json
    import urllib.request

    p = obtener(producto_id)
    codigo = (p.get("codigo_barras") or p.get("codigo_qr") or "").strip()
    if not codigo or not codigo.isdigit():
        raise ErrorNegocio("El producto no tiene un codigo de barras numerico")

    url = f"https://world.openfoodfacts.org/api/v2/product/{codigo}.json"
    try:
        with urllib.request.urlopen(url, timeout=8) as r:
            datos = json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:
        raise ErrorNegocio(f"No se pudo contactar el buscador de imagenes: {e}")

    if datos.get("status") != 1 or not datos.get("product"):
        raise ErrorNegocio("El codigo no figura en el catalogo publico")
    img_url = (datos["product"].get("image_front_small_url")
               or datos["product"].get("image_front_url")
               or datos["product"].get("image_url"))
    if not img_url:
        raise ErrorNegocio("El producto esta cargado pero no tiene imagen publicada")

    try:
        with urllib.request.urlopen(img_url, timeout=12) as r:
            crudo = r.read()
            tipo = r.headers.get_content_type() or "image/jpeg"
    except Exception as e:
        raise ErrorNegocio(f"No se pudo descargar la imagen: {e}")
    if not crudo:
        raise ErrorNegocio("La imagen descargada esta vacia")
    if len(crudo) > MAX_IMAGEN:
        raise ErrorNegocio("La imagen encontrada es demasiado grande")
    data_url = f"data:{tipo};base64,{base64.b64encode(crudo).decode('ascii')}"
    return guardar_imagen(producto_id, data_url, usuario)
