"""Capa de integracion de facturacion.

IMPORTANTE: aca NO se inventa ninguna API externa. Se define una interfaz
(`AdaptadorFacturacion`) y se registran los adaptadores disponibles. Para
conectar una facturadora fiscal, un controlador homologado o un servicio
de facturacion electronica, se escribe una clase nueva que implemente
`emitir()` y se la registra con `registrar_adaptador()`. El resto del
sistema no cambia.

Adaptadores incluidos y funcionando:
  - ticket_interno : comprobante NO fiscal, se guarda como archivo de texto
                     (control interno / remito).
  - impresora_escpos: envia el ticket en ESC/POS al puerto configurado
                     (ej: /dev/usb/lp0 en Linux, COM1 o una impresora
                     compartida en Windows). Usa el puerto de configuracion,
                     no requiere librerias externas.

Stub documentado (levanta un error claro hasta que se implemente):
  - fiscal_externo : lugar donde conectar el proveedor fiscal real.
"""
from __future__ import annotations

import os
from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path

from .. import audit, db
from ..db import BASE_DIR, ErrorNegocio, a_pesos
from . import config, ventas

DIR_COMPROBANTES = BASE_DIR / "datos" / "comprobantes"


# --------------------------- interfaz ---------------------------------
class AdaptadorFacturacion(ABC):
    """Contrato que debe cumplir cualquier proveedor de facturacion."""

    nombre = "abstracto"
    descripcion = ""
    fiscal = False

    def __init__(self, cfg: dict):
        self.cfg = cfg

    @abstractmethod
    def emitir(self, venta: dict, tipo: str) -> dict:
        """Emite el comprobante.

        Debe devolver un dict con al menos:
          {"numero": str, "estado": "emitido"|"pendiente"|"error",
           "cae": str|None, "vencimiento_cae": str|None,
           "mensaje": str|None, "archivo": str|None}
        """

    def anular(self, comprobante: dict) -> dict:
        return {"estado": "anulado", "mensaje": "Anulado localmente"}

    def probar(self) -> dict:
        return {"ok": True, "mensaje": f"Adaptador {self.nombre} disponible"}


# --------------------------- utilidades -------------------------------
def _formatear_ticket(venta: dict, cfg: dict, ancho: int = 48) -> str:
    def linea(izq: str, der: str) -> str:
        espacio = max(1, ancho - len(izq) - len(der))
        return f"{izq}{' ' * espacio}{der}"

    sim = cfg.get("moneda.simbolo", "$")
    miles = cfg.get("moneda.separador_miles", ".")
    decimal = cfg.get("moneda.separador_decimal", ",")

    def money(valor) -> str:
        texto = f"{float(valor or 0):,.2f}"          # 1,234.56
        texto = texto.replace(",", "\x00").replace(".", decimal).replace("\x00", miles)
        return f"{sim}{texto}"
    out = [
        (cfg.get("negocio.nombre") or "COMPROBANTE").center(ancho),
        (cfg.get("negocio.direccion") or "").center(ancho),
        (f"Tel: {cfg.get('negocio.telefono','')}").center(ancho),
        (f"CUIT: {cfg.get('negocio.cuit','')}").center(ancho),
        (cfg.get("negocio.condicion_fiscal") or "").center(ancho),
        "-" * ancho,
        linea(venta["numero"], venta["fecha"][:16]),
        "-" * ancho,
    ]
    for it in venta["items"]:
        out.append(it["descripcion"][:ancho])
        out.append(linea(f"  {it['cantidad']:g} x {money(it['precio_unit_pesos'])}",
                         money(it['subtotal_pesos'])))
    out.append("-" * ancho)
    if venta["descuento"]:
        out.append(linea("Descuentos", "-" + money(venta['descuento_pesos'])))
    if venta["impuestos"]:
        out.append(linea("IVA incluido", money(venta['impuestos_pesos'])))
    out.append(linea("TOTAL", money(venta['total_pesos'])))
    out.append(linea("Pago", venta.get("forma_pago") or "-"))
    out.append("-" * ancho)
    if not cfg.get("_fiscal"):
        out.append("DOCUMENTO NO VALIDO COMO FACTURA".center(ancho))
    out.append("Gracias por su compra".center(ancho))
    out.append("")
    return "\n".join(out)


# --------------------------- adaptadores ------------------------------
class TicketInterno(AdaptadorFacturacion):
    nombre = "ticket_interno"
    descripcion = "Comprobante interno no fiscal guardado como archivo de texto"

    def emitir(self, venta: dict, tipo: str) -> dict:
        DIR_COMPROBANTES.mkdir(parents=True, exist_ok=True)
        ancho = int(float(self.cfg.get("factura.impresora_ancho") or 48))
        texto = _formatear_ticket(venta, self.cfg, ancho)
        ruta = DIR_COMPROBANTES / f"{venta['numero'].replace('/', '-')}.txt"
        ruta.write_text(texto, encoding="utf-8")
        return {"numero": venta["numero"], "estado": "emitido", "cae": None,
                "vencimiento_cae": None, "mensaje": "Comprobante interno generado",
                "archivo": str(ruta), "texto": texto}


class ImpresoraEscPos(AdaptadorFacturacion):
    nombre = "impresora_escpos"
    descripcion = "Impresora termica ESC/POS conectada a un puerto del sistema"

    CORTE = b"\x1d\x56\x00"
    INIT = b"\x1b\x40"

    def emitir(self, venta: dict, tipo: str) -> dict:
        puerto = (self.cfg.get("factura.impresora_puerto") or "").strip()
        if not puerto:
            raise ErrorNegocio(
                "Configura el puerto de la impresora en Configuracion > Facturacion")
        ancho = int(float(self.cfg.get("factura.impresora_ancho") or 48))
        texto = _formatear_ticket(venta, self.cfg, ancho)
        datos = self.INIT + texto.encode("cp437", "replace") + b"\n\n\n" + self.CORTE
        try:
            with open(puerto, "wb") as f:
                f.write(datos)
        except OSError as e:
            raise ErrorNegocio(f"No se pudo imprimir en {puerto}: {e}", 502)
        # copia local siempre
        DIR_COMPROBANTES.mkdir(parents=True, exist_ok=True)
        ruta = DIR_COMPROBANTES / f"{venta['numero'].replace('/', '-')}.txt"
        ruta.write_text(texto, encoding="utf-8")
        return {"numero": venta["numero"], "estado": "emitido", "cae": None,
                "vencimiento_cae": None, "mensaje": f"Impreso en {puerto}",
                "archivo": str(ruta), "texto": texto}

    def probar(self) -> dict:
        puerto = (self.cfg.get("factura.impresora_puerto") or "").strip()
        if not puerto:
            return {"ok": False, "mensaje": "Falta configurar el puerto"}
        existe = os.path.exists(puerto)
        return {"ok": existe,
                "mensaje": f"Puerto {puerto} {'disponible' if existe else 'no encontrado'}"}


class FiscalExterno(AdaptadorFacturacion):
    """PUNTO DE CONEXION con el proveedor fiscal real.

    Para implementarlo:
      1. Crear una clase que herede de AdaptadorFacturacion.
      2. En `emitir()` llamar al servicio del proveedor usando
         `self.cfg["factura.api_url"]` y `self.cfg["factura.api_token"]`,
         mas los datos fiscales de `self.cfg["negocio.*"]`.
      3. Devolver el dict del contrato (numero, cae, vencimiento_cae, estado).
      4. Registrarla con `registrar_adaptador(MiAdaptador)`.
    El sistema guarda el resultado en la tabla `comprobantes` sin cambios.
    """

    nombre = "fiscal_externo"
    descripcion = "Conector fiscal (pendiente de implementar con el proveedor real)"
    fiscal = True

    def emitir(self, venta: dict, tipo: str) -> dict:
        raise ErrorNegocio(
            "El conector fiscal todavia no esta implementado. Implementa "
            "FiscalExterno.emitir() con los datos de tu proveedor de facturacion "
            "o usa el adaptador 'ticket_interno' mientras tanto.", 501)

    def probar(self) -> dict:
        return {"ok": False,
                "mensaje": "Adaptador fiscal no implementado: falta conectar el proveedor"}


ADAPTADORES: dict[str, type] = {}


def registrar_adaptador(clase: type) -> None:
    if not issubclass(clase, AdaptadorFacturacion):
        raise ErrorNegocio("El adaptador debe heredar de AdaptadorFacturacion")
    ADAPTADORES[clase.nombre] = clase


for _c in (TicketInterno, ImpresoraEscPos, FiscalExterno):
    registrar_adaptador(_c)


def listar_adaptadores() -> list[dict]:
    return [{"nombre": c.nombre, "descripcion": c.descripcion, "fiscal": c.fiscal}
            for c in ADAPTADORES.values()]


def adaptador_activo() -> AdaptadorFacturacion:
    cfg = config.obtener_todo()
    nombre = cfg.get("factura.adaptador") or "ticket_interno"
    clase = ADAPTADORES.get(nombre)
    if not clase:
        raise ErrorNegocio(f"El adaptador de facturacion '{nombre}' no esta registrado")
    cfg["_fiscal"] = clase.fiscal
    return clase(cfg)


# --------------------------- emision ----------------------------------
def emitir(venta_id: int, tipo: str = None, usuario: dict | None = None) -> dict:
    venta = ventas.obtener(venta_id)
    if venta["estado"] == "anulada":
        raise ErrorNegocio("No se puede facturar una venta anulada")
    adaptador = adaptador_activo()
    tipo = tipo or config.obtener("factura.tipo_default", "TICKET")
    try:
        res = adaptador.emitir(venta, tipo)
        estado = res.get("estado", "emitido")
        mensaje = res.get("mensaje")
    except ErrorNegocio as e:
        res, estado, mensaje = {}, "error", e.mensaje
        _guardar(venta_id, tipo, adaptador, res, estado, mensaje, usuario)
        raise
    return _guardar(venta_id, tipo, adaptador, res, estado, mensaje, usuario)


def _guardar(venta_id, tipo, adaptador, res, estado, mensaje, usuario) -> dict:
    with db.transaccion() as con:
        cur = con.execute(
            "INSERT INTO comprobantes (venta_id, tipo, punto_venta, numero, cae,"
            " vencimiento_cae, adaptador, estado, mensaje, archivo)"
            " VALUES (?,?,?,?,?,?,?,?,?,?)",
            (venta_id, tipo, config.obtener("factura.punto_venta"), res.get("numero"),
             res.get("cae"), res.get("vencimiento_cae"), adaptador.nombre, estado,
             mensaje, res.get("archivo")))
        audit.registrar(usuario, "comprobante.emitir", "venta", venta_id,
                        f"{tipo} via {adaptador.nombre}: {estado}", con=con)
    salida = db.fila_dict(db.q1("SELECT * FROM comprobantes WHERE id = ?",
                                (cur.lastrowid,)))
    salida["texto"] = res.get("texto")
    return salida


def probar_configuracion() -> dict:
    return adaptador_activo().probar()


def ticket_texto(venta_id: int) -> str:
    """Vista previa del ticket sin emitir nada."""
    venta = ventas.obtener(venta_id)
    cfg = config.obtener_todo()
    cfg["_fiscal"] = False
    return _formatear_ticket(venta, cfg,
                             int(float(cfg.get("factura.impresora_ancho") or 48)))
