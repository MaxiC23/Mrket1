"""Dashboard, control de costos y exportacion real a Excel (.xlsx)."""
from __future__ import annotations

from datetime import date, datetime, timedelta

from .. import db, xlsx
from ..db import ErrorNegocio, a_pesos
from . import caja, config, stock, ventas


# ------------------------------ periodos ------------------------------
def rango(periodo: str = "hoy", desde: str = None, hasta: str = None) -> tuple[str, str]:
    hoy = date.today()
    if periodo == "personalizado" and desde and hasta:
        return desde, hasta
    if periodo == "dia" or periodo == "hoy":
        return hoy.isoformat(), hoy.isoformat()
    if periodo == "ayer":
        d = hoy - timedelta(days=1)
        return d.isoformat(), d.isoformat()
    if periodo == "semana":
        ini = hoy - timedelta(days=hoy.weekday())
        return ini.isoformat(), hoy.isoformat()
    if periodo == "mes":
        return hoy.replace(day=1).isoformat(), hoy.isoformat()
    if periodo == "anio":
        return hoy.replace(month=1, day=1).isoformat(), hoy.isoformat()
    if periodo == "todo":
        return "1900-01-01", hoy.isoformat()
    return desde or hoy.isoformat(), hasta or hoy.isoformat()


# ------------------------------ dashboard -----------------------------
def dashboard() -> dict:
    hoy = date.today()
    inv = stock.resumen_inventario()
    data = {
        "hoy": ventas.resumen(*rango("dia")),
        "semana": ventas.resumen(*rango("semana")),
        "mes": ventas.resumen(*rango("mes")),
        "inventario": inv,
        "alertas": stock.alertas()[:20],
        "ultimas_ventas": ventas.listar(limite=10),
    }
    data["mas_vendidos"] = [
        {"producto": f["nombre"], "cantidad": f["cantidad"],
         "total": a_pesos(f["total"])}
        for f in db.q(
            "SELECT p.nombre, SUM(vi.cantidad) AS cantidad, SUM(vi.subtotal) AS total"
            " FROM venta_items vi JOIN ventas v ON v.id = vi.venta_id"
            " JOIN productos p ON p.id = vi.producto_id"
            " WHERE v.estado = 'confirmada' AND date(v.fecha) >= date(?)"
            " GROUP BY vi.producto_id ORDER BY cantidad DESC LIMIT 10",
            (hoy.replace(day=1).isoformat(),))]
    data["ventas_por_dia"] = [
        {"fecha": f["dia"], "total": a_pesos(f["total"]),
         "ganancia": a_pesos(f["total"] - f["costo"])}
        for f in db.q(
            "SELECT date(fecha) AS dia, SUM(total) AS total, SUM(costo_total) AS costo"
            " FROM ventas WHERE estado = 'confirmada'"
            " AND date(fecha) >= date(?) GROUP BY dia ORDER BY dia",
            ((hoy - timedelta(days=29)).isoformat(),))]
    data["stock_bajo"] = db.filas_dict(db.q(
        "SELECT id, nombre, stock, stock_minimo FROM productos"
        " WHERE activo = 1 AND stock <= stock_minimo ORDER BY stock LIMIT 15"))
    data["margen_categoria"] = margen_por_categoria()
    data["ventas_por_forma"] = [
        {"forma": f["forma"], "total": a_pesos(f["total"]),
         "cantidad": f["cantidad"]}
        for f in db.q(
            "SELECT COALESCE(fp.nombre, 'Sin definir') AS forma,"
            " SUM(v.total) AS total, COUNT(*) AS cantidad"
            " FROM ventas v LEFT JOIN formas_pago fp ON fp.id = v.forma_pago_id"
            " WHERE v.estado = 'confirmada' AND date(v.fecha) >= date(?)"
            " GROUP BY forma ORDER BY total DESC",
            (hoy.replace(day=1).isoformat(),))]
    try:
        data["caja"] = caja.estado()
    except Exception:
        data["caja"] = {"abierta": False, "caja": None, "ventas": None}
    return data


def margen_por_categoria(desde: str = None, hasta: str = None) -> list[dict]:
    d, h = (desde, hasta) if desde and hasta else rango("mes")
    filas = db.q(
        "SELECT COALESCE(c.nombre,'Sin categoria') AS categoria,"
        " SUM(vi.subtotal) AS venta, SUM(vi.cantidad * vi.costo_unit) AS costo"
        " FROM venta_items vi JOIN ventas v ON v.id = vi.venta_id"
        " JOIN productos p ON p.id = vi.producto_id"
        " LEFT JOIN categorias c ON c.id = p.categoria_id"
        " WHERE v.estado = 'confirmada' AND date(v.fecha) BETWEEN date(?) AND date(?)"
        " GROUP BY categoria ORDER BY venta DESC", (d, h))
    res = []
    for f in filas:
        venta, costo = f["venta"] or 0, int(f["costo"] or 0)
        res.append({"categoria": f["categoria"], "venta": a_pesos(venta),
                    "costo": a_pesos(costo), "ganancia": a_pesos(venta - costo),
                    "margen": round((venta - costo) / costo * 100, 2) if costo else 0})
    return res


# ------------------------------ Excel ---------------------------------
def _hoja_stock(libro: xlsx.Libro) -> None:
    cols = [
        {"titulo": "Codigo", "clave": "codigo_barras", "ancho": 18},
        {"titulo": "Producto", "clave": "nombre", "ancho": 38},
        {"titulo": "Marca", "clave": "marca", "ancho": 16},
        {"titulo": "Categoria", "clave": "categoria", "ancho": 18},
        {"titulo": "Proveedor", "clave": "proveedor", "ancho": 20},
        {"titulo": "Unidad", "clave": "unidad", "ancho": 10},
        {"titulo": "Cantidad", "clave": "stock", "formato": "numero", "ancho": 12},
        {"titulo": "Stock minimo", "clave": "stock_minimo", "formato": "numero", "ancho": 13},
        {"titulo": "Costo unitario", "clave": "costo", "formato": "moneda", "ancho": 15},
        {"titulo": "Costo total stock", "clave": "costo_total", "formato": "moneda", "ancho": 17},
        {"titulo": "Precio venta", "clave": "precio", "formato": "moneda", "ancho": 15},
        {"titulo": "Ganancia unitaria", "clave": "ganancia_unit", "formato": "moneda", "ancho": 17},
        {"titulo": "Ganancia potencial", "clave": "ganancia_total", "formato": "moneda", "ancho": 18},
        {"titulo": "Margen %", "clave": "margen", "formato": "numero", "ancho": 11},
        {"titulo": "Estado", "clave": "estado", "ancho": 12},
    ]
    hoja = libro.hoja("Stock", cols)
    for f in db.q(
            "SELECT p.*, c.nombre AS categoria, m.nombre AS marca, pr.nombre AS proveedor"
            " FROM productos p LEFT JOIN categorias c ON c.id = p.categoria_id"
            " LEFT JOIN marcas m ON m.id = p.marca_id"
            " LEFT JOIN proveedores pr ON pr.id = p.proveedor_id"
            " WHERE p.activo = 1 ORDER BY p.nombre"):
        ganancia = f["precio"] - f["costo"]
        hoja.agregar({
            "codigo_barras": f["codigo_barras"], "nombre": f["nombre"],
            "marca": f["marca"], "categoria": f["categoria"],
            "proveedor": f["proveedor"], "unidad": f["unidad"],
            "stock": f["stock"], "stock_minimo": f["stock_minimo"],
            "costo": a_pesos(f["costo"]),
            "costo_total": a_pesos(int(round(f["stock"] * f["costo"]))),
            "precio": a_pesos(f["precio"]),
            "ganancia_unit": a_pesos(ganancia),
            "ganancia_total": a_pesos(int(round(f["stock"] * ganancia))),
            "margen": round(ganancia / f["costo"] * 100, 2) if f["costo"] else 0,
            "estado": ("SIN STOCK" if f["stock"] <= 0
                       else "BAJO" if f["stock"] <= f["stock_minimo"] else "OK"),
        })


def _hoja_ventas(libro: xlsx.Libro, desde: str, hasta: str) -> None:
    cols = [
        {"titulo": "Fecha", "clave": "fecha", "ancho": 12},
        {"titulo": "Hora", "clave": "hora", "ancho": 10},
        {"titulo": "Comprobante", "clave": "numero", "ancho": 16},
        {"titulo": "Producto", "clave": "producto", "ancho": 38},
        {"titulo": "Cantidad", "clave": "cantidad", "formato": "numero", "ancho": 11},
        {"titulo": "Precio unitario", "clave": "precio", "formato": "moneda", "ancho": 15},
        {"titulo": "Total", "clave": "total", "formato": "moneda", "ancho": 14},
        {"titulo": "Costo", "clave": "costo", "formato": "moneda", "ancho": 14},
        {"titulo": "Ganancia", "clave": "ganancia", "formato": "moneda", "ancho": 14},
        {"titulo": "Medio de pago", "clave": "pago", "ancho": 16},
        {"titulo": "Usuario", "clave": "usuario", "ancho": 14},
        {"titulo": "Estado", "clave": "estado", "ancho": 12},
    ]
    hoja = libro.hoja("Ventas", cols)
    for f in db.q(
            "SELECT v.fecha, v.numero, v.estado, vi.descripcion, vi.cantidad,"
            " vi.precio_unit, vi.subtotal, vi.costo_unit, fp.nombre AS pago,"
            " u.usuario FROM venta_items vi JOIN ventas v ON v.id = vi.venta_id"
            " LEFT JOIN formas_pago fp ON fp.id = v.forma_pago_id"
            " LEFT JOIN usuarios u ON u.id = v.usuario_id"
            " WHERE date(v.fecha) BETWEEN date(?) AND date(?)"
            " ORDER BY v.id, vi.id", (desde, hasta)):
        costo = int(round(f["cantidad"] * f["costo_unit"]))
        hoja.agregar({
            "fecha": f["fecha"][:10], "hora": f["fecha"][11:19], "numero": f["numero"],
            "producto": f["descripcion"], "cantidad": f["cantidad"],
            "precio": a_pesos(f["precio_unit"]), "total": a_pesos(f["subtotal"]),
            "costo": a_pesos(costo), "ganancia": a_pesos(f["subtotal"] - costo),
            "pago": f["pago"], "usuario": f["usuario"], "estado": f["estado"]})


def _hoja_compras(libro: xlsx.Libro, desde: str, hasta: str) -> None:
    cols = [
        {"titulo": "Fecha", "clave": "fecha", "ancho": 12},
        {"titulo": "Comprobante", "clave": "comprobante", "ancho": 16},
        {"titulo": "Proveedor", "clave": "proveedor", "ancho": 24},
        {"titulo": "Producto", "clave": "producto", "ancho": 38},
        {"titulo": "Cantidad", "clave": "cantidad", "formato": "numero", "ancho": 11},
        {"titulo": "Costo unitario", "clave": "costo", "formato": "moneda", "ancho": 15},
        {"titulo": "Costo total", "clave": "total", "formato": "moneda", "ancho": 15},
        {"titulo": "Usuario", "clave": "usuario", "ancho": 14},
    ]
    hoja = libro.hoja("Compras", cols)
    for f in db.q(
            "SELECT c.fecha, c.comprobante, pr.nombre AS proveedor, p.nombre AS producto,"
            " ci.cantidad, ci.costo_unit, ci.subtotal, u.usuario"
            " FROM compra_items ci JOIN compras c ON c.id = ci.compra_id"
            " JOIN productos p ON p.id = ci.producto_id"
            " LEFT JOIN proveedores pr ON pr.id = c.proveedor_id"
            " LEFT JOIN usuarios u ON u.id = c.usuario_id"
            " WHERE date(c.fecha) BETWEEN date(?) AND date(?) ORDER BY c.id, ci.id",
            (desde, hasta)):
        hoja.agregar({"fecha": f["fecha"][:10], "comprobante": f["comprobante"],
                      "proveedor": f["proveedor"], "producto": f["producto"],
                      "cantidad": f["cantidad"], "costo": a_pesos(f["costo_unit"]),
                      "total": a_pesos(f["subtotal"]), "usuario": f["usuario"]})


def _hoja_movimientos(libro: xlsx.Libro, desde: str, hasta: str) -> None:
    cols = [
        {"titulo": "Fecha", "clave": "fecha", "ancho": 12},
        {"titulo": "Hora", "clave": "hora", "ancho": 10},
        {"titulo": "Producto", "clave": "producto", "ancho": 38},
        {"titulo": "Tipo", "clave": "tipo", "ancho": 14},
        {"titulo": "Entrada", "clave": "entrada", "formato": "numero", "ancho": 11},
        {"titulo": "Salida", "clave": "salida", "formato": "numero", "ancho": 11},
        {"titulo": "Stock resultante", "clave": "stock", "formato": "numero", "ancho": 16},
        {"titulo": "Referencia", "clave": "referencia", "ancho": 16},
        {"titulo": "Motivo", "clave": "motivo", "ancho": 30},
        {"titulo": "Usuario", "clave": "usuario", "ancho": 14},
    ]
    hoja = libro.hoja("Movimientos", cols)
    for f in db.q(
            "SELECT m.*, p.nombre AS producto, u.usuario FROM movimientos_stock m"
            " JOIN productos p ON p.id = m.producto_id"
            " LEFT JOIN usuarios u ON u.id = m.usuario_id"
            " WHERE date(m.fecha) BETWEEN date(?) AND date(?) ORDER BY m.id",
            (desde, hasta)):
        hoja.agregar({"fecha": f["fecha"][:10], "hora": f["fecha"][11:19],
                      "producto": f["producto"], "tipo": f["tipo"],
                      "entrada": f["entrada"] or None, "salida": f["salida"] or None,
                      "stock": f["stock_result"], "referencia": f["referencia"],
                      "motivo": f["motivo"], "usuario": f["usuario"]})


def _hoja_precios(libro: xlsx.Libro, desde: str, hasta: str) -> None:
    cols = [
        {"titulo": "Fecha", "clave": "fecha", "ancho": 18},
        {"titulo": "Producto", "clave": "producto", "ancho": 38},
        {"titulo": "Tipo", "clave": "tipo", "ancho": 10},
        {"titulo": "Valor anterior", "clave": "antes", "formato": "moneda", "ancho": 15},
        {"titulo": "Valor nuevo", "clave": "despues", "formato": "moneda", "ancho": 15},
        {"titulo": "Aumento %", "clave": "pct", "formato": "numero", "ancho": 12},
        {"titulo": "Motivo", "clave": "motivo", "ancho": 30},
        {"titulo": "Usuario", "clave": "usuario", "ancho": 14},
    ]
    hoja = libro.hoja("Historial precios", cols)
    for f in db.q(
            "SELECT h.*, p.nombre AS producto, u.usuario FROM precios_historial h"
            " JOIN productos p ON p.id = h.producto_id"
            " LEFT JOIN usuarios u ON u.id = h.usuario_id"
            " WHERE date(h.fecha) BETWEEN date(?) AND date(?) ORDER BY h.id",
            (desde, hasta)):
        hoja.agregar({"fecha": f["fecha"], "producto": f["producto"], "tipo": f["tipo"],
                      "antes": a_pesos(f["valor_anterior"]),
                      "despues": a_pesos(f["valor_nuevo"]), "pct": f["porcentaje"],
                      "motivo": f["motivo"], "usuario": f["usuario"]})


def _hoja_resumen(libro: xlsx.Libro, desde: str, hasta: str) -> None:
    cols = [{"titulo": "Concepto", "clave": "k", "ancho": 34},
            {"titulo": "Valor", "clave": "v", "ancho": 22}]
    hoja = libro.hoja("Resumen", cols)
    res = ventas.resumen(desde, hasta)
    inv = stock.resumen_inventario()
    compras_total = db.q1("SELECT COALESCE(SUM(total),0) AS t FROM compras"
                          " WHERE date(fecha) BETWEEN date(?) AND date(?)",
                          (desde, hasta))["t"]
    filas = [
        ("Negocio", config.obtener("negocio.nombre") or "(sin configurar)"),
        ("CUIT", config.obtener("negocio.cuit")),
        ("Periodo", f"{desde} a {hasta}"),
        ("Generado", datetime.now().strftime("%Y-%m-%d %H:%M")),
        ("Ventas (cantidad)", res["cantidad"]),
        ("Ventas (total $)", res["total"]),
        ("Costo de lo vendido ($)", res["costo"]),
        ("Ganancia del periodo ($)", res["ganancia"]),
        ("Compras del periodo ($)", a_pesos(compras_total)),
        ("Productos activos", inv["productos"]),
        ("Valor inventario a costo ($)", inv["valor_inventario_costo"]),
        ("Valor inventario a venta ($)", inv["valor_inventario_venta"]),
        ("Ganancia potencial del stock ($)", inv["ganancia_potencial"]),
        ("Productos sin stock", inv["sin_stock"]),
        ("Productos con stock bajo", inv["stock_bajo"]),
    ]
    for k, v in filas:
        hoja.agregar({"k": k, "v": v})


GENERADORES = {
    "stock": lambda lib, d, h: _hoja_stock(lib),
    "ventas": _hoja_ventas,
    "compras": _hoja_compras,
    "movimientos": _hoja_movimientos,
    "precios": _hoja_precios,
    "resumen": _hoja_resumen,
}


def exportar_excel(tipos=("resumen", "stock", "ventas", "compras", "movimientos"),
                   periodo: str = "mes", desde: str = None, hasta: str = None) -> tuple:
    """Devuelve (nombre_archivo, bytes) de un .xlsx real."""
    if isinstance(tipos, str):
        tipos = [t.strip() for t in tipos.split(",") if t.strip()]
    desconocidos = [t for t in tipos if t not in GENERADORES]
    if desconocidos:
        raise ErrorNegocio(f"Reporte desconocido: {', '.join(desconocidos)}")
    d, h = rango(periodo, desde, hasta)
    libro = xlsx.Libro()
    for t in tipos:
        GENERADORES[t](libro, d, h)
    nombre = (config.obtener("negocio.nombre") or "minimarket").lower()
    nombre = "".join(c if c.isalnum() else "-" for c in nombre).strip("-") or "minimarket"
    archivo = f"{nombre}-{'-'.join(tipos)}-{d}_a_{h}.xlsx"
    return archivo, libro.a_bytes()
