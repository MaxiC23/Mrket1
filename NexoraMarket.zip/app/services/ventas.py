"""Punto de venta: registro de ventas, totales, anulacion.

Una venta descuenta stock y se guarda en la misma transaccion. Si falta
stock de cualquier item, la operacion completa se revierte y no queda
nada registrado.
"""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from .. import audit, db
from ..db import ErrorNegocio, a_centavos, a_pesos, redondear_centavos
from . import config, stock


def _numero_comprobante(con) -> str:
    pv = config.obtener("factura.punto_venta", "0001")
    fila = con.execute("SELECT COALESCE(MAX(id),0) + 1 AS n FROM ventas").fetchone()
    return f"{pv}-{fila['n']:08d}"


def calcular_totales(items: list[dict], descuento_pct=0,
                     recargo_pct: float = 0) -> dict:
    """Calcula subtotal, descuentos, IVA y total (en centavos).

    `descuento_pct` es un porcentaje del subtotal bruto (lo define el dueño
    con el maximo configurado); ademas cada item puede cargar un descuento
    en pesos propio.
    """
    subtotal = 0
    impuestos = 0
    descuentos = 0
    incluye_iva = config.obtener_bool("precios.precio_incluye_iva", True)

    for it in items:
        cantidad = float(it["cantidad"])
        precio = int(it["precio_unit"])
        bruto = int(round(cantidad * precio))
        desc = int(it.get("descuento", 0))
        neto = bruto - desc
        subtotal += bruto
        descuentos += desc
        alicuota = Decimal(str(it.get("iva", 0) or 0))
        if alicuota:
            if incluye_iva:
                impuestos += redondear_centavos(
                    Decimal(neto) - Decimal(neto) / (1 + alicuota / 100))
            else:
                impuestos += redondear_centavos(Decimal(neto) * alicuota / 100)

    try:
        pct = float(descuento_pct or 0)
    except (TypeError, ValueError):
        pct = 0.0
    if pct > 0:
        descuentos += redondear_centavos(Decimal(subtotal) * Decimal(str(pct)) / 100)

    base = subtotal - descuentos
    if not incluye_iva:
        base += impuestos
    if recargo_pct:
        base += redondear_centavos(Decimal(base) * Decimal(str(recargo_pct)) / 100)
    return {"subtotal": subtotal, "descuento": descuentos,
            "impuestos": impuestos, "total": max(base, 0)}


def _validar_descuento(descuento_pct, usuario: dict | None) -> float:
    """Valida el porcentaje de descuento contra el permiso y el maximo del dueño."""
    try:
        pct = float(descuento_pct or 0)
    except (TypeError, ValueError):
        raise ErrorNegocio("El descuento debe ser un porcentaje valido")
    if pct < 0:
        raise ErrorNegocio("El descuento no puede ser negativo")
    if pct > 0:
        if "venta.descuento" not in (usuario or {}).get("permisos", []):
            raise ErrorNegocio("Sin permiso para aplicar descuentos")
        maximo = config.obtener_float("ventas.descuento_maximo", 0)
        if maximo > 0 and pct > maximo:
            texto = str(maximo).rstrip("0").rstrip(".")
            raise ErrorNegocio(
                f"El descuento supera el maximo permitido del {texto}%")
    return pct


def _caja_actual(con, exigir: bool) -> int | None:
    """Adjunta la venta a la caja abierta actual (si la hay)."""
    fila = con.execute("SELECT id FROM cajas WHERE estado = 'abierta'"
                       " ORDER BY id DESC LIMIT 1").fetchone()
    if not fila and exigir:
        raise ErrorNegocio("No hay una caja abierta. Abri la caja antes de vender.")
    return fila["id"] if fila else None


def registrar(datos: dict, usuario: dict | None = None) -> dict:
    lineas = datos.get("items") or []
    if not lineas:
        raise ErrorNegocio("La venta no tiene productos")

    forma_pago_id = datos.get("forma_pago_id")
    recargo = 0.0
    if forma_pago_id:
        fp = db.q1("SELECT * FROM formas_pago WHERE id = ? AND activo = 1",
                   (forma_pago_id,))
        if not fp:
            raise ErrorNegocio("Forma de pago invalida", 404)
        recargo = float(fp["recargo"] or 0)
    descuento_pct = _validar_descuento(datos.get("descuento_pct", 0), usuario)
    exigir_caja = config.obtener_bool("ventas.exigir_caja_abierta", False)

    with db.transaccion() as con:
        preparados = []
        for it in lineas:
            pid = it.get("producto_id")
            if not pid and it.get("codigo"):
                fila = con.execute(
                    "SELECT id FROM productos WHERE codigo_barras = ? OR codigo_qr = ?",
                    (it["codigo"], it["codigo"])).fetchone()
                if not fila:
                    raise ErrorNegocio(f"No existe un producto con codigo {it['codigo']}",
                                       404)
                pid = fila["id"]
            p = con.execute("SELECT * FROM productos WHERE id = ?", (pid,)).fetchone()
            if not p:
                raise ErrorNegocio("Producto inexistente en la venta", 404)
            p = dict(p)
            if not p["activo"]:
                raise ErrorNegocio(f"'{p['nombre']}' esta desactivado y no se puede vender")
            cantidad = float(it.get("cantidad") or 0)
            if cantidad <= 0:
                raise ErrorNegocio(f"Cantidad invalida para '{p['nombre']}'")
            precio = (a_centavos(it["precio_unit"])
                      if it.get("precio_unit") not in (None, "") else p["precio"])
            if precio <= 0:
                raise ErrorNegocio(f"'{p['nombre']}' no tiene precio de venta cargado")
            desc = a_centavos(it.get("descuento", 0))
            preparados.append({
                "producto_id": p["id"], "descripcion": p["nombre"],
                "cantidad": cantidad, "precio_unit": precio,
                "costo_unit": p["costo"], "descuento": desc, "iva": p["iva"],
                "subtotal": int(round(cantidad * precio)) - desc})

        tot = calcular_totales(preparados, descuento_pct, recargo)
        numero = _numero_comprobante(con)
        caja_id = _caja_actual(con, exigir_caja)
        costo_total = sum(int(round(i["cantidad"] * i["costo_unit"])) for i in preparados)

        cur = con.execute(
            "INSERT INTO ventas (numero, subtotal, descuento, descuento_pct,"
            " impuestos, total, costo_total, forma_pago_id, usuario_id, cliente,"
            " caja_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (numero, tot["subtotal"], tot["descuento"], descuento_pct,
             tot["impuestos"], tot["total"], costo_total, forma_pago_id,
             (usuario or {}).get("id"), datos.get("cliente"), caja_id))
        venta_id = cur.lastrowid

        for i in preparados:
            con.execute(
                "INSERT INTO venta_items (venta_id, producto_id, descripcion, cantidad,"
                " precio_unit, costo_unit, descuento, iva, subtotal)"
                " VALUES (?,?,?,?,?,?,?,?,?)",
                (venta_id, i["producto_id"], i["descripcion"], i["cantidad"],
                 i["precio_unit"], i["costo_unit"], i["descuento"], i["iva"],
                 i["subtotal"]))
            stock.mover(con, i["producto_id"], "venta", -i["cantidad"],
                        f"VENTA:{venta_id}", f"Venta {numero}", usuario)

        audit.registrar(usuario, "venta.registrar", "venta", venta_id,
                        f"{numero} - total {a_pesos(tot['total'])}", con=con)

    return obtener(venta_id)


def anular(venta_id: int, motivo: str = "", usuario: dict | None = None) -> dict:
    with db.transaccion() as con:
        v = con.execute("SELECT * FROM ventas WHERE id = ?", (venta_id,)).fetchone()
        if not v:
            raise ErrorNegocio("La venta no existe", 404)
        if v["estado"] == "anulada":
            raise ErrorNegocio("La venta ya estaba anulada")
        for it in con.execute("SELECT * FROM venta_items WHERE venta_id = ?",
                              (venta_id,)).fetchall():
            stock.mover(con, it["producto_id"], "anulacion", it["cantidad"],
                        f"ANULA:{venta_id}", motivo or f"Anulacion de {v['numero']}",
                        usuario)
        con.execute("UPDATE ventas SET estado = 'anulada' WHERE id = ?", (venta_id,))
        con.execute("UPDATE comprobantes SET estado = 'anulado' WHERE venta_id = ?",
                    (venta_id,))
        audit.registrar(usuario, "venta.anular", "venta", venta_id,
                        motivo, "confirmada", "anulada", con=con)
    return obtener(venta_id)


def obtener(venta_id: int) -> dict:
    fila = db.q1("SELECT v.*, f.nombre AS forma_pago, u.usuario FROM ventas v"
                 " LEFT JOIN formas_pago f ON f.id = v.forma_pago_id"
                 " LEFT JOIN usuarios u ON u.id = v.usuario_id WHERE v.id = ?",
                 (venta_id,))
    if not fila:
        raise ErrorNegocio("La venta no existe", 404)
    v = dict(fila)
    for campo in ("subtotal", "descuento", "impuestos", "total", "costo_total"):
        v[campo + "_pesos"] = a_pesos(v[campo])
    v["ganancia_pesos"] = a_pesos(v["total"] - v["costo_total"])
    v["items"] = []
    for it in db.q("SELECT * FROM venta_items WHERE venta_id = ?", (venta_id,)):
        d = dict(it)
        d["precio_unit_pesos"] = a_pesos(d["precio_unit"])
        d["subtotal_pesos"] = a_pesos(d["subtotal"])
        v["items"].append(d)
    comp = db.q1("SELECT * FROM comprobantes WHERE venta_id = ? ORDER BY id DESC",
                 (venta_id,))
    v["comprobante"] = db.fila_dict(comp)
    return v


def listar(desde: str = None, hasta: str = None, limite: int = 200,
           incluir_anuladas: bool = True) -> list[dict]:
    sql = ("SELECT v.*, f.nombre AS forma_pago, u.usuario,"
           " (SELECT COUNT(*) FROM venta_items vi WHERE vi.venta_id = v.id) AS items"
           " FROM ventas v LEFT JOIN formas_pago f ON f.id = v.forma_pago_id"
           " LEFT JOIN usuarios u ON u.id = v.usuario_id WHERE 1=1")
    par: list = []
    if desde:
        sql += " AND date(v.fecha) >= date(?)"
        par.append(desde)
    if hasta:
        sql += " AND date(v.fecha) <= date(?)"
        par.append(hasta)
    if not incluir_anuladas:
        sql += " AND v.estado = 'confirmada'"
    sql += " ORDER BY v.id DESC LIMIT ?"
    par.append(limite)
    filas = db.filas_dict(db.q(sql, par))
    for f in filas:
        f["total_pesos"] = a_pesos(f["total"])
        f["ganancia_pesos"] = a_pesos(f["total"] - f["costo_total"])
    return filas


def formas_pago(activas: bool = True) -> list[dict]:
    sql = "SELECT * FROM formas_pago"
    if activas:
        sql += " WHERE activo = 1"
    return db.filas_dict(db.q(sql + " ORDER BY id"))


def guardar_forma_pago(nombre: str, recargo=0, fp_id=None, activo=True,
                       usuario=None) -> dict:
    nombre = (nombre or "").strip()
    if not nombre:
        raise ErrorNegocio("El nombre de la forma de pago es obligatorio")
    with db.transaccion() as con:
        if fp_id:
            con.execute("UPDATE formas_pago SET nombre = ?, recargo = ?, activo = ?"
                        " WHERE id = ?",
                        (nombre, float(recargo or 0), 1 if activo else 0, fp_id))
        else:
            cur = con.execute("INSERT INTO formas_pago (nombre, recargo, activo)"
                              " VALUES (?,?,?)",
                              (nombre, float(recargo or 0), 1 if activo else 0))
            fp_id = cur.lastrowid
        audit.registrar(usuario, "forma_pago.guardar", "forma_pago", fp_id,
                        nombre, con=con)
    return db.fila_dict(db.q1("SELECT * FROM formas_pago WHERE id = ?", (fp_id,)))


def resumen(desde: str = None, hasta: str = None) -> dict:
    hoy = datetime.now().strftime("%Y-%m-%d")
    desde = desde or hoy
    hasta = hasta or hoy
    f = db.q1("SELECT COUNT(*) AS cantidad, COALESCE(SUM(total),0) AS total,"
              " COALESCE(SUM(costo_total),0) AS costo FROM ventas"
              " WHERE estado = 'confirmada' AND date(fecha) BETWEEN date(?) AND date(?)",
              (desde, hasta))
    return {"desde": desde, "hasta": hasta, "cantidad": f["cantidad"],
            "total": a_pesos(f["total"]), "costo": a_pesos(f["costo"]),
            "ganancia": a_pesos(f["total"] - f["costo"])}
