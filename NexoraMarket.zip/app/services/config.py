"""Configuracion del negocio. Nada de esto esta escrito en el codigo:
todo se guarda en la tabla `config` y se edita desde la pantalla
Configuracion.
"""
from __future__ import annotations

import json

from .. import audit, db

# clave -> (valor por defecto, descripcion)
DEFAULTS: dict[str, tuple] = {
    # --- negocio ---
    "negocio.nombre": ("", "Nombre del comercio"),
    "negocio.logo": ("", "Logo en base64 (data URL)"),
    "negocio.direccion": ("", "Direccion"),
    "negocio.telefono": ("", "Telefono"),
    "negocio.cuit": ("", "CUIT"),
    "negocio.condicion_fiscal": ("Responsable Inscripto", "Condicion frente al IVA"),
    "negocio.inicio_actividades": ("", "Fecha de inicio de actividades"),
    # --- moneda y precios ---
    "moneda.simbolo": ("$", "Simbolo de moneda"),
    "moneda.codigo": ("ARS", "Codigo de moneda"),
    "moneda.decimales": ("2", "Decimales a mostrar"),
    "moneda.separador_miles": (".", "Separador de miles"),
    "moneda.separador_decimal": (",", "Separador decimal"),
    "precios.margen_default": ("35", "Margen % por defecto para precio de venta"),
    "precios.redondeo": ("10", "Redondear precio de venta a multiplos de (en pesos, 0 = sin redondeo)"),
    "precios.recalculo_automatico": ("1", "Recalcular precio de venta al cambiar el costo"),
    "precios.iva_default": ("21", "Alicuota de IVA por defecto (%)"),
    "precios.precio_incluye_iva": ("1", "El precio de venta ya incluye IVA"),
    # --- facturacion ---
    "factura.adaptador": ("ticket_interno", "Adaptador de facturacion activo"),
    "factura.punto_venta": ("0001", "Punto de venta"),
    "factura.tipo_default": ("TICKET", "Tipo de comprobante por defecto"),
    "factura.api_url": ("", "URL del servicio de facturacion"),
    "factura.api_token": ("", "Token/clave del servicio de facturacion"),
    "factura.impresora_nombre": ("", "Nombre de la impresora"),
    "factura.impresora_puerto": ("", "Puerto/dispositivo (ej: COM1, /dev/usb/lp0)"),
    "factura.impresora_ancho": ("48", "Ancho del ticket en caracteres"),
    "factura.impresora_auto": ("1", "Imprimir automaticamente al confirmar la venta"),
    # --- operacion ---
    "alertas.stock_bajo": ("1", "Avisar cuando un producto llega al stock minimo"),
    "alertas.suba_costo": ("15", "Avisar si un costo sube mas de este % de una vez"),
    "ventas.descuento_maximo": ("10", "Descuento maximo permitido por venta (%)"),
    "ventas.exigir_caja_abierta": ("0", "Exigir una caja abierta para poder vender"),
    "backup.directorio": ("", "Carpeta donde guardar las copias de seguridad"),
    "backup.automatico": ("1", "Crear copia automatica al iniciar el dia"),
    "backup.retencion": ("30", "Cantidad de copias a conservar"),
}


def obtener_todo() -> dict:
    valores = {k: v[0] for k, v in DEFAULTS.items()}
    for fila in db.q("SELECT clave, valor FROM config"):
        valores[fila["clave"]] = fila["valor"]
    return valores


def obtener(clave: str, default=None):
    fila = db.q1("SELECT valor FROM config WHERE clave = ?", (clave,))
    if fila is not None:
        return fila["valor"]
    if clave in DEFAULTS:
        return DEFAULTS[clave][0]
    return default


def obtener_float(clave: str, default: float = 0.0) -> float:
    try:
        return float(str(obtener(clave, default)).replace(",", "."))
    except (TypeError, ValueError):
        return default


def obtener_bool(clave: str, default: bool = False) -> bool:
    v = obtener(clave, "1" if default else "0")
    return str(v).strip().lower() in ("1", "true", "si", "sí", "on")


def guardar(valores: dict, usuario: dict | None = None) -> dict:
    anterior = obtener_todo()
    with db.transaccion() as con:
        for clave, valor in valores.items():
            if clave not in DEFAULTS and not clave.startswith("extra."):
                continue
            if isinstance(valor, (dict, list)):
                valor = json.dumps(valor, ensure_ascii=False)
            con.execute(
                "INSERT INTO config (clave, valor, actualizado)"
                " VALUES (?,?, datetime('now','localtime'))"
                " ON CONFLICT(clave) DO UPDATE SET valor = excluded.valor,"
                " actualizado = excluded.actualizado",
                (clave, "" if valor is None else str(valor)),
            )
        cambios = {k: {"antes": anterior.get(k), "ahora": str(v)}
                   for k, v in valores.items() if str(anterior.get(k)) != str(v)}
        if cambios:
            audit.registrar(usuario, "config.actualizar", "config", None,
                            f"{len(cambios)} valor(es) modificados",
                            valor_anterior={k: c["antes"] for k, c in cambios.items()},
                            valor_nuevo={k: c["ahora"] for k, c in cambios.items()},
                            con=con)
    return obtener_todo()


def descripciones() -> dict:
    return {k: v[1] for k, v in DEFAULTS.items()}
