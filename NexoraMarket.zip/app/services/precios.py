"""Margenes, calculo de precio de venta y actualizacion masiva de precios."""
from __future__ import annotations

import uuid
from decimal import Decimal

from .. import audit, db
from ..db import ErrorNegocio, a_centavos, a_pesos, redondear_centavos
from . import config


# ----------------------------- margenes -------------------------------
def margen_efectivo(producto: dict) -> float:
    """Margen a aplicar: producto > marca > categoria > configuracion."""
    if producto.get("margen") is not None:
        return float(producto["margen"])
    if producto.get("marca_id"):
        fila = db.q1("SELECT margen FROM marcas WHERE id = ?", (producto["marca_id"],))
        if fila and fila["margen"] is not None:
            return float(fila["margen"])
    if producto.get("categoria_id"):
        fila = db.q1("SELECT margen FROM categorias WHERE id = ?",
                     (producto["categoria_id"],))
        if fila and fila["margen"] is not None:
            return float(fila["margen"])
    return config.obtener_float("precios.margen_default", 35.0)


def aplicar_redondeo(centavos: int) -> int:
    """Redondea hacia arriba al multiplo configurado (en pesos)."""
    paso = config.obtener_float("precios.redondeo", 0)
    if paso <= 0:
        return int(centavos)
    paso_cent = int(round(paso * 100))
    if paso_cent <= 0:
        return int(centavos)
    resto = centavos % paso_cent
    return int(centavos if resto == 0 else centavos + (paso_cent - resto))


def precio_desde_costo(costo_centavos: int, margen_pct: float,
                       redondear: bool = True) -> int:
    if costo_centavos < 0:
        raise ErrorNegocio("El costo no puede ser negativo")
    bruto = redondear_centavos(
        Decimal(costo_centavos) * (Decimal(1) + Decimal(str(margen_pct)) / 100))
    return aplicar_redondeo(bruto) if redondear else bruto


def margen_de(costo_centavos: int, precio_centavos: int) -> float:
    if not costo_centavos:
        return 0.0
    return round((precio_centavos - costo_centavos) / costo_centavos * 100, 2)


# --------------------- registro de cambios de precio ------------------
def registrar_cambio(con, producto_id: int, tipo: str, anterior: int, nuevo: int,
                     porcentaje: float | None, motivo: str,
                     usuario: dict | None, lote_id: str | None = None) -> None:
    if anterior == nuevo:
        return
    con.execute(
        "INSERT INTO precios_historial (producto_id, tipo, valor_anterior,"
        " valor_nuevo, porcentaje, motivo, lote_id, usuario_id)"
        " VALUES (?,?,?,?,?,?,?,?)",
        (producto_id, tipo, anterior, nuevo, porcentaje, motivo, lote_id,
         (usuario or {}).get("id")),
    )


def historial(producto_id: int = None, lote_id: str = None,
              limite: int = 200) -> list[dict]:
    sql = ("SELECT h.*, p.nombre AS producto, p.codigo_barras, u.usuario"
           " FROM precios_historial h JOIN productos p ON p.id = h.producto_id"
           " LEFT JOIN usuarios u ON u.id = h.usuario_id WHERE 1=1")
    par: list = []
    if producto_id:
        sql += " AND h.producto_id = ?"
        par.append(producto_id)
    if lote_id:
        sql += " AND h.lote_id = ?"
        par.append(lote_id)
    sql += " ORDER BY h.id DESC LIMIT ?"
    par.append(limite)
    filas = db.filas_dict(db.q(sql, par))
    for f in filas:
        f["valor_anterior_pesos"] = a_pesos(f["valor_anterior"])
        f["valor_nuevo_pesos"] = a_pesos(f["valor_nuevo"])
    return filas


# --------------------- actualizacion masiva ---------------------------
def _seleccionar(alcance: str, ids=None, categoria_id=None, proveedor_id=None,
                 marca_id=None, incluir_inactivos=False) -> list[dict]:
    sql = "SELECT * FROM productos WHERE 1=1"
    par: list = []
    if not incluir_inactivos:
        sql += " AND activo = 1"
    if alcance == "producto":
        if not ids:
            raise ErrorNegocio("Elegi al menos un producto")
        marcas = ",".join("?" * len(ids))
        sql += f" AND id IN ({marcas})"
        par.extend(ids)
    elif alcance == "categoria":
        if not categoria_id:
            raise ErrorNegocio("Elegi una categoria")
        sql += " AND categoria_id = ?"
        par.append(categoria_id)
    elif alcance == "proveedor":
        if not proveedor_id:
            raise ErrorNegocio("Elegi un proveedor")
        sql += " AND proveedor_id = ?"
        par.append(proveedor_id)
    elif alcance == "marca":
        if not marca_id:
            raise ErrorNegocio("Elegi una marca")
        sql += " AND marca_id = ?"
        par.append(marca_id)
    elif alcance == "todos":
        pass
    else:
        raise ErrorNegocio(f"Alcance desconocido: {alcance}")
    sql += " ORDER BY nombre"
    return db.filas_dict(db.q(sql, par))


def previsualizar(porcentaje: float, aplicar_a: str = "ambos", alcance: str = "todos",
                  **filtros) -> dict:
    """Devuelve la tabla 'precio anterior -> precio nuevo' SIN guardar nada."""
    try:
        porcentaje = float(porcentaje)
    except (TypeError, ValueError):
        raise ErrorNegocio("El porcentaje no es un numero valido")
    if porcentaje <= -100:
        raise ErrorNegocio("El porcentaje no puede dejar valores negativos")
    if aplicar_a not in ("costo", "venta", "ambos"):
        raise ErrorNegocio("Elegi si el aumento va sobre costo, venta o ambos")

    factor = Decimal(1) + Decimal(str(porcentaje)) / 100
    recalcular = aplicar_a == "costo" and config.obtener_bool(
        "precios.recalculo_automatico", True)
    filas = []
    for p in _seleccionar(alcance, **filtros):
        costo_nuevo = p["costo"]
        precio_nuevo = p["precio"]
        if aplicar_a in ("costo", "ambos"):
            costo_nuevo = redondear_centavos(Decimal(p["costo"]) * factor)
        if aplicar_a in ("venta", "ambos"):
            precio_nuevo = aplicar_redondeo(
                redondear_centavos(Decimal(p["precio"]) * factor))
        elif recalcular and p["margen_auto"]:
            precio_nuevo = precio_desde_costo(costo_nuevo, margen_efectivo(p))
        if costo_nuevo == p["costo"] and precio_nuevo == p["precio"]:
            continue
        filas.append({
            "id": p["id"], "codigo_barras": p["codigo_barras"], "nombre": p["nombre"],
            "costo_anterior": a_pesos(p["costo"]), "costo_nuevo": a_pesos(costo_nuevo),
            "precio_anterior": a_pesos(p["precio"]),
            "precio_nuevo": a_pesos(precio_nuevo),
            "_costo_nuevo": costo_nuevo, "_precio_nuevo": precio_nuevo,
            "margen_nuevo": margen_de(costo_nuevo, precio_nuevo),
        })
    return {"porcentaje": porcentaje, "aplicar_a": aplicar_a, "alcance": alcance,
            "cantidad": len(filas), "productos": filas}


def aplicar(porcentaje: float, aplicar_a: str = "ambos", alcance: str = "todos",
            motivo: str = "", usuario: dict | None = None, **filtros) -> dict:
    """Confirma el aumento. Guarda historial de cada cambio (nunca lo pisa)."""
    vista = previsualizar(porcentaje, aplicar_a, alcance, **filtros)
    if not vista["productos"]:
        raise ErrorNegocio("No hay productos para actualizar con ese criterio")
    lote = uuid.uuid4().hex[:12]
    motivo = motivo or f"Aumento {porcentaje}% ({aplicar_a}, {alcance})"
    with db.transaccion() as con:
        for f in vista["productos"]:
            actual = con.execute(
                "SELECT costo, precio FROM productos WHERE id = ?", (f["id"],)
            ).fetchone()
            registrar_cambio(con, f["id"], "costo", actual["costo"], f["_costo_nuevo"],
                             porcentaje, motivo, usuario, lote)
            registrar_cambio(con, f["id"], "venta", actual["precio"],
                             f["_precio_nuevo"], porcentaje, motivo, usuario, lote)
            con.execute(
                "UPDATE productos SET costo = ?, precio = ?,"
                " modificado = datetime('now','localtime') WHERE id = ?",
                (f["_costo_nuevo"], f["_precio_nuevo"], f["id"]))
        audit.registrar(usuario, "precios.aumento", "lote", lote,
                        f"{porcentaje}% sobre {aplicar_a} - {vista['cantidad']} productos",
                        valor_nuevo={"alcance": alcance, "motivo": motivo}, con=con)
    return {"lote_id": lote, "actualizados": vista["cantidad"],
            "porcentaje": porcentaje, "aplicar_a": aplicar_a}


def recalcular_precios_por_margen(alcance: str = "todos", usuario: dict | None = None,
                                  **filtros) -> dict:
    """Recalcula precio de venta = costo * (1 + margen) para la seleccion."""
    cambios = 0
    with db.transaccion() as con:
        for p in _seleccionar(alcance, **filtros):
            if not p["margen_auto"] or not p["costo"]:
                continue
            nuevo = precio_desde_costo(p["costo"], margen_efectivo(p))
            if nuevo != p["precio"]:
                registrar_cambio(con, p["id"], "venta", p["precio"], nuevo, None,
                                 "Recalculo por margen", usuario)
                con.execute("UPDATE productos SET precio = ?,"
                            " modificado = datetime('now','localtime') WHERE id = ?",
                            (nuevo, p["id"]))
                cambios += 1
        audit.registrar(usuario, "precios.recalculo", "lote", alcance,
                        f"{cambios} precios recalculados por margen", con=con)
    return {"actualizados": cambios}


def set_precio_manual(producto_id: int, costo=None, precio=None, margen=None,
                      usuario: dict | None = None, motivo: str = "Edicion manual",
                      con=None) -> dict:
    """Cambia costo/precio de un producto registrando el historial."""
    propio = con is None
    ctx = db.transaccion() if propio else _NoOp(con)
    with ctx as c:
        p = c.execute("SELECT * FROM productos WHERE id = ?", (producto_id,)).fetchone()
        if not p:
            raise ErrorNegocio("El producto no existe", 404)
        p = dict(p)
        costo_nuevo = a_centavos(costo) if costo is not None else p["costo"]
        if margen is not None:
            p["margen"] = float(margen)
        if precio is not None:
            precio_nuevo = a_centavos(precio)
        elif costo is not None and p["margen_auto"] and config.obtener_bool(
                "precios.recalculo_automatico", True):
            precio_nuevo = precio_desde_costo(costo_nuevo, margen_efectivo(p))
        else:
            precio_nuevo = p["precio"]
        registrar_cambio(c, producto_id, "costo", p["costo"], costo_nuevo, None,
                         motivo, usuario)
        registrar_cambio(c, producto_id, "venta", p["precio"], precio_nuevo, None,
                         motivo, usuario)
        c.execute("UPDATE productos SET costo = ?, precio = ?, margen = ?,"
                  " modificado = datetime('now','localtime') WHERE id = ?",
                  (costo_nuevo, precio_nuevo, p["margen"], producto_id))
    return {"costo": costo_nuevo, "precio": precio_nuevo}


class _NoOp:
    """Permite reutilizar una transaccion ya abierta."""

    def __init__(self, con):
        self.con = con

    def __enter__(self):
        return self.con

    def __exit__(self, *exc):
        return False
