"""Servidor HTTP (libreria estandar). Sirve la interfaz y la API REST."""
from __future__ import annotations

import json
import mimetypes
import socket
import sys
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from . import api, db, security
from .db import BASE_DIR, ErrorNegocio
from .services import config, reportes

# Cuando la app esta "congelada" (PyInstaller) la interfaz se copia dentro del
# .exe y se extrae a una carpeta temporal; si no, se sirve desde el proyecto.
WEB_DIR = (Path(getattr(sys, "_MEIPASS", "") or BASE_DIR) / "web"
           if getattr(sys, "frozen", False) else BASE_DIR / "web")


class Servidor(ThreadingHTTPServer):
    """Servidor que al apagarse tambien cierra las conexiones de cliente.

    Con keep-alive (HTTP/1.1) cada conexion deja a su hilo esperando en recv()
    sin fin. `server_close()` de la clase base solo cierra el socket de
    escucha, asi que esos hilos quedarian vivos reteniendo (via
    `threading.local()`) sus conexiones a la base de datos; en Windows eso
    impide borrar o reemplazar el archivo de la base (WinError 32). Aqui se
    cierran los sockets de los clientes y se espera a que los hilos terminen.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._conexiones = set()
        self._hilos = set()
        self._lock = threading.Lock()

    def get_request(self):
        sock, addr = super().get_request()
        with self._lock:
            self._conexiones.add(sock)
        return sock, addr

    def process_request_thread(self, request, client_address):
        hilo = threading.current_thread()
        with self._lock:
            self._hilos.add(hilo)
        try:
            super().process_request_thread(request, client_address)
        finally:
            with self._lock:
                self._hilos.discard(hilo)

    def shutdown_request(self, request):
        with self._lock:
            self._conexiones.discard(request)
        try:
            request.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            request.close()
        except OSError:
            pass

    def cerrar_conexiones(self):
        """Cierra los sockets de los clientes; sus hilos salen del recv()."""
        with self._lock:
            pendientes = list(self._conexiones)
            self._conexiones.clear()
        for s in pendientes:
            try:
                s.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                s.close()
            except OSError:
                pass

    def server_close(self):
        self.cerrar_conexiones()
        super().server_close()
        with self._lock:
            hilos = list(self._hilos)
        for h in hilos:
            h.join(timeout=5)


class Handler(BaseHTTPRequestHandler):
    server_version = "Minimarket/1.0"
    protocol_version = "HTTP/1.1"

    # ----------------------------- utilidades -------------------------
    def log_message(self, formato, *args):
        if self.server.verbose:
            super().log_message(formato, *args)

    def _json(self, datos, codigo=200):
        cuerpo = json.dumps(datos, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(cuerpo)

    def _bytes(self, datos: bytes, tipo: str, descarga: str = None, codigo=200):
        self.send_response(codigo)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(datos)))
        if descarga:
            self.send_header("Content-Disposition",
                             f'attachment; filename="{descarga}"')
        self.end_headers()
        self.wfile.write(datos)

    def _error(self, mensaje: str, codigo: int = 400):
        self._json({"error": mensaje}, codigo)

    def _leer_body(self) -> dict:
        largo = int(self.headers.get("Content-Length") or 0)
        if not largo:
            return {}
        crudo = self.rfile.read(largo)
        try:
            return json.loads(crudo.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise ErrorNegocio("El cuerpo de la peticion no es JSON valido")

    def _usuario(self):
        auth = self.headers.get("Authorization", "")
        token = auth[7:].strip() if auth.lower().startswith("bearer ") else ""
        return security.usuario_de_token(token)

    # ----------------------------- estaticos --------------------------
    def _servir_archivo(self, ruta: str):
        if ruta in ("", "/"):
            ruta = "/index.html"
        destino = (WEB_DIR / ruta.lstrip("/")).resolve()
        if not str(destino).startswith(str(WEB_DIR.resolve())) or not destino.is_file():
            destino = WEB_DIR / "index.html"
        tipo = mimetypes.guess_type(str(destino))[0] or "application/octet-stream"
        if tipo.startswith("text/") or tipo in ("application/javascript",):
            tipo += "; charset=utf-8"
        self._bytes(destino.read_bytes(), tipo)

    # ----------------------------- despacho ---------------------------
    def _manejar(self, metodo: str):
        parsed = urlparse(self.path)
        ruta = unquote(parsed.path)
        query = {k: v[0] for k, v in parse_qs(parsed.query).items()}

        if not ruta.startswith("/api/"):
            if metodo != "GET":
                return self._error("Metodo no permitido", 405)
            return self._servir_archivo(ruta)

        try:
            # datos de acceso local (para el aviso de la pantalla de ingreso)
            if ruta == "/api/red" and metodo == "GET":
                if getattr(self.server, "red_accesible", False):
                    return self._json(
                        {"red": True, "ip": _ip_local(),
                         "puerto": getattr(self.server, "puerto", 8080)})
                return self._json({"red": False})

            usuario = self._usuario()

            # descarga de Excel (no es JSON)
            if ruta == "/api/reportes/excel" and metodo == "GET":
                if not usuario:
                    token = query.get("token", "")
                    usuario = security.usuario_de_token(token)
                security.exigir(usuario, "reporte.ver")
                nombre, datos = reportes.exportar_excel(
                    query.get("tipos", "resumen,stock,ventas,compras,movimientos"),
                    query.get("periodo", "mes"), query.get("desde"), query.get("hasta"))
                return self._bytes(
                    datos,
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    nombre)

            permiso, handler, params = api.resolver(metodo, ruta)
            if handler is None:
                return self._error(f"Ruta no encontrada: {ruta}", 404)
            if permiso:
                security.exigir(usuario, permiso)
            body = self._leer_body() if metodo in ("POST", "PUT", "PATCH") else {}
            ctx = api.Ctx(usuario, params, query, body)
            return self._json(handler(ctx))

        except ErrorNegocio as e:
            return self._error(e.mensaje, e.codigo)
        except db.sqlite3.IntegrityError as e:
            return self._error(f"Los datos violan una restriccion: {e}", 409)
        except ValueError as e:
            return self._error(f"Dato invalido: {e}", 400)
        except Exception:
            traceback.print_exc()
            return self._error("Error interno del servidor. Revisa la consola.", 500)

    def do_GET(self):
        self._manejar("GET")

    def do_POST(self):
        self._manejar("POST")

    def do_PUT(self):
        self._manejar("PUT")

    def do_DELETE(self):
        self._manejar("DELETE")


def _ip_local() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "127.0.0.1"


def crear_servidor(host="127.0.0.1", puerto=8080, verbose=False):
    httpd = Servidor((host, puerto), Handler)
    httpd.verbose = verbose
    httpd.red_accesible = host == "0.0.0.0"
    httpd.puerto = puerto
    httpd.daemon_threads = True
    return httpd


def iniciar(host="127.0.0.1", puerto=8080, verbose=False):
    from . import seed
    from .services import backup
    db.inicializar()
    # Los permisos, roles y valores de config nuevos se sincronizan en cada
    # arranque (idempotente). Asi una base vieja tambien gana "venta.descuento",
    # "caja.gestion" y las nuevas claves de configuracion.
    seed.cargar_basicos(db.conexion())
    seed.ajustar_nombres_duplicados()
    try:
        backup.backup_diario_si_corresponde()
    except Exception as e:  # el backup nunca debe impedir abrir el negocio
        print(f"Aviso: no se pudo crear la copia automatica ({e})")
    httpd = crear_servidor(host, puerto, verbose)
    nombre = config.obtener("negocio.nombre") or "(negocio sin configurar)"
    print(f"\n  {nombre}")
    print(f"  Sistema de gestion iniciado")
    print(f"  Base de datos: {db.get_db_path()}")
    print(f"  Abri en el navegador:  http://localhost:{puerto}")
    if host == "0.0.0.0":
        print(f"  Desde otra PC de la red: http://{_ip_local()}:{puerto}")
    print("  Ctrl+C para detener\n")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  Sistema detenido.")
    finally:
        httpd.server_close()
