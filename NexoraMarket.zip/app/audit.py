"""Registro de auditoria. Nunca se actualiza ni se borra: solo se agrega."""
from __future__ import annotations

import json

from . import db


def registrar(usuario: dict | None, operacion: str, entidad: str = None,
              entidad_id=None, detalle: str = None,
              valor_anterior=None, valor_nuevo=None, con=None) -> None:
    def ser(v):
        if v is None:
            return None
        if isinstance(v, (dict, list)):
            return json.dumps(v, ensure_ascii=False)
        return str(v)

    ejecutor = con.execute if con is not None else db.ejecutar
    ejecutor(
        "INSERT INTO auditoria (usuario_id, usuario_nombre, operacion, entidad,"
        " entidad_id, detalle, valor_anterior, valor_nuevo)"
        " VALUES (?,?,?,?,?,?,?,?)",
        ((usuario or {}).get("id"), (usuario or {}).get("usuario", "sistema"),
         operacion, entidad, str(entidad_id) if entidad_id is not None else None,
         detalle, ser(valor_anterior), ser(valor_nuevo)),
    )


def listar(limite: int = 200, entidad: str = None, desde: str = None,
           hasta: str = None) -> list[dict]:
    sql = "SELECT * FROM auditoria WHERE 1=1"
    p: list = []
    if entidad:
        sql += " AND entidad = ?"
        p.append(entidad)
    if desde:
        sql += " AND date(fecha) >= date(?)"
        p.append(desde)
    if hasta:
        sql += " AND date(fecha) <= date(?)"
        p.append(hasta)
    sql += " ORDER BY id DESC LIMIT ?"
    p.append(int(limite))
    return db.filas_dict(db.q(sql, p))
