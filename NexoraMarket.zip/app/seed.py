"""Datos iniciales: roles, permisos, unidades, formas de pago y usuario admin."""
from __future__ import annotations

from . import db, security
from .services import config, productos

UNIDADES = [
    ("UN", "Unidad", 0), ("KG", "Kilogramo", 1), ("GR", "Gramo", 1),
    ("LT", "Litro", 1), ("ML", "Mililitro", 1), ("PACK", "Pack", 0),
    ("CAJ", "Caja", 0), ("BOL", "Bolsa", 0), ("DOC", "Docena", 0),
]

FORMAS_PAGO = [("Efectivo", 0), ("Tarjeta de debito", 0), ("Tarjeta de credito", 0),
               ("Transferencia", 0), ("Mercado Pago", 0), ("Cuenta corriente", 0)]

CATEGORIAS = [("Almacen", 35), ("Bebidas", 30), ("Lacteos", 25), ("Fiambreria", 35),
              ("Panaderia", 40), ("Limpieza", 45), ("Perfumeria", 50),
              ("Kiosco", 40), ("Verduleria", 45), ("Congelados", 35)]


def cargar_basicos(con) -> None:
    for codigo, desc, frac in UNIDADES:
        con.execute("INSERT OR IGNORE INTO unidades (codigo, descripcion, fraccionable)"
                    " VALUES (?,?,?)", (codigo, desc, frac))
    for nombre, recargo in FORMAS_PAGO:
        con.execute("INSERT OR IGNORE INTO formas_pago (nombre, recargo) VALUES (?,?)",
                    (nombre, recargo))
    for nombre, margen in CATEGORIAS:
        con.execute("INSERT OR IGNORE INTO categorias (nombre, margen) VALUES (?,?)",
                    (nombre, margen))
    for codigo, desc in security.PERMISOS.items():
        con.execute("INSERT OR REPLACE INTO permisos (codigo, descripcion)"
                    " VALUES (?,?)", (codigo, desc))
    for rol, permisos in security.ROLES_BASE.items():
        con.execute("INSERT OR IGNORE INTO roles (nombre, descripcion) VALUES (?,?)",
                    (rol, f"Rol {rol}"))
        rid = con.execute("SELECT id FROM roles WHERE nombre = ?", (rol,)).fetchone()["id"]
        for p in permisos:
            con.execute("INSERT OR IGNORE INTO rol_permiso (rol_id, permiso_codigo)"
                        " VALUES (?,?)", (rid, p))
    for clave, (valor, _desc) in config.DEFAULTS.items():
        con.execute("INSERT OR IGNORE INTO config (clave, valor) VALUES (?,?)",
                    (clave, valor))


def ajustar_nombres_duplicados(usuario_admin="admin") -> None:
    """Si el admin quedo con nombre igual al rol (Administrador/Administrador)
    se ve como 'Administrador - Administrador'. Se le pone un nombre distinto.
    Idempotente: solo toca cuando nombre == rol."""
    db.ejecutar(
        "UPDATE usuarios SET nombre = 'Administrador principal'"
        " WHERE usuario = ?"
        " AND nombre IN (SELECT nombre FROM roles WHERE id = usuarios.rol_id)",
        (usuario_admin,))


def inicializar(usuario_admin="admin", password_admin="admin1234",
                nombre_negocio=None) -> dict:
    """Crea el esquema, los datos base y el usuario administrador inicial."""
    db.inicializar()
    with db.transaccion() as con:
        cargar_basicos(con)
    creado = False
    if not db.q1("SELECT id FROM usuarios LIMIT 1"):
        security.crear_usuario(usuario_admin, "Administrador principal",
                               password_admin, "Administrador")
        creado = True
    ajustar_nombres_duplicados(usuario_admin)
    if nombre_negocio:
        config.guardar({"negocio.nombre": nombre_negocio})
    return {"admin_creado": creado, "usuario": usuario_admin}


def datos_demo(usuario=None) -> dict:
    """Carga productos y un proveedor de ejemplo para probar el sistema."""
    from .services import proveedores
    prov = proveedores.guardar({"nombre": "Distribuidora del Norte",
                                "cuit": "30-71234567-9", "telefono": "381-4000000",
                                "email": "ventas@distrinorte.test"}, usuario=usuario)
    cats = {c["nombre"]: c["id"] for c in productos.categorias()}
    demo = [
        ("7790895000997", "Gaseosa Coca-Cola 2.25 L", "Bebidas", 1500, 2200, 30, 6),
        ("7790070410122", "Yerba mate Playadito 1 kg", "Almacen", 3200, 4500, 20, 5),
        ("7791234567890", "Leche entera La Serenisima 1 L", "Lacteos", 900, 1250, 40, 10),
        ("7790040999992", "Fideos Matarazzo 500 g", "Almacen", 700, 1000, 50, 12),
        ("7791290791374", "Detergente Magistral 750 ml", "Limpieza", 1800, 2700, 15, 4),
        ("7622300740504", "Galletitas Oreo 118 g", "Kiosco", 600, 950, 60, 15),
        ("7790387014109", "Aceite Natura 900 ml", "Almacen", 2400, 3400, 18, 5),
        ("7791813422105", "Pan lactal Bimbo 390 g", "Panaderia", 1400, 2000, 12, 4),
    ]
    creados = 0
    for codigo, nombre, cat, costo, precio, cant, minimo in demo:
        if productos.buscar_por_codigo(codigo):
            continue
        productos.crear({"codigo_barras": codigo, "nombre": nombre,
                         "categoria_id": cats.get(cat), "unidad": "UN",
                         "costo": costo, "precio": precio,
                         "stock": cant, "stock_minimo": minimo,
                         "proveedor_id": prov["id"]}, usuario)
        creados += 1
    return {"productos_creados": creados, "proveedor": prov["nombre"]}
