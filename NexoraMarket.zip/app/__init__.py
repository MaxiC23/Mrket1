"""Sistema de gestion para minimercado / almacen / drugstore."""
__version__ = "1.0.0"
