-- =====================================================================
-- Esquema relacional del sistema de gestion de minimercado
-- Motor: SQLite 3 (compatible en estructura con PostgreSQL/MySQL)
-- Todos los importes se guardan en CENTAVOS (INTEGER) para evitar
-- errores de redondeo de punto flotante con moneda.
-- =====================================================================

PRAGMA foreign_keys = ON;

-- ------------------------- Configuracion -----------------------------
CREATE TABLE IF NOT EXISTS config (
    clave        TEXT PRIMARY KEY,
    valor        TEXT,
    actualizado  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- ------------------------- Usuarios y roles --------------------------
CREATE TABLE IF NOT EXISTS roles (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre       TEXT NOT NULL UNIQUE,
    descripcion  TEXT
);

CREATE TABLE IF NOT EXISTS permisos (
    codigo       TEXT PRIMARY KEY,
    descripcion  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rol_permiso (
    rol_id          INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permiso_codigo  TEXT NOT NULL REFERENCES permisos(codigo) ON DELETE CASCADE,
    PRIMARY KEY (rol_id, permiso_codigo)
);

CREATE TABLE IF NOT EXISTS usuarios (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario       TEXT NOT NULL UNIQUE,
    nombre        TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    rol_id        INTEGER NOT NULL REFERENCES roles(id),
    activo        INTEGER NOT NULL DEFAULT 1 CHECK (activo IN (0,1)),
    creado        TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    ultimo_acceso TEXT
);

CREATE TABLE IF NOT EXISTS sesiones (
    token      TEXT PRIMARY KEY,
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    creada     TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    expira     TEXT NOT NULL
);

-- ------------------------- Catalogos ---------------------------------
CREATE TABLE IF NOT EXISTS categorias (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre  TEXT NOT NULL UNIQUE,
    margen  REAL,                     -- margen % por defecto de la categoria
    activo  INTEGER NOT NULL DEFAULT 1 CHECK (activo IN (0,1))
);

CREATE TABLE IF NOT EXISTS subcategorias (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    categoria_id INTEGER NOT NULL REFERENCES categorias(id) ON DELETE CASCADE,
    nombre       TEXT NOT NULL,
    UNIQUE (categoria_id, nombre)
);

CREATE TABLE IF NOT EXISTS marcas (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre  TEXT NOT NULL UNIQUE,
    margen  REAL
);

CREATE TABLE IF NOT EXISTS unidades (
    codigo      TEXT PRIMARY KEY,     -- UN, KG, LT, PACK...
    descripcion TEXT NOT NULL,
    fraccionable INTEGER NOT NULL DEFAULT 0 CHECK (fraccionable IN (0,1))
);

CREATE TABLE IF NOT EXISTS proveedores (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre    TEXT NOT NULL UNIQUE,
    cuit      TEXT,
    telefono  TEXT,
    email     TEXT,
    direccion TEXT,
    notas     TEXT,
    activo    INTEGER NOT NULL DEFAULT 1 CHECK (activo IN (0,1)),
    creado    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS formas_pago (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre   TEXT NOT NULL UNIQUE,
    recargo  REAL NOT NULL DEFAULT 0,   -- % recargo/descuento sobre el total
    activo   INTEGER NOT NULL DEFAULT 1 CHECK (activo IN (0,1))
);

-- ------------------------- Productos ---------------------------------
CREATE TABLE IF NOT EXISTS productos (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo_barras   TEXT UNIQUE,
    codigo_qr       TEXT UNIQUE,
    nombre          TEXT NOT NULL,
    descripcion     TEXT,
    imagen          TEXT,                        -- imagen del producto (data URL)
    marca_id        INTEGER REFERENCES marcas(id),
    categoria_id    INTEGER REFERENCES categorias(id),
    subcategoria_id INTEGER REFERENCES subcategorias(id),
    unidad          TEXT NOT NULL DEFAULT 'UN' REFERENCES unidades(codigo),
    stock           REAL NOT NULL DEFAULT 0 CHECK (stock >= 0),
    stock_minimo    REAL NOT NULL DEFAULT 0 CHECK (stock_minimo >= 0),
    stock_maximo    REAL,
    costo           INTEGER NOT NULL DEFAULT 0 CHECK (costo >= 0),   -- centavos
    precio          INTEGER NOT NULL DEFAULT 0 CHECK (precio >= 0),  -- centavos
    margen          REAL,                        -- margen % propio del producto
    margen_auto     INTEGER NOT NULL DEFAULT 1 CHECK (margen_auto IN (0,1)),
    iva             REAL NOT NULL DEFAULT 21,    -- alicuota %
    proveedor_id    INTEGER REFERENCES proveedores(id),
    activo          INTEGER NOT NULL DEFAULT 1 CHECK (activo IN (0,1)),
    creado          TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    modificado      TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE INDEX IF NOT EXISTS ix_prod_nombre     ON productos(nombre);
CREATE INDEX IF NOT EXISTS ix_prod_categoria  ON productos(categoria_id);
CREATE INDEX IF NOT EXISTS ix_prod_proveedor  ON productos(proveedor_id);
CREATE INDEX IF NOT EXISTS ix_prod_activo     ON productos(activo);

-- ------------------------- Historial de precios ----------------------
CREATE TABLE IF NOT EXISTS precios_historial (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    producto_id   INTEGER NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
    tipo          TEXT NOT NULL CHECK (tipo IN ('costo','venta')),
    valor_anterior INTEGER NOT NULL,
    valor_nuevo    INTEGER NOT NULL,
    porcentaje     REAL,
    motivo         TEXT,
    lote_id        TEXT,               -- agrupa una actualizacion masiva
    usuario_id     INTEGER REFERENCES usuarios(id),
    fecha          TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_precios_prod  ON precios_historial(producto_id);
CREATE INDEX IF NOT EXISTS ix_precios_fecha ON precios_historial(fecha);

-- ------------------------- Compras -----------------------------------
CREATE TABLE IF NOT EXISTS compras (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    proveedor_id  INTEGER REFERENCES proveedores(id),
    comprobante   TEXT,
    fecha         TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    total         INTEGER NOT NULL DEFAULT 0,
    usuario_id    INTEGER REFERENCES usuarios(id),
    notas         TEXT
);
CREATE INDEX IF NOT EXISTS ix_compras_fecha ON compras(fecha);

CREATE TABLE IF NOT EXISTS compra_items (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    compra_id    INTEGER NOT NULL REFERENCES compras(id) ON DELETE CASCADE,
    producto_id  INTEGER NOT NULL REFERENCES productos(id),
    cantidad     REAL NOT NULL CHECK (cantidad > 0),
    costo_unit   INTEGER NOT NULL CHECK (costo_unit >= 0),
    subtotal     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_citems_compra ON compra_items(compra_id);
CREATE INDEX IF NOT EXISTS ix_citems_prod   ON compra_items(producto_id);

-- ------------------------- Ventas ------------------------------------
CREATE TABLE IF NOT EXISTS ventas (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    numero         TEXT NOT NULL UNIQUE,
    fecha          TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    subtotal       INTEGER NOT NULL,
    descuento      INTEGER NOT NULL DEFAULT 0,
    descuento_pct  REAL NOT NULL DEFAULT 0,     -- descuento general aplicado (%)
    impuestos      INTEGER NOT NULL DEFAULT 0,
    total          INTEGER NOT NULL,
    costo_total    INTEGER NOT NULL DEFAULT 0,
    forma_pago_id  INTEGER REFERENCES formas_pago(id),
    caja_id        INTEGER REFERENCES cajas(id),
    usuario_id     INTEGER REFERENCES usuarios(id),
    estado         TEXT NOT NULL DEFAULT 'confirmada'
                   CHECK (estado IN ('confirmada','anulada')),
    cliente        TEXT
);
CREATE INDEX IF NOT EXISTS ix_ventas_fecha ON ventas(fecha);

CREATE TABLE IF NOT EXISTS cajas (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    estado            TEXT NOT NULL DEFAULT 'abierta'
                      CHECK (estado IN ('abierta','cerrada')),
    monto_inicial     INTEGER NOT NULL DEFAULT 0,
    ventas_total      INTEGER NOT NULL DEFAULT 0,
    monto_esperado    INTEGER NOT NULL DEFAULT 0,
    monto_contado     INTEGER NOT NULL DEFAULT 0,
    diferencia        INTEGER NOT NULL DEFAULT 0,
    abierta_en        TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    cerrada_en        TEXT,
    usuario_abre_id   INTEGER REFERENCES usuarios(id),
    usuario_cierra_id INTEGER REFERENCES usuarios(id),
    observaciones     TEXT
);
CREATE INDEX IF NOT EXISTS ix_cajas_estado ON cajas(estado);

CREATE TABLE IF NOT EXISTS venta_items (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    venta_id     INTEGER NOT NULL REFERENCES ventas(id) ON DELETE CASCADE,
    producto_id  INTEGER NOT NULL REFERENCES productos(id),
    descripcion  TEXT NOT NULL,
    cantidad     REAL NOT NULL CHECK (cantidad > 0),
    precio_unit  INTEGER NOT NULL CHECK (precio_unit >= 0),
    costo_unit   INTEGER NOT NULL DEFAULT 0,
    descuento    INTEGER NOT NULL DEFAULT 0,
    iva          REAL NOT NULL DEFAULT 0,
    subtotal     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_vitems_venta ON venta_items(venta_id);
CREATE INDEX IF NOT EXISTS ix_vitems_prod  ON venta_items(producto_id);

-- ------------------------- Movimientos de stock ----------------------
CREATE TABLE IF NOT EXISTS movimientos_stock (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    producto_id  INTEGER NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
    tipo         TEXT NOT NULL CHECK (tipo IN
                 ('compra','venta','ajuste','devolucion','anulacion','alta')),
    entrada      REAL NOT NULL DEFAULT 0,
    salida       REAL NOT NULL DEFAULT 0,
    stock_result REAL NOT NULL,
    referencia   TEXT,                 -- ej: VENTA:12  COMPRA:5
    motivo       TEXT,
    usuario_id   INTEGER REFERENCES usuarios(id),
    fecha        TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_mov_prod  ON movimientos_stock(producto_id);
CREATE INDEX IF NOT EXISTS ix_mov_fecha ON movimientos_stock(fecha);

-- ------------------------- Facturacion -------------------------------
CREATE TABLE IF NOT EXISTS comprobantes (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    venta_id       INTEGER NOT NULL REFERENCES ventas(id) ON DELETE CASCADE,
    tipo           TEXT NOT NULL,          -- TICKET, FACTURA_B, FACTURA_A...
    punto_venta    TEXT,
    numero         TEXT,
    cae            TEXT,
    vencimiento_cae TEXT,
    adaptador      TEXT NOT NULL,          -- proveedor de facturacion usado
    estado         TEXT NOT NULL DEFAULT 'emitido'
                   CHECK (estado IN ('emitido','pendiente','error','anulado')),
    mensaje        TEXT,
    archivo        TEXT,
    fecha          TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_comp_venta ON comprobantes(venta_id);

-- ------------------------- Auditoria ---------------------------------
CREATE TABLE IF NOT EXISTS auditoria (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    fecha         TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    usuario_id    INTEGER REFERENCES usuarios(id),
    usuario_nombre TEXT,
    operacion     TEXT NOT NULL,
    entidad       TEXT,
    entidad_id    TEXT,
    detalle       TEXT,
    valor_anterior TEXT,
    valor_nuevo    TEXT
);
CREATE INDEX IF NOT EXISTS ix_audit_fecha ON auditoria(fecha);
CREATE INDEX IF NOT EXISTS ix_audit_ent   ON auditoria(entidad, entidad_id);
