"""Acceso a la base de datos SQLite.

Todas las operaciones de escritura importantes se hacen dentro de
`transaccion()`, que hace COMMIT si todo salio bien y ROLLBACK ante
cualquier excepcion. Asi una venta nunca queda registrada sin descontar
stock (ni al reves).
"""
from __future__ import annotations

import os
import sqlite3
import sys
import threading
from contextlib import contextmanager
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path


def directorio_base() -> Path:
    """Carpeta raiz de datos: junto al .exe cuando esta "congelado"
    (PyInstaller), o la carpeta del proyecto al correr con python."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


BASE_DIR = directorio_base()
SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"
DEFAULT_DB = BASE_DIR / "datos" / "minimarket.db"

_local = threading.local()
_db_path: Path = Path(os.environ.get("MINIMARKET_DB", str(DEFAULT_DB)))


class ErrorNegocio(Exception):
    """Error esperable de negocio: se devuelve al usuario como mensaje claro."""

    def __init__(self, mensaje: str, codigo: int = 400):
        super().__init__(mensaje)
        self.mensaje = mensaje
        self.codigo = codigo


def set_db_path(path) -> None:
    """Cambia la base activa (usado por los tests y por --db)."""
    global _db_path
    _db_path = Path(path)
    cerrar()


def get_db_path() -> Path:
    return _db_path


def conexion() -> sqlite3.Connection:
    """Conexion por hilo (el servidor HTTP es multi-hilo)."""
    con = getattr(_local, "con", None)
    if con is not None and getattr(_local, "path", None) == str(_db_path):
        return con
    _db_path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(_db_path), timeout=30, isolation_level=None)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    con.execute("PRAGMA journal_mode = WAL")
    con.execute("PRAGMA busy_timeout = 30000")
    _local.con = con
    _local.path = str(_db_path)
    return con


def cerrar() -> None:
    """Cierra la conexion del hilo actual.

    Python 3.13 exige que cada conexion se use (y se cierre) en el hilo que la
    creo: intentar `con.close()` desde otro hilo lanza
    `sqlite3.ProgrammingError`. Por eso aqui solo se cierra la conexion del
    hilo que llama. Las conexiones de los demas hilos se liberan solas cuando
    ese hilo termina (el almacenamiento `threading.local` se limpia al salir),
    por lo que conviene terminar los hilos del servidor antes de apagar el
    sistema o borrar la base.
    """
    con = getattr(_local, "con", None)
    if con is not None:
        try:
            con.close()
        except sqlite3.Error:
            pass
    _local.con = None
    _local.path = None


@contextmanager
def transaccion():
    """Bloque atomico. Uso: `with transaccion() as con: ...`"""
    con = conexion()
    ya_abierta = con.in_transaction
    if not ya_abierta:
        con.execute("BEGIN IMMEDIATE")
    try:
        yield con
    except Exception:
        if not ya_abierta:
            con.execute("ROLLBACK")
        raise
    else:
        if not ya_abierta:
            con.execute("COMMIT")


# ------------------------------ helpers SQL ---------------------------
def q(sql: str, params=()) -> list[sqlite3.Row]:
    return conexion().execute(sql, params).fetchall()


def q1(sql: str, params=()):
    return conexion().execute(sql, params).fetchone()


def ejecutar(sql: str, params=()) -> sqlite3.Cursor:
    return conexion().execute(sql, params)


def fila_dict(row) -> dict | None:
    return dict(row) if row is not None else None


def filas_dict(rows) -> list[dict]:
    return [dict(r) for r in rows]


# ------------------------------ dinero --------------------------------
CENT = Decimal("1")


def a_centavos(valor) -> int:
    """Convierte un importe (float/str/Decimal) a centavos enteros."""
    if valor is None or valor == "":
        return 0
    if isinstance(valor, int) and not isinstance(valor, bool):
        return int(Decimal(valor) * 100)
    d = Decimal(str(valor).replace(",", ".").replace("$", "").strip())
    return int((d * 100).quantize(CENT, rounding=ROUND_HALF_UP))


def a_pesos(centavos: int) -> float:
    return float(Decimal(int(centavos or 0)) / 100)


def redondear_centavos(valor: Decimal) -> int:
    return int(Decimal(valor).quantize(CENT, rounding=ROUND_HALF_UP))


# ------------------------------ init ----------------------------------
def _migrar(con: sqlite3.Connection) -> None:
    """Aplica cambios de esquema a bases creadas con versiones anteriores.

    `schema.sql` usa CREATE TABLE IF NOT EXISTS, que no agrega columnas a
    tablas ya existentes; las bases viejas reciben aqui las columnas nuevas
    (idempotente: cada columna se agrega una sola vez).
    """
    def columnas(tabla: str) -> set[str]:
        return {fila["name"] for fila in con.execute(f"PRAGMA table_info({tabla})")}

    if "imagen" not in columnas("productos"):
        con.execute("ALTER TABLE productos ADD COLUMN imagen TEXT")

    cols_ventas = columnas("ventas")
    if "descuento_pct" not in cols_ventas:
        con.execute("ALTER TABLE ventas ADD COLUMN descuento_pct REAL NOT NULL DEFAULT 0")
    if "caja_id" not in cols_ventas:
        con.execute("ALTER TABLE ventas ADD COLUMN caja_id INTEGER REFERENCES cajas(id)")
    if "caja_id" in columnas("ventas"):
        con.execute("CREATE INDEX IF NOT EXISTS ix_ventas_caja ON ventas(caja_id)")


def inicializar(con: sqlite3.Connection | None = None) -> None:
    """Crea el esquema si no existe (idempotente) y migra bases viejas."""
    con = con or conexion()
    con.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
    _migrar(con)
