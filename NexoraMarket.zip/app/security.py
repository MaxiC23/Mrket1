"""Usuarios, contrasenas, sesiones y permisos."""
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
from datetime import datetime, timedelta

from . import db
from .db import ErrorNegocio

ITERACIONES = 200_000
DURACION_SESION_HORAS = 12

# --------------------------- catalogo de permisos ---------------------
PERMISOS = {
    "venta.crear": "Registrar ventas",
    "venta.anular": "Anular ventas",
    "venta.descuento": "Aplicar descuentos en las ventas",
    "caja.gestion": "Abrir y cerrar caja",
    "producto.ver": "Ver productos y stock",
    "producto.editar": "Crear y modificar productos",
    "precio.editar": "Modificar precios y aplicar aumentos",
    "stock.ajustar": "Ajustes manuales y devoluciones de stock",
    "compra.crear": "Registrar compras a proveedores",
    "proveedor.editar": "Administrar proveedores",
    "reporte.ver": "Ver reportes y exportar Excel",
    "config.editar": "Modificar la configuracion del negocio",
    "usuario.editar": "Administrar usuarios y permisos",
    "backup.ejecutar": "Crear y restaurar copias de seguridad",
    "auditoria.ver": "Consultar el historial de auditoria",
}

ROLES_BASE = {
    "Administrador": list(PERMISOS.keys()),
    "Encargado": [
        "venta.crear", "venta.anular", "venta.descuento", "caja.gestion",
        "producto.ver", "producto.editar",
        "precio.editar", "stock.ajustar", "compra.crear", "proveedor.editar",
        "reporte.ver", "auditoria.ver", "backup.ejecutar",
    ],
    "Vendedor": ["venta.crear", "producto.ver"],
    "Consulta": ["producto.ver", "reporte.ver"],
}


# --------------------------- contrasenas ------------------------------
def hash_password(password: str) -> str:
    if not password or len(password) < 4:
        raise ErrorNegocio("La contrasena debe tener al menos 4 caracteres")
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, ITERACIONES)
    return f"pbkdf2_sha256${ITERACIONES}${salt.hex()}${dk.hex()}"


def verificar_password(password: str, almacenado: str) -> bool:
    try:
        _, iters, salt_hex, hash_hex = almacenado.split("$")
        dk = hashlib.pbkdf2_hmac(
            "sha256", password.encode(), bytes.fromhex(salt_hex), int(iters)
        )
        return hmac.compare_digest(dk.hex(), hash_hex)
    except Exception:
        return False


# --------------------------- usuarios ---------------------------------
def crear_usuario(usuario: str, nombre: str, password: str, rol: str,
                  activo: bool = True) -> int:
    usuario = (usuario or "").strip().lower()
    if not usuario:
        raise ErrorNegocio("El nombre de usuario es obligatorio")
    fila = db.q1("SELECT id FROM roles WHERE nombre = ?", (rol,))
    if not fila:
        raise ErrorNegocio(f"El rol '{rol}' no existe")
    if db.q1("SELECT id FROM usuarios WHERE usuario = ?", (usuario,)):
        raise ErrorNegocio("Ya existe un usuario con ese nombre")
    with db.transaccion() as con:
        cur = con.execute(
            "INSERT INTO usuarios (usuario, nombre, password_hash, rol_id, activo)"
            " VALUES (?,?,?,?,?)",
            (usuario, nombre or usuario, hash_password(password), fila["id"],
             1 if activo else 0),
        )
        return cur.lastrowid


def cambiar_password(usuario_id: int, password: str) -> None:
    with db.transaccion() as con:
        con.execute("UPDATE usuarios SET password_hash = ? WHERE id = ?",
                    (hash_password(password), usuario_id))


def permisos_de(usuario_id: int) -> list[str]:
    filas = db.q(
        "SELECT rp.permiso_codigo AS c FROM usuarios u"
        " JOIN rol_permiso rp ON rp.rol_id = u.rol_id WHERE u.id = ?",
        (usuario_id,),
    )
    return [f["c"] for f in filas]


# --------------------------- sesiones ---------------------------------
def login(usuario: str, password: str) -> dict:
    fila = db.q1(
        "SELECT u.*, r.nombre AS rol FROM usuarios u JOIN roles r ON r.id = u.rol_id"
        " WHERE u.usuario = ?", ((usuario or "").strip().lower(),))
    if not fila or not verificar_password(password, fila["password_hash"]):
        raise ErrorNegocio("Usuario o contrasena incorrectos", 401)
    if not fila["activo"]:
        raise ErrorNegocio("El usuario esta desactivado", 403)
    token = secrets.token_urlsafe(32)
    expira = (datetime.now() + timedelta(hours=DURACION_SESION_HORAS)
              ).strftime("%Y-%m-%d %H:%M:%S")
    with db.transaccion() as con:
        con.execute("INSERT INTO sesiones (token, usuario_id, expira) VALUES (?,?,?)",
                    (token, fila["id"], expira))
        con.execute("UPDATE usuarios SET ultimo_acceso = datetime('now','localtime')"
                    " WHERE id = ?", (fila["id"],))
        con.execute("DELETE FROM sesiones WHERE expira < datetime('now','localtime')")
    return {
        "token": token,
        "usuario": {
            "id": fila["id"], "usuario": fila["usuario"], "nombre": fila["nombre"],
            "rol": fila["rol"], "permisos": permisos_de(fila["id"]),
        },
    }


def logout(token: str) -> None:
    with db.transaccion() as con:
        con.execute("DELETE FROM sesiones WHERE token = ?", (token,))


def usuario_de_token(token: str) -> dict | None:
    if not token:
        return None
    fila = db.q1(
        "SELECT u.id, u.usuario, u.nombre, u.activo, r.nombre AS rol"
        " FROM sesiones s JOIN usuarios u ON u.id = s.usuario_id"
        " JOIN roles r ON r.id = u.rol_id"
        " WHERE s.token = ? AND s.expira > datetime('now','localtime')", (token,))
    if not fila or not fila["activo"]:
        return None
    d = dict(fila)
    d["permisos"] = permisos_de(d["id"])
    return d


def exigir(usuario: dict | None, permiso: str) -> dict:
    if not usuario:
        raise ErrorNegocio("Sesion no iniciada", 401)
    if permiso not in usuario.get("permisos", []):
        raise ErrorNegocio(
            f"El usuario no tiene permiso para: {PERMISOS.get(permiso, permiso)}", 403)
    return usuario
