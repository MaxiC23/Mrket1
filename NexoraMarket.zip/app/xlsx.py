"""Generador de archivos .xlsx real, escrito solo con la libreria estandar.

Un .xlsx es un ZIP con XML adentro (Office Open XML). Se implementa aca
para que el sistema no dependa de paquetes externos: se instala Python y
funciona. Soporta encabezados en negrita, ancho de columnas, congelado de
la primera fila, formato de moneda/numero/fecha y totales.
"""
from __future__ import annotations

import datetime as _dt
import zipfile
from io import BytesIO
from xml.sax.saxutils import escape

# numFmtId usados: 0 general, 3 miles, 14 fecha, 164 moneda, 10 porcentaje
FORMATOS = {"texto": 0, "entero": 1, "numero": 2, "moneda": 3, "fecha": 4,
            "porcentaje": 5}

_CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
{sheets}
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>"""

_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

_STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="2">
<numFmt numFmtId="164" formatCode="&quot;$&quot;\\ #,##0.00"/>
<numFmt numFmtId="165" formatCode="#,##0.00"/>
</numFmts>
<fonts count="2">
<font><sz val="11"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
</fonts>
<fills count="3">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF14532D"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="7">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="1" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="14" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="10" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""

ESTILO_ENCABEZADO = 6


def _col(idx: int) -> str:
    """0 -> A, 26 -> AA"""
    nombre = ""
    idx += 1
    while idx:
        idx, resto = divmod(idx - 1, 26)
        nombre = chr(65 + resto) + nombre
    return nombre


def _serial_fecha(valor) -> float:
    if isinstance(valor, _dt.datetime):
        base = _dt.datetime(1899, 12, 30)
        return (valor - base).total_seconds() / 86400
    base = _dt.date(1899, 12, 30)
    return (valor - base).days


class Hoja:
    def __init__(self, nombre: str, columnas: list[dict]):
        self.nombre = nombre[:31] or "Hoja"
        self.columnas = columnas          # [{"titulo":..,"clave":..,"formato":..,"ancho":..}]
        self.filas: list[list] = []

    def agregar(self, fila) -> None:
        if isinstance(fila, dict):
            fila = [fila.get(c["clave"]) for c in self.columnas]
        self.filas.append(list(fila))

    def agregar_muchas(self, filas) -> None:
        for f in filas:
            self.agregar(f)


class Libro:
    def __init__(self):
        self.hojas: list[Hoja] = []

    def hoja(self, nombre: str, columnas: list[dict]) -> Hoja:
        h = Hoja(nombre, columnas)
        self.hojas.append(h)
        return h

    # ---------------------------- XML -------------------------------
    def _xml_hoja(self, hoja: Hoja) -> str:
        anchos = "".join(
            f'<col min="{i+1}" max="{i+1}" width="{c.get("ancho", 18)}" customWidth="1"/>'
            for i, c in enumerate(hoja.columnas))
        partes = [
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
            '<sheetViews><sheetView workbookViewId="0">'
            '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
            '</sheetView></sheetViews>',
            f'<cols>{anchos}</cols>' if anchos else "",
            '<sheetData>',
        ]
        # encabezado
        celdas = "".join(
            f'<c r="{_col(i)}1" s="{ESTILO_ENCABEZADO}" t="inlineStr">'
            f'<is><t>{escape(str(c["titulo"]))}</t></is></c>'
            for i, c in enumerate(hoja.columnas))
        partes.append(f'<row r="1">{celdas}</row>')

        for n, fila in enumerate(hoja.filas, start=2):
            celdas = []
            for i, valor in enumerate(fila):
                if valor is None or valor == "":
                    continue
                fmt = hoja.columnas[i].get("formato", "texto")
                estilo = FORMATOS.get(fmt, 0)
                ref = f"{_col(i)}{n}"
                if fmt == "fecha" and isinstance(valor, (_dt.date, _dt.datetime)):
                    celdas.append(f'<c r="{ref}" s="{estilo}"><v>{_serial_fecha(valor)}</v></c>')
                elif fmt in ("entero", "numero", "moneda", "porcentaje"):
                    try:
                        num = float(valor)
                    except (TypeError, ValueError):
                        celdas.append(f'<c r="{ref}" t="inlineStr"><is><t>'
                                      f'{escape(str(valor))}</t></is></c>')
                        continue
                    if fmt == "porcentaje":
                        num = num / 100
                    celdas.append(f'<c r="{ref}" s="{estilo}"><v>{num:.6f}</v></c>')
                else:
                    celdas.append(f'<c r="{ref}" s="{estilo}" t="inlineStr"><is><t>'
                                  f'{escape(str(valor))}</t></is></c>')
            partes.append(f'<row r="{n}">{"".join(celdas)}</row>')
        partes.append("</sheetData></worksheet>")
        return "".join(partes)

    def guardar(self, destino) -> None:
        buffer = destino if hasattr(destino, "write") else open(destino, "wb")
        cerrar = not hasattr(destino, "write")
        hojas_ct = "".join(
            f'<Override PartName="/xl/worksheets/sheet{i+1}.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.'
            'spreadsheetml.worksheet+xml"/>' for i in range(len(self.hojas)))
        wb_sheets = "".join(
            f'<sheet name="{escape(h.nombre)}" sheetId="{i+1}" r:id="rId{i+1}"/>'
            for i, h in enumerate(self.hojas))
        wb = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
              ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
              f'<sheets>{wb_sheets}</sheets></workbook>')
        rels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
        for i in range(len(self.hojas)):
            rels.append(f'<Relationship Id="rId{i+1}" Type="http://schemas.openxmlformats.org/'
                        f'officeDocument/2006/relationships/worksheet" '
                        f'Target="worksheets/sheet{i+1}.xml"/>')
        rels.append(f'<Relationship Id="rId{len(self.hojas)+1}" Type="http://schemas.'
                    'openxmlformats.org/officeDocument/2006/relationships/styles" '
                    'Target="styles.xml"/></Relationships>')

        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("[Content_Types].xml", _CONTENT_TYPES.format(sheets=hojas_ct))
            z.writestr("_rels/.rels", _RELS)
            z.writestr("xl/workbook.xml", wb)
            z.writestr("xl/_rels/workbook.xml.rels", "".join(rels))
            z.writestr("xl/styles.xml", _STYLES)
            for i, h in enumerate(self.hojas):
                z.writestr(f"xl/worksheets/sheet{i+1}.xml", self._xml_hoja(h))
        if cerrar:
            buffer.close()

    def a_bytes(self) -> bytes:
        buf = BytesIO()
        self.guardar(buf)
        return buf.getvalue()
