# Manual de uso diario

## Entrar

Abrir `http://localhost:8080`, poner usuario y contrasena. El sistema abre
directo en **Vender** si la persona tiene permiso de venta.

## Teclas rapidas

| Tecla | Seccion |
|---|---|
| F1 | Panel |
| F2 | Vender |
| F3 | Comprar |
| F4 | Productos |
| F5 | Stock |
| F6 | Precios |
| F7 | Reportes y Excel |
| F12 | Cobrar (en Vender) |
| Esc | Cerrar la ventana emergente |

---

## Vender

1. Escanear el producto (o escribir parte del nombre) y presionar **Enter**.
2. El producto se suma al carrito. Escanear dos veces suma dos unidades; tambien
   se puede escribir la cantidad en la columna Cantidad.
3. Elegir forma de pago y, si hace falta, cargar un descuento general.
4. **Cobrar** o F12. El sistema descuenta el stock, numera el comprobante y
   muestra el ticket para imprimir.

Si un producto no tiene precio cargado o no hay stock suficiente, avisa y **no
registra nada**: la venta entra completa o no entra.

---

## Comprar (cuando llega la mercaderia)

1. Elegir el proveedor.
2. Escanear cada producto del pedido. Si ya existe, aparece con su costo y
   precio actuales; si es nuevo, se abre el alta rapida (nombre, categoria,
   costo, precio) y queda cargado para siempre.
3. Poner **cuantas unidades entraron**, el costo unitario y, si cambia, el
   precio de venta. A la derecha se ve en vivo el costo total del pedido, el
   valor de venta, la ganancia potencial y el margen promedio.
4. **Registrar compra**: suma el stock, guarda el nuevo costo y recalcula el
   precio de venta de los productos con margen automatico.

Ejemplo: Coca-Cola 2,25 L, 30 unidades, costo $1.500, venta $2.200 →
costo total $45.000, valor de venta $66.000, ganancia potencial $21.000,
margen 46,7%.

---

## Productos

Buscar por nombre, codigo o marca; filtrar por categoria, stock bajo, sin stock
o inactivos. En **Ver** aparece la ficha completa: stock, costo, margen,
ultimas compras con el precio pagado, historial de precios y movimientos de
stock.

En el alta o edicion se cargan codigo de barras, QR, marca, categoria,
subcategoria, unidad, stock minimo, IVA, proveedor y el margen propio. Si se
deja el margen vacio, el producto usa el de la marca, el de la categoria o el
general, en ese orden.

Los productos no se borran: se **desactivan** (asi no se pierde el historial de
ventas).

---

## Stock

- Indicadores de valor del inventario a costo, a venta y ganancia potencial.
- Lista de productos criticos (sin stock o en el minimo).
- **Ajustar**: se pone el stock realmente contado y un motivo obligatorio
  (rotura, vencimiento, error de carga). Queda registrado quien y cuando.
- **Devolucion**: las unidades que devuelve un cliente vuelven al inventario.
- Movimientos: todo lo que entro y salio, con filtro por fecha y tipo.

El sistema nunca deja stock negativo.

---

## Precios (aumentos)

1. Cargar el porcentaje.
2. Elegir si aplica sobre el **costo**, el **precio de venta** o **ambos**.
   Si se aplica solo sobre el costo, el precio de venta se recalcula solo segun
   el margen de cada producto.
3. Elegir el alcance: todos, una categoria, un proveedor o una marca.
4. **Ver vista previa**: muestra producto por producto el precio anterior y el
   nuevo. Hasta aca no se modifico nada.
5. **Confirmar**. Cada cambio queda en el historial con valor anterior, nuevo,
   porcentaje, motivo, usuario y fecha. Ese historial no se pisa nunca.

Tambien esta **Recalcular ventas por margen**, para dejar los precios alineados
con el margen configurado sin aplicar ningun aumento.

---

## Proveedores

Datos de contacto, productos asociados, compras realizadas y el **ultimo precio
pagado por cada producto**, para comparar cuando llega una lista nueva.

---

## Reportes y Excel

- Resumen del periodo: comprobantes, total vendido, costo de lo vendido y
  ganancia.
- Margen por categoria.
- Listado de ventas con opcion de ver el detalle, reimprimir el ticket o
  **anular** (la anulacion devuelve el stock).
- **Descargar Excel**: se eligen las planillas (Resumen, Stock, Ventas,
  Compras, Movimientos, Historial de precios) y el periodo (hoy, ayer, semana,
  mes, ano, todo o un rango de fechas). El archivo es un .xlsx real que abre en
  Excel, LibreOffice o Google Sheets.

---

## Usuarios y permisos

Roles que vienen cargados:

| Rol | Que puede hacer |
|---|---|
| Administrador | Todo |
| Encargado | Todo menos usuarios y configuracion del negocio |
| Vendedor | Vender y consultar productos. **No** cambia precios ni stock |
| Consulta | Solo mirar productos y reportes |

Los permisos de cada rol se editan con casilleros en Usuarios > Permisos por
rol. En **Historial** queda registrado cada movimiento: usuario, fecha, hora,
operacion, producto y valores anterior y nuevo.

---

## Configuracion

Todo lo del negocio se guarda en la base: nombre, direccion, telefono, CUIT,
condicion fiscal, moneda y separadores, margen por defecto, redondeo de precios
(por ejemplo, a multiplos de $10), IVA, recalculo automatico al cambiar el
costo, datos de facturacion e impresora, alertas y copias de seguridad.

También se administran desde ahi las formas de pago, los margenes por categoria
y las copias de seguridad.

## Rutina recomendada

- **Al abrir**: revisar el Panel (avisos de stock y ventas del dia).
- **Cuando llega mercaderia**: usar Comprar, nunca editar el stock a mano.
- **Cuando llega una lista nueva de precios**: Precios > vista previa >
  confirmar.
- **Al cerrar**: mirar ventas y ganancia del dia; una vez por semana, descargar
  el Excel y verificar que la copia de seguridad este en el pendrive o la nube.
