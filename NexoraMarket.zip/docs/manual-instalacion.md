# Manual de instalacion

## 1. Requisitos

- Una PC con Windows 10/11 o Linux.
- **Python 3.10 o superior**. Nada mas: el sistema no usa librerias externas.
  - Windows: descargar de python.org y **tildar "Add Python to PATH"** durante
    la instalacion.
  - Linux (Ubuntu/Debian): `sudo apt install python3`
- Un navegador (Chrome, Edge o Firefox).
- Opcional: lector de codigos de barras/QR USB. Funcionan tal cual porque se
  comportan como un teclado (escriben el codigo y mandan Enter).

Verificar la instalacion de Python:

```bash
python --version      # Windows
python3 --version     # Linux
```

## 2. Copiar el sistema

Descomprimir la carpeta `minimarket` donde vaya a quedar, por ejemplo
`C:\minimarket` o `/opt/minimarket`. Abrir una terminal ahi:

- Windows: entrar a la carpeta, escribir `cmd` en la barra de direcciones y Enter.
- Linux: `cd /opt/minimarket`

## 3. Crear la base de datos y el usuario administrador

```bash
python run.py iniciar-base --negocio "Almacen Don Jose"
```

Pide la contrasena del administrador (Enter deja `admin1234`). Esto crea:

- `datos/minimarket.db` con todas las tablas,
- roles y permisos (Administrador, Encargado, Vendedor, Consulta),
- unidades, formas de pago y categorias con margenes sugeridos,
- el usuario `admin`.

Para probar con productos de ejemplo:

```bash
python run.py iniciar-base --negocio "Almacen Don Jose" --demo
```

> **Cambiar la contrasena del administrador** apenas se entra la primera vez
> (Usuarios > admin > Editar).

## 4. Iniciar el sistema

```bash
python run.py servidor
```

Abrir `http://localhost:8080` en el navegador.

Opciones utiles:

```bash
python run.py servidor --puerto 9000      # otro puerto
python run.py servidor --red              # acceder desde otras PC del local
```

Con `--red`, el sistema muestra la direccion IP para usar desde otra
computadora o una tablet conectada a la misma red: `http://192.168.0.X:8080`.

## 5. Que cargar la primera vez

1. **Configuracion**: nombre, direccion, telefono, CUIT, condicion fiscal,
   simbolo de moneda, margen por defecto y redondeo de precios.
2. **Formas de pago**: activar o desactivar las que use el negocio y cargar
   recargos si corresponde.
3. **Categorias**: ajustar el margen % de cada una (de ahi sale el precio de
   venta sugerido).
4. **Proveedores**.
5. **Productos**: con el lector, desde Comprar (alta rapida) o desde Productos >
   Nuevo producto.
6. **Usuarios**: crear una cuenta por persona con su rol.

## 6. Arranque automatico (opcional)

**Windows** — crear un archivo `iniciar.bat` en la carpeta del sistema:

```bat
@echo off
cd /d %~dp0
start "" http://localhost:8080
python run.py servidor
```

Poner un acceso directo en el Escritorio, o en
`shell:startup` para que arranque con Windows.

**Linux (systemd)** — `/etc/systemd/system/minimarket.service`:

```ini
[Unit]
Description=Sistema de gestion minimarket
After=network.target

[Service]
WorkingDirectory=/opt/minimarket
ExecStart=/usr/bin/python3 /opt/minimarket/run.py servidor --red
Restart=always
User=minimarket

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now minimarket
```

## 7. Copias de seguridad

- El sistema crea una copia automatica por dia al iniciar (se puede desactivar).
- Manual: `python run.py backup` o el boton en Configuracion.
- Carpeta: `datos/backups/` o la que se indique en `backup.directorio`
  (conviene apuntar a un pendrive o carpeta de la nube).
- Restaurar: `python run.py restaurar NOMBRE-DEL-ARCHIVO.db` o desde
  Configuracion. Antes de restaurar, el sistema guarda una copia del estado
  actual por las dudas.
- Ver copias disponibles: `python run.py backups`.

## 8. Comandos disponibles

| Comando | Para que sirve |
|---|---|
| `python run.py iniciar-base [--demo] [--negocio N] [--usuario U] [--password P]` | Crea la base y el admin |
| `python run.py servidor [--puerto N] [--red] [--verbose]` | Inicia el sistema |
| `python run.py usuario NOMBRE --rol Vendedor` | Crea un usuario desde la terminal |
| `python run.py backup` / `backups` / `restaurar ARCHIVO` | Copias de seguridad |
| `python run.py pruebas` | Corre las 34 pruebas automaticas |
| `python run.py --db /ruta/otra.db servidor` | Usar otra base (o variable `MINIMARKET_DB`) |

## 9. Problemas frecuentes

| Sintoma | Solucion |
|---|---|
| `python no se reconoce como un comando` | Reinstalar Python tildando "Add Python to PATH" |
| `La base no existe` | Correr primero `python run.py iniciar-base` |
| El puerto esta ocupado | `python run.py servidor --puerto 9000` |
| Otra PC no entra al sistema | Iniciar con `--red` y permitir Python en el firewall |
| El lector escribe el codigo pero no pasa nada | Hacer clic en el campo "Codigo" para que tenga el foco |
| La impresora no imprime | Configuracion > puerto de la impresora (`COM1`, `/dev/usb/lp0`). El estado del adaptador se muestra ahi mismo |
