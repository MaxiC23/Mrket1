#!/usr/bin/env python3
"""Punto de entrada del sistema.

Uso:
  python run.py iniciar-base            Crea la base y el usuario administrador
  python run.py iniciar-base --demo     Ademas carga productos de ejemplo
  python run.py servidor                Levanta el sistema (http://localhost:8080)
  python run.py servidor --red          Permite el acceso desde otras PC de la red
  python run.py backup                  Crea una copia de seguridad
  python run.py restaurar NOMBRE        Restaura una copia
  python run.py usuario ALTA            Crea un usuario
  python run.py pruebas                 Ejecuta las pruebas automaticas
"""
from __future__ import annotations

import argparse
import getpass
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app import db, seed, security, server  # noqa: E402
from app.services import backup as backup_srv  # noqa: E402


def main(argv=None) -> int:
    # Modo app instalada: al hacer doble clic sobre el .exe se levanta solo el
    # sistema en toda la red local (sin pedir comandos) y se abre el navegador.
    if getattr(sys, "frozen", False) and argv is None:
        import threading
        import webbrowser
        threading.Timer(2.0, lambda: webbrowser.open("http://localhost:8080")).start()
        argv = ["servidor", "--red"]
    p = argparse.ArgumentParser(description="Sistema de gestion de minimercado")
    p.add_argument("--db", help="Ruta de la base de datos")
    sub = p.add_subparsers(dest="comando", required=True)

    s = sub.add_parser("iniciar-base", help="Crea la base y los datos iniciales")
    s.add_argument("--usuario", default="admin")
    s.add_argument("--password", default=None)
    s.add_argument("--negocio", default=None, help="Nombre del comercio")
    s.add_argument("--demo", action="store_true", help="Cargar productos de ejemplo")

    s = sub.add_parser("servidor", help="Inicia el sistema")
    s.add_argument("--puerto", type=int, default=8080)
    s.add_argument("--red", action="store_true", help="Escuchar en toda la red local")
    s.add_argument("--verbose", action="store_true")

    sub.add_parser("backup", help="Crea una copia de seguridad")
    s = sub.add_parser("restaurar", help="Restaura una copia de seguridad")
    s.add_argument("nombre")
    sub.add_parser("backups", help="Lista las copias disponibles")

    s = sub.add_parser("usuario", help="Crea un usuario")
    s.add_argument("nombre_usuario")
    s.add_argument("--rol", default="Vendedor")
    s.add_argument("--password", default=None)

    sub.add_parser("pruebas", help="Ejecuta las pruebas automaticas")

    args = p.parse_args(argv)
    if args.db:
        db.set_db_path(args.db)

    if args.comando == "iniciar-base":
        password = args.password or getpass.getpass(
            "Contrasena del administrador (Enter = admin1234): ") or "admin1234"
        res = seed.inicializar(args.usuario, password, args.negocio)
        print(f"Base lista en {db.get_db_path()}")
        if res["admin_creado"]:
            print(f"Usuario administrador: {args.usuario}")
        else:
            print("Ya existian usuarios: no se creo ninguno nuevo.")
        if args.demo:
            print("Datos de ejemplo:", seed.datos_demo())
        return 0

    if args.comando == "servidor":
        if not db.get_db_path().exists():
            if getattr(sys, "frozen", False):
                # primera vez con el .exe: crear la base (admin / admin1234)
                seed.inicializar()
            else:
                print("La base no existe. Ejecuta primero: python run.py iniciar-base")
                return 1
        server.iniciar("0.0.0.0" if args.red else "127.0.0.1", args.puerto,
                       args.verbose)
        return 0

    if args.comando == "backup":
        db.inicializar()
        print(backup_srv.crear("manual"))
        return 0

    if args.comando == "backups":
        for b in backup_srv.listar():
            print(f"{b['fecha']}  {b['nombre']}  ({b['bytes'] / 1024:.0f} KB)")
        return 0

    if args.comando == "restaurar":
        db.inicializar()
        print(backup_srv.restaurar(args.nombre))
        return 0

    if args.comando == "usuario":
        db.inicializar()
        password = args.password or getpass.getpass("Contrasena: ")
        uid = security.crear_usuario(args.nombre_usuario, args.nombre_usuario,
                                     password, args.rol)
        print(f"Usuario creado (id {uid}) con rol {args.rol}")
        return 0

    if args.comando == "pruebas":
        cargador = unittest.TestLoader()
        suite = cargador.discover("tests")
        res = unittest.TextTestRunner(verbosity=2).run(suite)
        return 0 if res.wasSuccessful() else 1

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
