@echo off
title Armar instalador .exe (PyInstaller)
cd /d "%~dp0.."
setlocal

set "PY_EXE="
where python >nul 2>nul && set "PY_EXE=python"
if not defined PY_EXE (
  if exist "%LocalAppData%\Programs\Python\Python313\python.exe" (
    set "PY_EXE=%LocalAppData%\Programs\Python\Python313\python.exe"
  )
)
if not defined PY_EXE (
  echo   No se encontro Python. Instalalo desde python.org e intente de nuevo.
  pause & exit /b 1
)

echo   Verificando PyInstaller...
"%PY_EXE%" -c "import PyInstaller" >nul 2>nul
if errorlevel 1 (
  echo   Descargando PyInstaller (solo la primera vez)...
  "%PY_EXE%" -m pip install --upgrade pyinstaller
  if errorlevel 1 ( echo   No se pudo instalar PyInstaller. & pause & exit /b 1 )
)

echo   Regenerando iconos...
"%PY_EXE%" scripts\generar_iconos.py

echo.
echo   Compilando (puede tardar un minuto)...
"%PY_EXE%" -m PyInstaller --noconfirm --clean --onefile --console ^
  --name Minimercado ^
  --icon web\Minimercado.ico ^
  --add-data "web;web" ^
  --add-data "app\schema.sql;app" ^
  --hidden-import app.seed ^
  --hidden-import app.services.backup ^
  run.py
if errorlevel 1 ( echo   Fallo la compilacion. & pause & exit /b 1 )

echo.
echo   LISTO: dist\Minimercado.exe
echo   Copialo a donde quieras: al abrirlo crea "datos" a su lado y abre el
echo   navegador. Usuario inicial: admin / admin1234.
pause