"""Genera los iconos PNG de la app (192, 512 y 180) sin dependencias.

Rasteriza la "M" del logotipo sobre un fondo verde degradado, con
super-muestreo 4x para bordes suaves, y escribe PNG estandar (zlib + CRC32).
Uso:  python scripts/generar_iconos.py
"""
import struct
import zlib
from pathlib import Path

VERDE   = (20, 83, 45)      # #14532d
VERDE2  = (31, 108, 62)     # #1f6c3e
BLANCO  = (255, 255, 255, 255)
FONDO   = (244, 246, 243, 255)

BASE = Path(__file__).resolve().parent.parent / "web"


def _dist_segmento(px, py, ax, ay, bx, by):
    vx, vy = bx - ax, by - ay
    wx, wy = px - ax, py - ay
    largo2 = vx * vx + vy * vy
    t = max(0.0, min(1.0, (wx * vx + wy * vy) / largo2)) if largo2 else 0.0
    cx, cy = ax + t * vx, ay + t * vy
    return ((px - cx) ** 2 + (py - cy) ** 2) ** 0.5


def _color_pixel(px, py, n):
    """Devuelve RGBA ya resuelto, segun la forma dibujada en un cuadrado 0..1."""
    if px < 0 or px > 1 or py < 0 or py > 1:
        return FONDO
    # esquinas redondeadas (radio 0.22)
    r = 0.22
    if (
        (px <= r and py <= r and (px - r) ** 2 + (py - r) ** 2 > r * r)
        or (px >= 1 - r and py <= r
            and (px - (1 - r)) ** 2 + (py - r) ** 2 > r * r)
        or (px <= r and py >= 1 - r
            and (px - r) ** 2 + (py - (1 - r)) ** 2 > r * r)
        or (px >= 1 - r and py >= 1 - r
            and (px - (1 - r)) ** 2 + (py - (1 - r)) ** 2 > r * r)
    ):
        return FONDO
    # fondo: degradado vertical
    g = int(VERDE[1] + (VERDE2[1] - VERDE[1]) * py)
    base = (VERDE[0], g, VERDE2[2], 255)
    # halo suave arriba-izquierda
    dist_esq = ((px - 0.05) ** 2 + (py - 0.05) ** 2) ** 0.5
    if dist_esq < 0.55:
        base = (min(255, base[0] + 14), min(255, base[1] + 18), min(255, base[2] + 10), 255)
    # forma "M" blanca: trazos gruesos con centro abierto
    trazos = [
        (0.235, 0.30, 0.235, 0.72),   # palo izquierdo
        (0.765, 0.30, 0.765, 0.72),   # palo derecho
        (0.235, 0.30, 0.50, 0.72),    # diagonal izquierda
        (0.765, 0.30, 0.50, 0.72),    # diagonal derecha
    ]
    ancho = 0.105
    for (ax, ay, bx, by) in trazos:
        if _dist_segmento(px, py, ax, ay, bx, by) <= ancho / 2:
            return BLANCO
        # bisel sutil para dar volumen
        if _dist_segmento(px, py, ax, ay, bx, by) <= ancho / 2 + 0.022:
            return (230, 238, 232, 255)
    # remate inferior: linea horizontal
    if 0.225 <= px <= 0.775 and abs(py - 0.72) <= 0.045:
        return BLANCO
    return base


def _render(tam, ss=4):
    pix = []
    for py in range(tam):
        for px in range(tam):
            r = g = b = a = 0
            for sy in range(ss):
                for sx in range(ss):
                    u = (px + (sx + 0.5) / ss) / tam
                    v = (py + (sy + 0.5) / ss) / tam
                    c = _color_pixel(u, v, tam)
                    r += c[0]; g += c[1]; b += c[2]; a += c[3]
            total = ss * ss
            pix.append((r // total, g // total, b // total, a // total))
    return pix


def _png(tam, pix):
    filas = b""
    for py in range(tam):
        fila = b"\x00"
        for px in range(tam):
            fila += bytes(pix[py * tam + px])
        filas += fila
    datos = zlib.compress(filas, 9)
    def chunk(tipo, datos_):
        crc = zlib.crc32(tipo + datos_) & 0xFFFFFFFF
        return struct.pack(">I", len(datos_)) + tipo + datos_ + struct.pack(">I", crc)
    ihdr = struct.pack(">IIBBBBB", tam, tam, 8, 6, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr)
            + chunk(b"IDAT", datos) + chunk(b"IEND", b""))


def _icono_ico(png_256: bytes) -> bytes:
    """Envuelve un PNG de 256x256 en un contenedor ICO (Windows Vista+)."""
    cabecera = struct.pack("<HHH", 0, 1, 1)
    entrada = struct.pack("<BBBBHHII", 0, 0, 0, 0, 1, 32, len(png_256), 22)
    return cabecera + entrada + png_256


def principal():
    for tam in (192, 512, 180, 256):
        pix = _render(tam)
        ruta = BASE / f"icon-{tam}.png"
        ruta.write_bytes(_png(tam, pix))
        print(f"  generado {ruta.name} ({ruta.stat().st_size / 1024:.1f} KB)")
    png256 = (BASE / "icon-256.png").read_bytes()
    ico = BASE / "Minimercado.ico"
    ico.write_bytes(_icono_ico(png256))
    print(f"  generado {ico.name} ({ico.stat().st_size / 1024:.1f} KB)")


if __name__ == "__main__":
    principal()