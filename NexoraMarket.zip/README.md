# Sistema de gestion para minimercado / almacen / drugstore

Sistema completo y funcional: punto de venta con lector de codigos, control de
stock, compras, actualizacion masiva de precios con vista previa, control de
costos y ganancias, proveedores, reportes en Excel real (.xlsx), usuarios con
permisos, auditoria, copias de seguridad y una capa de facturacion
intercambiable.

- Version: 1.2.0
- Estado: 42 pruebas automaticas en verde (`python run.py pruebas`)
- Ademas del codigo fuente hay una **version instalada** para Windows: ver seccion 9

---

## 1. Tecnologias y por que

| Capa | Eleccion | Motivo |
|---|---|---|
| Lenguaje | Python 3.10+ | Viene con todo lo necesario, corre igual en Windows y Linux, facil de mantener |
| Base de datos | SQLite 3 (modo WAL) | Relacional, transaccional (ACID), un solo archivo facil de respaldar y copiar. El esquema es SQL estandar: migrar a PostgreSQL/MySQL despues es directo |
| Servidor / API | `http.server` (ThreadingHTTPServer) de la libreria estandar | API REST JSON sin instalar nada. La PC del negocio solo necesita Python |
| Interfaz | HTML + CSS + JavaScript sin frameworks | Abre en cualquier navegador, sin compilar, sin npm, arranca instantaneo en PC modestas. Es adaptable a celular y se puede instalar como app (PWA) |
| Excel | Escritor OOXML propio (`app/xlsx.py`, usa `zipfile` + XML) | Genera archivos .xlsx reales, sin depender de openpyxl ni de internet |
| Seguridad | PBKDF2-SHA256 (200.000 iteraciones) + tokens de sesion | Contrasenas nunca guardadas en texto plano |

**Cero dependencias externas.** No hace falta pip, ni npm, ni internet en la PC
del comercio. Se instala Python y funciona.

**Importes en centavos.** Todo el dinero se guarda como enteros (centavos) y se
calcula con `Decimal` + redondeo ROUND_HALF_UP. Nunca aparecen errores del tipo
`0.1 + 0.2 = 0.30000000000000004`.

---

## 2. Arquitectura

```
   Navegador (PC del mostrador)          Lector de codigos (actua como teclado)
   web/index.html + app.js + vistas.js            |
                 |  fetch JSON / Bearer token     v
                 v                         campo "Codigo" del POS
        +--------------------------+
        |   app/server.py          |  HTTP + estaticos + errores + descargas
        +--------------------------+
        |   app/api.py             |  tabla de rutas -> permiso -> handler
        +--------------------------+
        |   app/security.py        |  login, sesiones, permisos por rol
        +--------------------------+
        |   app/services/*         |  REGLAS DE NEGOCIO
        |   productos  compras     |
        |   ventas     stock       |
        |   precios    reportes    |
        |   proveedores config     |
        |   facturacion  backup    |
        +--------------------------+
        |   app/db.py              |  conexiones, transacciones, dinero
        +--------------------------+
        |   SQLite (datos/minimarket.db)  |
        +--------------------------+
```

Reglas estructurales que sostienen la consistencia:

1. **El stock solo cambia por `services/stock.mover()`**, siempre dentro de una
   transaccion y dejando el movimiento registrado. No hay ningun `UPDATE
   productos SET stock` suelto en el codigo.
2. **Una venta es una sola transaccion**: cabecera + items + descuento de stock.
   Si falta stock de cualquier item, se revierte todo y no queda ni la venta ni
   el movimiento. La tabla ademas tiene `CHECK (stock >= 0)`.
3. **El historial de precios nunca se sobrescribe**: cada cambio agrega una fila
   nueva con valor anterior, valor nuevo, porcentaje, motivo, usuario y fecha.
4. **Nada del negocio esta hardcodeado**: nombre, CUIT, logo, moneda, margenes,
   impresora y datos fiscales viven en la tabla `config`.

---

## 3. Diagrama de la base de datos

```
 roles ---< rol_permiso >--- permisos
   |
   ^
 usuarios ---< sesiones
   |  \
   |   \----------------------------< auditoria
   |    \---------------------------< movimientos_stock
   |     \--------------------------< precios_historial
   |
 categorias ---< subcategorias              proveedores
   |                  |                        |
   +------------------+------------+-----------+
                                   |
   marcas ------------------------ productos ----------------+
   unidades ---------------------- (stock, costo, precio,    |
                                    margen, iva, activo)     |
                                     |      |     |          |
             +-----------------------+      |     +----------+------------+
             |                              |                             |
        compra_items                  venta_items                 movimientos_stock
             |                              |                       (compra/venta/
          compras                        ventas ---< comprobantes    ajuste/devolucion/
      (proveedor, total)          (numero, total, costo_total,        anulacion/alta)
                                   forma_pago, estado)
                                          |
                                     formas_pago
       config (clave/valor)
```

Tablas (21): `config`, `roles`, `permisos`, `rol_permiso`, `usuarios`,
`sesiones`, `categorias`, `subcategorias`, `marcas`, `unidades`, `proveedores`,
`formas_pago`, `productos`, `precios_historial`, `compras`, `compra_items`,
`ventas`, `venta_items`, `movimientos_stock`, `comprobantes`, `auditoria`.
Todas con clave primaria, claves foraneas, indices en los campos de busqueda y
restricciones `CHECK` (stock no negativo, cantidades mayores a cero, precios no
negativos, estados validos). Ver `app/schema.sql`.

---

## 4. Estructura de carpetas

```
minimarket/
  run.py                  Comandos: iniciar-base, servidor, backup, restaurar, pruebas
  Minimercado.exe         Version instalada (Windows, lista para usar, opcional)
  README.md               Este documento
  "Iniciar Minimercado (PC y celulares).bat"   Doble clic para levantar todo
  "Ver IP para el celular.bat"                 Muestra la direccion para el telefono
  scripts/
    generar_iconos.py     Regenera web/icon-*.png y web/Minimercado.ico
    armar_exe.bat         Compila Minimercado.exe con PyInstaller
  dist/                   Resultado de la compilacion del .exe
  docs/
    manual-instalacion.md
    manual-uso.md
  app/
    schema.sql            Esquema completo de la base
    db.py                 Conexion, transacciones, helpers de dinero
    security.py           Contrasenas, sesiones, permisos
    audit.py              Registro de auditoria
    xlsx.py               Generador de Excel (.xlsx) propio
    seed.py               Datos iniciales y datos de ejemplo
    api.py                Tabla de rutas de la API REST
    server.py             Servidor HTTP
    services/
      config.py           Configuracion del negocio
      productos.py        Alta rapida, busqueda por codigo, catalogos
      stock.py            Movimientos, ajustes, devoluciones, alertas
      compras.py          Compras a proveedores
      ventas.py           Punto de venta, totales, anulaciones
      precios.py          Margenes, aumentos con vista previa e historial
      proveedores.py      Proveedores y ultimos precios pagados
      reportes.py         Dashboard, control de costos, exportacion Excel
      facturacion.py      Capa de adaptadores de facturacion
      backup.py           Copias de seguridad y restauracion
  web/
    index.html  estilos.css  app.js  vistas.js
    manifest.json  sw.js  icon-192.png  icon-512.png  icon-180.png  icon-256.png
    Minimercado.ico
  tests/
    test_sistema.py       42 pruebas automaticas
  datos/                  Se crea sola: base, backups y comprobantes
```

---

## 5. Flujo de funcionamiento

**Compra (entrada de mercaderia).** Se escanea el producto. Si existe, aparece y
solo se completan cantidad, costo y precio; si no existe, se da de alta en el
momento. Al confirmar, en una sola transaccion: se crea la compra, se suman las
unidades al stock, se registra el movimiento, se actualiza el ultimo costo y,
si el producto tiene margen automatico, se recalcula el precio de venta y se
guarda el cambio en el historial.

**Venta.** Se escanea, se arma el carrito, se elige forma de pago y se cobra.
En una transaccion: se numera el comprobante, se guardan los items con precio y
costo del momento (para calcular la ganancia real despues), se descuenta el
stock y se emite el comprobante segun el adaptador configurado.

**Aumento de precios.** Se elige porcentaje, si aplica sobre costo, venta o
ambos, y el alcance (todos, categoria, proveedor, marca o productos elegidos).
El sistema muestra la **vista previa** con precio anterior y nuevo de cada
producto **sin tocar nada**. Recien al confirmar se aplica, con un `lote_id` que
agrupa el aumento y una fila de historial por cada cambio.

**Reportes.** Dashboard en vivo (ventas del dia/semana/mes con tendencia versus
el dia anterior, caja, valor de inventario, alertas, mas vendidos, margen por
categoria, grafico de 30 dias y distribucion por forma de pago) y exportacion
a Excel de Resumen, Stock, Ventas, Compras, Movimientos e Historial de precios,
por dia, semana, mes, ano o rango de fechas.

---

## 6. Facturacion (importante)

No se invento ninguna integracion. Lo que hay es una **capa de adaptadores**:

- `ticket_interno` (funciona): comprobante interno no fiscal, se guarda en
  `datos/comprobantes/` y se puede imprimir desde el navegador.
- `impresora_escpos` (funciona): envia el ticket en ESC/POS al puerto
  configurado (`/dev/usb/lp0`, `COM1`, etc.).
- `fiscal_externo` (a completar): clase documentada donde se conecta la
  facturadora o el servicio de facturacion electronica real. Mientras no este
  implementada, devuelve un error claro (501) en vez de simular una emision.

Para conectar el proveedor real se escribe una clase que herede de
`AdaptadorFacturacion`, se implementa `emitir()` y se registra con
`registrar_adaptador()`. El resto del sistema no cambia: el resultado se guarda
igual en la tabla `comprobantes` (numero, CAE, vencimiento, estado).

---

## 7. Instalacion rapida

```bash
python run.py iniciar-base --negocio "Mi Almacen"   # agrega --demo para datos de ejemplo
python run.py servidor                              # http://localhost:8080
```

Sin Python no hace falta nada: usar la version instalada (seccion 9).

Detalle completo en `docs/manual-instalacion.md`. Uso diario en
`docs/manual-uso.md`.

---

## 8. Uso desde el celular

La misma interfaz sirve en la PC y en el celular, sin instalar nada aparte:

- **Diseno adaptable.** En pantallas grandes se ve el menu lateral completo; en
  el tablet queda solo con iconos; en el celular el menu se abre con el boton
  de arriba y aparece una barra inferior con Panel, Vender, Comprar, Productos y
  Stock. El total del punto de venta queda siempre visible mientras se cobra.
- **App instalable (PWA).** El servidor incluye `web/manifest.json`, el service
  worker `web/sw.js` y los iconos. Desde el navegador del celular se puede
  elegir "Agregar a pantalla de inicio" y el sistema queda como una app en
  pantalla completa, sin la barra del navegador.
- **Como conectarse.** En la PC del negocio hay dos formas: doble clic en
  `Iniciar Minimercado (PC y celulares).bat` (levanta todo y abre el navegador)
  o `python run.py servidor --red`. El celular tiene que estar en la misma red
  Wi-Fi y se abre `http://IP-DE-LA-PC:8080`; la IP se muestra al iniciar y
  tambien en la pantalla de ingreso ("¿Usar desde tu celular?"). Si el negocio
  no tiene PC, el sistema tambien corre en el propio celular con Termux o en
  una mini PC, y el telefono se usa como terminal de venta.
- **La API nunca se cachea.** El service worker guarda solo la interfaz; las
  ventas, el stock y los precios siempre se leen y escriben en el servidor, asi
  que no hay riesgo de vender contra datos viejos.

## 9. Version instalada (.exe) para Windows

Si la PC del negocio no tiene Python (o no se quiere instalar nada), se usa la
**version instalada**: `Minimercado.exe`, un unico archivo que ya incluye el
servidor, la interfaz y la base. No necesita pip, npm ni internet.

- **Como se usa.** Doble clic en `Minimercado.exe`. Solo, abre el navegador en
  `http://localhost:8080` y levanta el sistema en la red local (celulares).
  La primera vez crea `datos\` a su lado con el usuario `admin` / `admin1234`.
- **Los datos quedan al lado del .exe.** La base, los backups y los comprobantes
  se guardan en `datos\` dentro de la misma carpeta, asi copiar toda la
  informacion es copiar esa carpeta (o el propio .exe con ella). No toca la
  instalacion de Python.
- **Con el lanzador.** `Iniciar Minimercado (PC y celulares).bat` detecta si
  existe `Minimercado.exe` y lo usa; si no, cae a Python. Es la forma mas simple
  en cualquier caso.
- **Como se compila.** Doble clic en `scripts\armar_exe.bat`: descarga
  PyInstaller la primera vez y genera `dist\Minimercado.exe` con la interfaz y
  el esquema embebidos. El icono tambien se regenera ahi (`web/Minimercado.ico`).

## 10. Pruebas automaticas

```bash
python run.py pruebas
```

Cubren: alta de productos y codigos duplicados, busqueda por codigo de barras,
compra que suma stock y actualiza costo, venta que descuenta stock, venta sin
stock suficiente que se revierte por completo, **15 ventas concurrentes sin
dejar stock negativo ni inconsistente**, anulacion que devuelve stock, IVA
discriminado, vista previa que no modifica nada, aumentos por categoria,
recalculo por margen, historial que nunca se pisa, redondeo configurable,
ajustes y devoluciones, permisos por rol (un vendedor no puede cambiar precios),
generacion y validez del .xlsx, ticket interno, adaptador fiscal no
implementado, backup y restauracion, configuracion persistida y el flujo
completo por HTTP (login, alta, compra, venta, dashboard y descarga de Excel).
