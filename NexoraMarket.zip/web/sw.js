/* Service worker del sistema de gestion.
   Deja la interfaz (HTML/CSS/JS/iconos) disponible y la app instalable en el
   celular. La API NUNCA se cachea: ventas, stock y precios siempre viven en el
   servidor. Los estaticos usan "stale-while-revalidate": abren al instante y se
   refrescan solos en segundo plano cuando hay una version nueva. */
const CACHE = 'minimarket-v3';
const ESTATICOS = [
  './',
  './index.html',
  './estilos.css',
  './app.js',
  './vistas.js',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './icon-180.png',
];

self.addEventListener('install', (evento) => {
  evento.waitUntil(
    caches.open(CACHE)
      .then((c) => c.addAll(ESTATICOS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (evento) => {
  evento.waitUntil(
    caches.keys()
      .then((claves) => Promise.all(
        claves.filter((k) => k !== CACHE).map((k) => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (evento) => {
  const peticion = evento.request;
  if (peticion.method !== 'GET') return;
  const url = new URL(peticion.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/')) return;

  if (peticion.mode === 'navigate') {
    evento.respondWith(
      fetch(peticion).then((respuesta) => {
        const copia = respuesta.clone();
        caches.open(CACHE).then((c) => c.put('./index.html', copia));
        return respuesta;
      }).catch(() => caches.match('./index.html'))
    );
    return;
  }

  evento.respondWith(
    caches.match(peticion).then((enCache) => {
      const desdeLaRed = fetch(peticion).then((respuesta) => {
        if (respuesta && respuesta.ok) {
          const copia = respuesta.clone();
          caches.open(CACHE).then((c) => c.put(peticion, copia));
        }
        return respuesta;
      }).catch(() => enCache);
      return enCache || desdeLaRed;
    })
  );
});
