/* Nucleo de la interfaz: sesion, llamadas a la API, navegacion y utilidades. */

const Estado = {
  token: localStorage.getItem('mm_token') || '',
  usuario: null,
  config: {},
  catalogos: { categorias: [], subcategorias: [], marcas: [], unidades: [] },
  formasPago: [],
  vista: 'panel',
  carrito: [],
  compra: [],
};

/* ----------------------------- API --------------------------------- */
async function api(ruta, opciones = {}) {
  const cfg = { method: opciones.method || 'GET', headers: {} };
  if (Estado.token) cfg.headers['Authorization'] = 'Bearer ' + Estado.token;
  if (opciones.body !== undefined) {
    cfg.headers['Content-Type'] = 'application/json';
    cfg.body = JSON.stringify(opciones.body);
  }
  const r = await fetch(ruta, cfg);
  let datos = null;
  try { datos = await r.json(); } catch (e) { datos = null; }
  if (!r.ok) {
    if (r.status === 401 && Estado.usuario) cerrarSesion(true);
    throw new Error((datos && datos.error) || 'Error ' + r.status);
  }
  return datos;
}

/* --------------------------- utilidades ---------------------------- */
function moneda(valor) {
  const sim = Estado.config['moneda.simbolo'] || '$';
  const n = Number(valor || 0);
  return sim + n.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function numero(v, dec = 0) {
  return Number(v || 0).toLocaleString('es-AR', { maximumFractionDigits: dec === 0 ? 2 : dec });
}
function esc(t) {
  return String(t === null || t === undefined ? '' : t)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
function hoy() { return new Date().toISOString().slice(0, 10); }
function primerDiaMes() { const d = new Date(); d.setDate(1); return d.toISOString().slice(0, 10); }

function aviso(texto, tipo = 'ok') {
  const cont = document.getElementById('mensajes');
  const div = document.createElement('div');
  div.className = tipo;
  div.textContent = texto;
  cont.appendChild(div);
  setTimeout(() => div.remove(), tipo === 'error' ? 6000 : 3500);
}
function error(e) { aviso(e.message || String(e), 'error'); }

function puede(permiso) {
  return Estado.usuario && Estado.usuario.permisos.includes(permiso);
}

function modal(titulo, html, botones = []) {
  const dlg = document.getElementById('modal');
  document.getElementById('modal-cuerpo').innerHTML = `<h3>${esc(titulo)}</h3>${html}`;
  const pie = document.getElementById('modal-pie');
  pie.innerHTML = '';
  botones.forEach(b => {
    const btn = document.createElement('button');
    btn.className = 'btn ' + (b.clase || '');
    btn.textContent = b.texto;
    btn.onclick = async () => {
      try {
        const cerrar = await b.accion(dlg);
        if (cerrar !== false) dlg.close();
      } catch (e) { error(e); }
    };
    pie.appendChild(btn);
  });
  const cerrar = document.createElement('button');
  cerrar.className = 'btn';
  cerrar.textContent = 'Cerrar';
  cerrar.onclick = () => dlg.close();
  pie.appendChild(cerrar);
  dlg.showModal();
  const primero = dlg.querySelector('input,select,textarea');
  if (primero) primero.focus();
  return dlg;
}
function cerrarModal() { document.getElementById('modal').close(); }
function valor(id) { const e = document.getElementById(id); return e ? e.value.trim() : ''; }
function marcado(id) { const e = document.getElementById(id); return e ? e.checked : false; }

/* --------------------------- navegacion ---------------------------- */
const VISTAS = [
  { id: 'panel', titulo: 'Panel', icono: '📊', permiso: 'producto.ver', tecla: 'F1' },
  { id: 'vender', titulo: 'Vender', icono: '🛒', permiso: 'venta.crear', tecla: 'F2' },
  { id: 'caja', titulo: 'Caja', icono: '💵', permiso: 'caja.gestion', tecla: 'F3' },
  { id: 'comprar', titulo: 'Comprar', icono: '📦', permiso: 'compra.crear', tecla: 'F4' },
  { id: 'productos', titulo: 'Productos', icono: '🏷️', permiso: 'producto.ver', tecla: 'F5' },
  { id: 'stock', titulo: 'Stock', icono: '📋', permiso: 'producto.ver', tecla: 'F6' },
  { id: 'precios', titulo: 'Precios', icono: '💲', permiso: 'precio.editar', tecla: 'F7' },
  { id: 'proveedores', titulo: 'Proveedores', icono: '🚚', permiso: 'producto.ver' },
  { id: 'reportes', titulo: 'Reportes y Excel', icono: '📑', permiso: 'reporte.ver', tecla: 'F8' },
  { id: 'auditoria', titulo: 'Historial', icono: '🕘', permiso: 'auditoria.ver' },
  { id: 'usuarios', titulo: 'Usuarios', icono: '👥', permiso: 'usuario.editar' },
  { id: 'config', titulo: 'Configuracion', icono: '⚙️', permiso: 'config.editar' },
];

const VISTAS_INFERIOR = ['panel', 'vender', 'comprar', 'productos', 'stock'];

function dibujarNav() {
  const cont = document.getElementById('nav-botones');
  cont.innerHTML = '';
  VISTAS.filter(v => puede(v.permiso)).forEach(v => {
    const b = document.createElement('button');
    b.type = 'button';
    b.innerHTML = `<span>${v.icono}</span><span class="txt">${v.titulo}</span>` +
      (v.tecla ? `<span class="tecla">${v.tecla}</span>` : '');
    b.onclick = () => ir(v.id);
    b.dataset.vista = v.id;
    cont.appendChild(b);
  });
}

/* Accesos rapidos al pie de la pantalla: la barra del celular. */
function dibujarNavInferior() {
  const cont = document.getElementById('nav-inferior');
  if (!cont) return;
  cont.innerHTML = '';
  VISTAS_INFERIOR
    .map(id => VISTAS.find(v => v.id === id))
    .filter(v => v && puede(v.permiso))
    .forEach(v => {
      const b = document.createElement('button');
      b.type = 'button';
      b.dataset.vista = v.id;
      b.innerHTML = `<span class="ic">${v.icono}</span><span class="txt">${v.titulo}</span>` +
        (v.id === 'vender' ? '<span class="badge" hidden></span>' : '');
      b.onclick = () => ir(v.id);
      cont.appendChild(b);
    });
}

function abrirMenu() { document.body.classList.add('menu-abierto'); }
function cerrarMenu() { document.body.classList.remove('menu-abierto'); }
function alternarMenu() { document.body.classList.toggle('menu-abierto'); }

async function ir(vista) {
  const def = VISTAS.find(v => v.id === vista);
  if (def && !puede(def.permiso)) { aviso('No tenes permiso para esa seccion', 'error'); return; }
  Estado.vista = vista;
  cerrarMenu();
  document.querySelectorAll('#nav-botones button').forEach(b =>
    b.classList.toggle('activo', b.dataset.vista === vista));
  document.querySelectorAll('#nav-inferior button').forEach(b =>
    b.classList.toggle('activo', b.dataset.vista === vista));
  const main = document.getElementById('contenido');
  main.classList.toggle('con-barra-pos', vista === 'vender');
  main.innerHTML = '<p class="vacio">Cargando...</p>';
  try {
    await Vistas[vista](main);
  } catch (e) {
    main.innerHTML = `<div class="panel"><p style="color:var(--rojo)">${esc(e.message)}</p></div>`;
  }
}

/* ----------------------------- sesion ------------------------------ */
function actualizarMarca() {
  const negocio = Estado.config['negocio.nombre'] || 'Sin nombre configurado';
  const u = Estado.usuario;
  // Si el nombre y el rol coinciden (ej: "Administrador" rol "Administrador")
  // se muestra una sola vez.
  const usuario = u ? (u.nombre) + (u.rol && u.rol !== u.nombre ? ` - ${u.rol}` : '') : '';
  const textos = { 'nav-negocio': negocio, 'barra-negocio': negocio,
    'nav-usuario': usuario, 'barra-usuario': usuario };
  Object.entries(textos).forEach(([id, texto]) => {
    const el = document.getElementById(id);
    if (el) el.textContent = texto;
  });
  document.title = (Estado.config['negocio.nombre'] || 'Minimercado') + ' - Gestion';
}

async function cargarContexto() {
  Estado.usuario = await api('/api/me');
  const cfg = await api('/api/config');
  Estado.config = cfg.valores;
  Estado.descripcionesConfig = cfg.descripciones;
  if (puede('producto.ver')) Estado.catalogos = await api('/api/catalogos');
  Estado.formasPago = (await api('/api/formas-pago')).formas_pago;
  actualizarMarca();
  dibujarNav();
  dibujarNavInferior();
}

async function entrar(usuario, password) {
  const r = await api('/api/login', { method: 'POST', body: { usuario, password } });
  Estado.token = r.token;
  localStorage.setItem('mm_token', r.token);
  await cargarContexto();
  document.getElementById('ingreso').style.display = 'none';
  document.getElementById('app').classList.add('visible');
  await ir(puede('venta.crear') ? 'vender' : 'panel');
}

function cerrarSesion(silencioso) {
  if (!silencioso) api('/api/logout', { method: 'POST', body: { token: Estado.token } }).catch(() => {});
  Estado.token = ''; Estado.usuario = null; Estado.carrito = [];
  localStorage.removeItem('mm_token');
  cerrarMenu();
  document.getElementById('app').classList.remove('visible');
  document.getElementById('ingreso').style.display = 'grid';
  document.getElementById('in-password').value = '';
}

async function mostrarAccesoRed() {
  try {
    const r = await fetch('/api/red', { headers: {} });
    const info = await r.json();
    if (!info || !info.red || !info.ip) return;
    const url = 'http://' + info.ip + ':' + info.puerto;
    let caja = document.getElementById('aviso-red');
    if (!caja) {
      caja = document.createElement('div');
      caja.id = 'aviso-red';
      document.getElementById('ingreso').appendChild(caja);
    }
    caja.innerHTML =
      '<div class="panel aviso-red"><strong>¿Usar desde tu celular?</strong>' +
      '<ol><li>Conectá el celular a la <b>misma red Wi-Fi</b> que esta PC.</li>' +
      '<li>Abrí en el celular: <code class="chip">' + esc(url) + '</code></li>' +
      '<li>En el navegador: <b>menú → "Agregar a pantalla de inicio"</b> para dejarla como app.</li></ol></div>';
  } catch (e) { /* sin red / servidor viejo: no mostramos nada */ }
}

/* ----------------------------- arranque ---------------------------- */
async function iniciarApp() {
  mostrarAccesoRed();
  document.getElementById('form-ingreso').onsubmit = async (ev) => {
    ev.preventDefault();
    const err = document.getElementById('error-ingreso');
    err.textContent = '';
    try {
      await entrar(valor('in-usuario'), valor('in-password'));
    } catch (e) { err.textContent = e.message; }
  };
  document.getElementById('btn-salir').onclick = () => cerrarSesion();
  document.getElementById('btn-menu').onclick = alternarMenu;
  document.getElementById('oscurecer').onclick = cerrarMenu;
  window.addEventListener('resize', () => { if (window.innerWidth > 720) cerrarMenu(); });

  document.addEventListener('keydown', (ev) => {
    const v = VISTAS.find(x => x.tecla === ev.key);
    if (v && Estado.usuario) { ev.preventDefault(); ir(v.id); }
    if (ev.key === 'Escape') {
      if (document.getElementById('modal').open) cerrarModal();
      cerrarMenu();
    }
  });

  if (Estado.token) {
    try {
      await cargarContexto();
      document.getElementById('ingreso').style.display = 'none';
      document.getElementById('app').classList.add('visible');
      await ir(puede('venta.crear') ? 'vender' : 'panel');
      return;
    } catch (e) { localStorage.removeItem('mm_token'); Estado.token = ''; }
  }
  document.getElementById('in-usuario').focus();
}
