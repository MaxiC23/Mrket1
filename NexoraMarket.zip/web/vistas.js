/* Vistas de la aplicacion. Cada funcion recibe el contenedor principal. */
const Vistas = {};

function encabezado(titulo, subtitulo, acciones = '') {
  return `<header class="titulo"><h2>${esc(titulo)}</h2>
    <p>${esc(subtitulo || '')}</p><div class="acciones">${acciones}</div></header>`;
}

function indicador(etiqueta, valor, detalle) {
  return `<div class="panel indicador"><span>${esc(etiqueta)}</span>
    <strong>${valor}</strong>${detalle ? `<small>${esc(detalle)}</small>` : ''}</div>`;
}

function opciones(lista, valorSel, campoTexto = 'nombre', vacio = '') {
  return (vacio ? `<option value="">${esc(vacio)}</option>` : '') +
    lista.map(x => `<option value="${x.id}" ${String(x.id) === String(valorSel) ? 'selected' : ''}>${esc(x[campoTexto])}</option>`).join('');
}

/* ============================== PANEL ============================== */
Vistas.panel = async (main) => {
  const d = await api('/api/dashboard');
  const inv = d.inventario;
  const caja = d.caja || {};
  const serie = d.ventas_por_dia || [];
  const acc = puede('caja.gestion')
    ? `<button class="btn primario" id="pn-caja">${caja.abierta ? 'Ver caja' : 'Abrir caja'}</button>`
    : '';

  // tendencia: hoy versus el dia anterior registrado
  const hoyVentas = d.hoy.total;
  let tendencia = null;
  if (serie.length > 1) {
    const prev = serie[serie.length - 2].total;
    if (prev > 0) tendencia = ((hoyVentas - prev) / prev) * 100;
  }
  const flecha = tendencia === null ? '' : tendencia >= 0
    ? `<span class="tend up">&#9650; ${numero(Math.abs(tendencia), 1)}%</span>`
    : `<span class="tend down">&#9660; ${numero(Math.abs(tendencia), 1)}%</span>`;

  main.innerHTML = encabezado('Panel', 'Resumen del negocio al ' + hoy(), acc) + `
  <div class="grilla g4" style="margin-bottom:1rem">
    <div class="panel indicador"><span>Ventas de hoy</span>
      <strong>${moneda(hoyVentas)}</strong>
      <small>${d.hoy.cantidad} comprobantes ${flecha ? '<br>' + flecha + ' vs. ayer' : ''}</small></div>
    ${indicador('Ventas de la semana', moneda(d.semana.total), 'Ganancia ' + moneda(d.semana.ganancia))}
    ${indicador('Ventas del mes', moneda(d.mes.total), 'Ganancia ' + moneda(d.mes.ganancia))}
    <div class="panel indicador"><span>Caja</span>
      <strong>${caja.abierta ? 'Abierta' : 'Cerrada'}</strong>
      <small>${caja.abierta ? 'Turno ' + moneda(caja.caja.ventas_total_pesos) : 'Sin caja abierta'}</small></div>
  </div>
  <div class="grilla g4" style="margin-bottom:1rem">
    ${indicador('Productos activos', numero(inv.productos))}
    ${indicador('Sin stock', numero(inv.sin_stock))}
    ${indicador('Stock bajo', numero(inv.stock_bajo))}
    ${indicador('Ganancia de hoy', moneda(d.hoy.ganancia))}
  </div>
  <div class="panel" style="margin-bottom:1rem">
    <h3>Movimiento de los ultimos 30 dias</h3>
    ${graficoSerie(serie)}
  </div>
  <div class="grilla g2">
    <div class="panel"><h3>Ventas por forma de pago (mes)</h3>
      ${graficoDonut(d.ventas_por_forma || [])}
      <p class="leyenda">Monto cobrado con cada medio de pago.</p></div>
    <div class="panel"><h3>Mas vendidos del mes</h3>
      ${graficoBarrasH(d.mas_vendidos.map(m => ({
        etiqueta: m.producto, valor: m.cantidad, sub: moneda(m.total)})))}
      <p class="leyenda">Cantidad de unidades vendidas.</p></div>
    <div class="panel"><h3>Margen por categoria</h3>
      ${graficoBarrasH((d.margen_categoria || []).map(c => ({
        etiqueta: c.categoria, valor: c.venta, sub: numero(c.margen, 1) + '% margen'})))}
      <p class="leyenda">Largo de la barra = monto vendido en el mes.</p></div>
    <div class="panel"><h3>Avisos</h3>${d.alertas.length ? d.alertas.map(a =>
      `<div class="aviso-linea ${a.nivel === 'alta' ? 'alta' : ''}">${esc(a.mensaje)}</div>`).join('')
      : '<p class="vacio">Todo en orden.</p>'}</div>
    <div class="panel" style="grid-column:1/-1"><h3>Ultimas ventas</h3>
      ${tabla(['Comprobante', 'Hora', 'Total', 'Pago'], d.ultimas_ventas.map(v =>
        [esc(v.numero), esc(v.fecha.slice(11, 16)), moneda(v.total_pesos), esc(v.forma_pago || '-')]),
        [false, false, true, false])}</div>
  </div>`;
  const botonCaja = document.getElementById('pn-caja');
  if (botonCaja) botonCaja.onclick = () => ir('caja');
};

function tabla(cabeceras, filas, derecha = []) {
  if (!filas.length) return '<p class="vacio">Sin datos.</p>';
  return `<div class="tabla-scroll"><table><thead><tr>${cabeceras.map((c, i) =>
    `<th class="${derecha[i] ? 'der' : ''}">${esc(c)}</th>`).join('')}</tr></thead>
    <tbody>${filas.map(f => `<tr>${f.map((c, i) =>
      `<td class="${derecha[i] ? 'der' : ''}">${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}

function monedaCorta(valor) {
  const sim = Estado.config['moneda.simbolo'] || '$';
  const v = Number(valor || 0);
  if (v >= 1000000) return sim + numero(v / 1000000, 1) + 'M';
  if (v >= 1000) return sim + numero(v / 1000, 1) + 'k';
  return sim + numero(v);
}

/* Serie de tiempo con ejes, grilla y dos lineas (total y ganancia).
   `datos` trae {fecha, total, ganancia}. */
function graficoSerie(datos) {
  if (!datos.length) return '<p class="vacio">Todavia no hay ventas registradas.</p>';
  const W = 100, H = 46, P = 4;
  const totalMax = Math.max(...datos.map(d => d.total), 1);
  const max = Math.max(totalMax, ...datos.map(d => d.ganancia || 0));

  // escalas "lindas" para la grilla (0, paso, 2*paso, ...)
  const crudo = max / 4;
  const mag = Math.pow(10, Math.floor(Math.log10(Math.max(crudo, 1))));
  const mult = crudo / mag;
  const paso = (mult > 5 ? 10 : mult > 2 ? 5 : mult > 1 ? 2 : 1) * mag;
  const ticks = [];
  for (let v = 0; v <= max + paso; v += paso) ticks.push(v);

  const x = (i) => P + (i * (W - 2 * P)) / Math.max(1, datos.length - 1);
  const y = (v) => H - P - (v / max) * (H - 2 * P);
  const lin = (campo) => datos.map((d, i) =>
    `${x(i).toFixed(2)},${y(d[campo] || 0).toFixed(2)}`).join(' ');
  const area = `${P},${H - P} ${lin('total')} ${datos.length > 1
    ? x(datos.length - 2).toFixed(2) : x(0).toFixed(2)},${H - P}`;

  const grilla = ticks.map(v => {
    const yy = y(v).toFixed(2);
    return `<line x1="${P}" y1="${yy}" x2="${W - P}" y2="${yy}"
      class="gridline"></line>
      <text x="${P - 1}" y="${(Number(yy) + 1.2).toFixed(2)}" class="etiqueta"
        text-anchor="end">${monedaCorta(v)}</text>`;
  }).join('');

  const XS = [];
  const pasoX = Math.max(1, Math.ceil((datos.length - 1) / 5));
  for (let i = 0; i < datos.length - 1E-9; i += pasoX) XS.push(i);
  if (!XS.includes(datos.length - 1)) XS.push(datos.length - 1);
  const xs = XS.map(i =>
    `<text x="${x(i).toFixed(2)}" y="${H - 1}" text-anchor="middle"
      class="etiqueta">${esc(datos[i].fecha.slice(5).replace('-', '/'))}</text>`).join('');

  const ojos = datos.map((d, i) => `
    <circle cx="${x(i).toFixed(2)}" cy="${y(d.total).toFixed(2)}" r="1.5" class="punto" data-serie="total">
      <title>${esc(d.fecha)} - total ${moneda(d.total)} - ganancia ${moneda(d.ganancia)}</title>
    </circle>`).join('');
  const ojosG = datos.map((d, i) => `
    <circle cx="${x(i).toFixed(2)}" cy="${y(d.ganancia || 0).toFixed(2)}" r="1.2" class="punto-g"
      data-serie="ganancia">
      <title>${esc(d.fecha)} - ganancia ${moneda(d.ganancia)}</title>
    </circle>`).join('');

  return `<div class="chart-linea">
      <svg viewBox="0 0 100 50" preserveAspectRatio="none" style="width:100%;height:230px"
        role="img" aria-label="Movimiento de ventas">
        ${grilla}
        <polygon points="${area}" fill="url(#gradTotal)" opacity="0.14"></polygon>
        <polyline points="${lin('ganancia')}" fill="none" class="linea-g"
          vector-effect="non-scaling-stroke"></polyline>
        <polyline points="${lin('total')}" fill="none" class="linea-t"
          vector-effect="non-scaling-stroke"></polyline>
        ${ojosG}${ojos}
        ${xs}
      </svg>
      <svg width="0" height="0"><defs>
        <linearGradient id="gradTotal" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#14532d"></stop>
          <stop offset="100%" stop-color="#14532d" stop-opacity="0"></stop>
        </linearGradient>
      </defs></svg>
    </div>
    <div class="leyenda-grafico">
      <span class="clave t"><i class="dot t"></i>Total</span>
      <span class="clave g"><i class="dot g"></i>Ganancia</span>
      <span>maximo ${monedaCorta(totalMax)} en un dia</span>
    </div>`;
}

/* Donut: participacion de cada categoria en el total.
   items: [{forma, total, cantidad}] */
function graficoDonut(items) {
  const validos = items.filter(i => (i.total || 0) > 0);
  if (!validos.length) return '<p class="vacio">Sin datos este mes.</p>';
  const total = validos.reduce((s, i) => s + i.total, 0);
  const R = 38, CX = 50, CY = 50, GROSOR = 17;
  const CIRC = 2 * Math.PI * R;
  const COLORES = ['#14532d', '#2f6b46', '#6f9b76', '#d9b23a', '#8a6d1f',
                   '#5b6b8c', '#8c5b3d', '#7d7d2f', '#8aa0a0', '#a0565e'];
  let acumulado = 0;
  const anillos = validos.map((i, k) => {
    const frac = i.total / total;
    const largo = Math.max(0.5, frac * CIRC);
    const off = -acumulado * CIRC;
    acumulado += frac;
    return `<circle cx="${CX}" cy="${CY}" r="${R}" fill="none"
      stroke="${COLORES[k % COLORES.length]}" stroke-width="${GROSOR}"
      stroke-dasharray="${largo.toFixed(2)} ${(CIRC - largo).toFixed(2)}"
      stroke-dashoffset="${off.toFixed(2)}" transform="rotate(-90 ${CX} ${CY})">
      <title>${esc(i.forma)}: ${moneda(i.total)} (${numero(frac * 100, 1)}%)</title></circle>`;
  }).join('');
  const leyenda = validos.map((i, k) => `
    <div class="donut-fila">
      <i class="dot" style="background:${COLORES[k % COLORES.length]}"></i>
      <span class="tex-eli">${esc(i.forma)}</span>
      <strong>${numero((i.total / total) * 100, 1)}%</strong>
      <span class="monto">${moneda(i.total)}</span>
    </div>`).join('');
  return `<div class="donut">
    <svg viewBox="0 0 100 100" role="img" aria-label="Ventas por forma de pago"
      width="170" height="170">
      ${anillos}
      <text x="${CX}" y="47" text-anchor="middle" class="donut-num">${monedaCorta(total)}</text>
      <text x="${CX}" y="59" text-anchor="middle" class="donut-tit">vendido este mes</text>
    </svg>
    <div class="donut-leyenda">${leyenda}</div>
  </div>`;
}

/* Barras horizontales. items: [{etiqueta, valor, sub}] */
function graficoBarrasH(items) {
  if (!items.length) return '<p class="vacio">Sin datos.</p>';
  const max = Math.max(...items.map(i => i.valor), 1);
  return `<div class="barras-h">` + items.map(i => `
    <div class="barra-h">
      <div class="barra-h-info"><span class="tex-eli">${esc(i.etiqueta)}</span>
        <strong>${esc(i.sub || '')}</strong></div>
      <div class="barra-h-pista"><div class="barra-h-relleno" style="width:${Math.max(2, (i.valor / max) * 100)}%"></div></div>
    </div>`).join('') + `</div>`;
}

function miniatura(p) {
  return p.imagen
    ? `<img class="thumb" src="${p.imagen}" alt="${esc(p.nombre || '')}">`
    : `<span class="thumb vacio">📦</span>`;
}

/* ============================== VENDER ============================= */
function descuentoMaximo() {
  return Number(Estado.config['ventas.descuento_maximo'] || 0);
}

Vistas.vender = async (main) => {
  main.innerHTML = encabezado('Vender', 'Escanea el producto y presiona Enter. F12 cobra.') + `
  <div class="pos">
    <div>
      <div class="panel escaner" style="margin-bottom:1rem">
        <label for="pos-codigo">Codigo de barras / QR o nombre del producto</label>
        <input id="pos-codigo" placeholder="Escanea o escribi y presiona Enter" autocomplete="off">
      </div>
      <div class="panel"><h3>Carrito</h3><div id="pos-items"></div></div>
    </div>
    <div>
      <div class="total" style="margin-bottom:1rem">
        <span>Total a cobrar</span><strong id="pos-total">$0,00</strong>
      </div>
      <div class="panel">
        <div id="pos-detalle"></div>
        <div class="campo"><label for="pos-descuento">Descuento general (%)</label>
          <input id="pos-descuento" type="number" min="0" step="0.5" value="0"
            ${puede('venta.descuento') ? '' : 'disabled'}>
          ${descuentoMaximo() > 0
            ? `<small class="ayu">Maximo que permite el dueño: <strong>${numero(descuentoMaximo(), 1)}%</strong>${puede('venta.descuento') ? '' : ' (no tenes permiso)'}</small>`
            : `<small class="ayu">${puede('venta.descuento') ? 'Porcentaje sobre el subtotal' : 'No tenes permiso para aplicar descuentos'}</small>`}
        </div>
        <div class="campo"><label for="pos-pago">Forma de pago</label>
          <select id="pos-pago">${opciones(Estado.formasPago, Estado.formasPago[0] && Estado.formasPago[0].id)}</select></div>
        <div class="campo"><label><input type="checkbox" id="pos-facturar" checked> Generar comprobante</label></div>
        <button class="btn primario grande" id="pos-cobrar" style="width:100%">Cobrar (F12)</button>
        <button class="btn" id="pos-limpiar" style="width:100%;margin-top:.5rem">Vaciar carrito</button>
      </div>
    </div>
  </div>
  <div id="pos-barra" class="pos-barra">
    <div class="pos-barra-total"><span>Total a cobrar</span><strong id="pos-total-movil">$0,00</strong></div>
    <button class="btn primario grande" id="pos-cobrar-movil">Cobrar</button>
  </div>`;

  const entrada = document.getElementById('pos-codigo');
  if (window.innerWidth > 720) entrada.focus();
  entrada.onkeydown = async (ev) => {
    if (ev.key !== 'Enter') return;
    ev.preventDefault();
    const texto = entrada.value.trim();
    if (!texto) return;
    entrada.value = '';
    await agregarAlCarrito(texto);
  };
  document.getElementById('pos-descuento').oninput = pintarCarrito;
  document.getElementById('pos-pago').onchange = pintarCarrito;
  document.getElementById('pos-cobrar').onclick = cobrar;
  document.getElementById('pos-cobrar-movil').onclick = cobrar;
  document.getElementById('pos-limpiar').onclick = () => { Estado.carrito = []; pintarCarrito(); };
  document.onkeydown = (ev) => {
    if (ev.key === 'F12' && Estado.vista === 'vender') { ev.preventDefault(); cobrar(); }
  };
  pintarCarrito();
};

async function buscarProductoInteractivo(texto) {
  try {
    return await api('/api/productos/codigo?codigo=' + encodeURIComponent(texto));
  } catch (e) { /* no esta por codigo: buscamos por nombre */ }
  const r = await api('/api/productos?q=' + encodeURIComponent(texto) + '&limite=25');
  if (!r.productos.length) { aviso('No se encontro "' + texto + '"', 'error'); return null; }
  if (r.productos.length === 1) return r.productos[0];
  return new Promise((resolver) => {
    const html = tabla(['Producto', 'Stock', 'Precio', ''], r.productos.map(p =>
      [esc(p.nombre), numero(p.stock), moneda(p.precio_pesos),
       `<button class="btn" data-id="${p.id}">Elegir</button>`]), [false, true, true, false]);
    const dlg = modal('Elegi el producto', html, []);
    dlg.querySelectorAll('button[data-id]').forEach(b => b.onclick = () => {
      dlg.close();
      resolver(r.productos.find(p => String(p.id) === b.dataset.id));
    });
    dlg.addEventListener('close', () => resolver(null), { once: true });
  });
}

async function agregarAlCarrito(texto) {
  const p = await buscarProductoInteractivo(texto);
  if (!p) return;
  if (p.precio_pesos <= 0) { aviso(p.nombre + ' no tiene precio de venta', 'error'); return; }
  const existente = Estado.carrito.find(i => i.producto_id === p.id);
  if (existente) existente.cantidad += 1;
  else Estado.carrito.push({ producto_id: p.id, nombre: p.nombre, cantidad: 1,
    precio: p.precio_pesos, stock: p.stock, unidad: p.unidad });
  pintarCarrito();
}

/* Refleja la cantidad de articulos en el icono "Vender" de la barra inferior. */
function actualizarContadorCarrito() {
  const badge = document.querySelector('#nav-inferior button[data-vista="vender"] .badge');
  if (!badge) return;
  const n = Estado.carrito.length;
  badge.hidden = n === 0;
  badge.textContent = n;
}

function pintarCarrito() {
  actualizarContadorCarrito();
  const cont = document.getElementById('pos-items');
  if (!cont) return;
  if (!Estado.carrito.length) {
    cont.innerHTML = '<p class="vacio">Escanea el primer producto para empezar.</p>';
  } else {
    cont.innerHTML = `<div class="tabla-scroll"><table><thead><tr>
      <th>Producto</th><th class="der">Cantidad</th><th class="der">Precio</th>
      <th class="der">Subtotal</th><th></th></tr></thead><tbody>
      ${Estado.carrito.map((i, n) => `<tr>
        <td>${esc(i.nombre)}${i.cantidad > i.stock ? ' <span class="chip malo">stock ' + numero(i.stock) + '</span>' : ''}</td>
        <td class="der"><input class="cant numero" type="number" min="0.001" step="1" value="${i.cantidad}" data-n="${n}"></td>
        <td class="der">${moneda(i.precio)}</td>
        <td class="der">${moneda(i.cantidad * i.precio)}</td>
        <td class="der"><button class="btn" data-quitar="${n}">Quitar</button></td></tr>`).join('')}
      </tbody></table></div>`;
    cont.querySelectorAll('input[data-n]').forEach(inp => inp.onchange = () => {
      const n = Number(inp.dataset.n);
      const v = Number(inp.value);
      if (v > 0) Estado.carrito[n].cantidad = v; else Estado.carrito.splice(n, 1);
      pintarCarrito();
    });
    cont.querySelectorAll('button[data-quitar]').forEach(b => b.onclick = () => {
      Estado.carrito.splice(Number(b.dataset.quitar), 1); pintarCarrito();
    });
  }
  const bruto = Estado.carrito.reduce((s, i) => s + i.cantidad * i.precio, 0);
  const campoDesc = document.getElementById('pos-descuento');
  const descPct = Math.max(0, Number(campoDesc.value || 0));
  const excede = descuentoMaximo() > 0 && descPct > descuentoMaximo();
  campoDesc.classList.toggle('invalido', excede);
  const desc = descPct > 0 ? bruto * descPct / 100 : 0;
  const fp = Estado.formasPago.find(f => String(f.id) === valor('pos-pago'));
  const recargo = fp && fp.recargo ? (bruto - desc) * fp.recargo / 100 : 0;
  const total = Math.max(0, bruto - desc + recargo);
  document.getElementById('pos-total').textContent = moneda(total);
  const movil = document.getElementById('pos-total-movil');
  if (movil) movil.textContent = moneda(total);
  document.getElementById('pos-detalle').innerHTML = `
    <div class="renglon"><span>Articulos</span><span class="numero">${Estado.carrito.length}</span></div>
    <div class="renglon"><span>Subtotal</span><span class="numero">${moneda(bruto)}</span></div>
    ${descPct > 0 ? `<div class="renglon"><span>Descuento ${numero(descPct, 1)}%</span>
      <span class="numero">-${moneda(desc)}</span></div>` : ''}
    ${recargo ? `<div class="renglon"><span>Recargo ${fp.nombre}</span><span class="numero">${moneda(recargo)}</span></div>` : ''}`;
}

async function cobrar() {
  if (!Estado.carrito.length) { aviso('El carrito esta vacio', 'error'); return; }
  const boton = document.getElementById('pos-cobrar');
  const botonMovil = document.getElementById('pos-cobrar-movil');
  boton.disabled = true;
  if (botonMovil) botonMovil.disabled = true;
  try {
    const venta = await api('/api/ventas', { method: 'POST', body: {
      items: Estado.carrito.map(i => ({ producto_id: i.producto_id, cantidad: i.cantidad })),
      descuento_pct: Number(document.getElementById('pos-descuento').value || 0),
      forma_pago_id: Number(valor('pos-pago')) || null,
      facturar: marcado('pos-facturar'),
    }});
    Estado.carrito = [];
    document.getElementById('pos-descuento').value = 0;
    pintarCarrito();
    if (window.innerWidth > 720) document.getElementById('pos-codigo').focus();
    aviso('Venta ' + venta.numero + ' por ' + moneda(venta.total_pesos));
    if (venta.aviso_facturacion) aviso(venta.aviso_facturacion, 'error');
    mostrarTicket(venta.id);
  } catch (e) { error(e); } finally { boton.disabled = false; if (botonMovil) botonMovil.disabled = false; }
}

async function mostrarTicket(ventaId) {
  const r = await api(`/api/ventas/${ventaId}/ticket`);
  const dlg = modal('Comprobante', `<pre class="ticket" id="ticket-txt">${esc(r.texto)}</pre>`, [
    { texto: 'Imprimir', clase: 'primario', accion: () => {
        const v = window.open('', '_blank');
        v.document.write('<pre style="font-family:monospace">' + esc(r.texto) + '</pre>');
        v.document.close(); v.print(); return true;
      } }]);
  return dlg;
}

/* ============================== COMPRAR ============================ */
Vistas.comprar = async (main) => {
  const provs = (await api('/api/proveedores')).proveedores;
  main.innerHTML = encabezado('Comprar', 'Carga la mercaderia una sola vez e indica cuantas unidades entraron.') + `
  <div class="grilla g2" style="align-items:start">
    <div>
      <div class="panel escaner" style="margin-bottom:1rem">
        <div class="fila">
          <div style="flex:2;min-width:220px"><label for="co-codigo">Codigo o nombre</label>
            <input id="co-codigo" placeholder="Escanea el producto y presiona Enter" autocomplete="off"></div>
          <div style="flex:1;min-width:160px"><label for="co-proveedor">Proveedor</label>
            <select id="co-proveedor">${opciones(provs, '', 'nombre', 'Sin proveedor')}</select></div>
        </div>
      </div>
      <div class="panel"><h3>Mercaderia que ingresa</h3><div id="co-items"></div></div>
    </div>
    <div class="panel">
      <h3>Resumen de la compra</h3>
      <div id="co-resumen"></div>
      <div class="campo" style="margin-top:1rem"><label for="co-comprobante">Remito / factura del proveedor</label>
        <input id="co-comprobante" placeholder="Opcional"></div>
      <button class="btn primario grande" id="co-guardar" style="width:100%">Registrar compra</button>
      <button class="btn" id="co-limpiar" style="width:100%;margin-top:.5rem">Vaciar</button>
    </div>
  </div>`;
  const inp = document.getElementById('co-codigo');
  inp.focus();
  inp.onkeydown = async (ev) => {
    if (ev.key !== 'Enter') return;
    ev.preventDefault();
    const texto = inp.value.trim(); inp.value = '';
    if (!texto) return;
    let p = null;
    try { p = await api('/api/productos/codigo?codigo=' + encodeURIComponent(texto)); }
    catch (e) { p = await buscarProductoInteractivo(texto); }
    if (!p) { if (/^\d{6,}$/.test(texto)) nuevoProductoRapido(texto); return; }
    Estado.compra.push({ producto_id: p.id, nombre: p.nombre, cantidad: 1,
      costo: p.costo_pesos, precio: p.precio_pesos, margen: p.margen_actual, stock: p.stock });
    pintarCompra();
  };
  document.getElementById('co-guardar').onclick = guardarCompra;
  document.getElementById('co-limpiar').onclick = () => { Estado.compra = []; pintarCompra(); };
  pintarCompra();
};

function pintarCompra() {
  const cont = document.getElementById('co-items');
  if (!cont) return;
  if (!Estado.compra.length) {
    cont.innerHTML = '<p class="vacio">Escanea el primer producto del pedido.</p>';
  } else {
    cont.innerHTML = `<div class="tabla-scroll"><table><thead><tr>
      <th>Producto</th><th class="der">Cantidad</th><th class="der">Costo unit.</th>
      <th class="der">Precio venta</th><th class="der">Costo total</th>
      <th class="der">Ganancia</th><th></th></tr></thead><tbody>
      ${Estado.compra.map((i, n) => `<tr>
        <td>${esc(i.nombre)}<br><small style="color:var(--tinta-suave)">stock actual ${numero(i.stock)}</small></td>
        <td class="der"><input class="cant" type="number" min="0.001" step="1" value="${i.cantidad}" data-c="cantidad" data-n="${n}"></td>
        <td class="der"><input class="cant" type="number" min="0" step="0.01" value="${i.costo}" data-c="costo" data-n="${n}"></td>
        <td class="der"><input class="cant" type="number" min="0" step="0.01" value="${i.precio}" data-c="precio" data-n="${n}"></td>
        <td class="der numero">${moneda(i.cantidad * i.costo)}</td>
        <td class="der numero">${moneda(i.cantidad * (i.precio - i.costo))}<br>
          <small>${numero(i.costo ? (i.precio - i.costo) / i.costo * 100 : 0, 1)}%</small></td>
        <td class="der"><button class="btn" data-quitar="${n}">Quitar</button></td></tr>`).join('')}
      </tbody></table></div>`;
    cont.querySelectorAll('input[data-n]').forEach(inp => inp.onchange = () => {
      const i = Estado.compra[Number(inp.dataset.n)];
      i[inp.dataset.c] = Number(inp.value);
      pintarCompra();
    });
    cont.querySelectorAll('button[data-quitar]').forEach(b => b.onclick = () => {
      Estado.compra.splice(Number(b.dataset.quitar), 1); pintarCompra();
    });
  }
  const costo = Estado.compra.reduce((s, i) => s + i.cantidad * i.costo, 0);
  const venta = Estado.compra.reduce((s, i) => s + i.cantidad * i.precio, 0);
  const unidades = Estado.compra.reduce((s, i) => s + i.cantidad, 0);
  document.getElementById('co-resumen').innerHTML = `
    <div class="renglon"><span>Productos distintos</span><span class="numero">${Estado.compra.length}</span></div>
    <div class="renglon"><span>Unidades que ingresan</span><span class="numero">${numero(unidades)}</span></div>
    <div class="renglon"><span>Costo total de la compra</span><span class="numero">${moneda(costo)}</span></div>
    <div class="renglon"><span>Valor de venta del lote</span><span class="numero">${moneda(venta)}</span></div>
    <div class="renglon"><strong>Ganancia potencial</strong><strong class="numero">${moneda(venta - costo)}</strong></div>
    <div class="renglon"><span>Margen promedio</span><span class="numero">${numero(costo ? (venta - costo) / costo * 100 : 0, 1)}%</span></div>`;
}

async function guardarCompra() {
  if (!Estado.compra.length) { aviso('No hay productos en la compra', 'error'); return; }
  try {
    const r = await api('/api/compras', { method: 'POST', body: {
      proveedor_id: Number(valor('co-proveedor')) || null,
      comprobante: valor('co-comprobante'),
      items: Estado.compra.map(i => ({ producto_id: i.producto_id, cantidad: i.cantidad,
        costo_unit: i.costo, precio_venta: i.precio })),
    }});
    Estado.compra = [];
    aviso('Compra registrada por ' + moneda(r.total_pesos));
    ir('comprar');
  } catch (e) { error(e); }
}

function nuevoProductoRapido(codigo) {
  formularioProducto({ codigo_barras: codigo }, async () => {
    aviso('Producto creado. Escanealo otra vez para agregarlo a la compra.');
  });
}

/* ============================= PRODUCTOS =========================== */
Vistas.productos = async (main) => {
  main.innerHTML = encabezado('Productos', 'Alta, busqueda y edicion del catalogo',
    puede('producto.editar') ? '<button class="btn primario" id="pr-nuevo">Nuevo producto</button>' : '') + `
  <div class="panel" style="margin-bottom:1rem">
    <div class="fila">
      <div style="flex:2;min-width:240px"><label for="pr-q">Buscar por nombre, codigo o marca</label>
        <input id="pr-q" placeholder="Escribi o escanea" autocomplete="off"></div>
      <div style="flex:1;min-width:160px"><label for="pr-cat">Categoria</label>
        <select id="pr-cat">${opciones(Estado.catalogos.categorias, '', 'nombre', 'Todas')}</select></div>
      <div style="flex:1;min-width:160px"><label for="pr-estado">Estado</label>
        <select id="pr-estado">
          <option value="activos">Activos</option><option value="stock_bajo">Stock bajo</option>
          <option value="sin_stock">Sin stock</option><option value="inactivos">Inactivos</option>
          <option value="todos">Todos</option></select></div>
    </div>
  </div>
  <div class="panel" id="pr-tabla"></div>`;

  const cargar = async () => {
    const r = await api(`/api/productos?q=${encodeURIComponent(valor('pr-q'))}` +
      `&categoria_id=${valor('pr-cat')}&estado=${valor('pr-estado')}`);
    document.getElementById('pr-tabla').innerHTML = tabla(
      ['Producto', 'Codigo', 'Categoria', 'Stock', 'Costo', 'Venta', 'Margen', 'Valor stock', ''],
      r.productos.map(p => [
        `<div class="prod-celda">${miniatura(p)}<div>
          <strong>${esc(p.nombre)}</strong>
          ${p.activo ? '' : ' <span class="chip malo">inactivo</span>'}</div></div>`,
        esc(p.codigo_barras || '-'),
        esc(p.categoria || '-'),
        `${numero(p.stock)} <span class="chip ${p.estado_stock === 'ok' ? '' : p.estado_stock === 'bajo' ? 'aviso' : 'malo'}">${p.estado_stock === 'ok' ? 'ok' : p.estado_stock === 'bajo' ? 'bajo' : 'sin stock'}</span>`,
        moneda(p.costo_pesos), moneda(p.precio_pesos), numero(p.margen_actual, 1) + '%',
        moneda(p.valor_stock_costo),
        `<button class="btn" data-ver="${p.id}">Ver</button>`]),
      [false, false, false, true, true, true, true, true, false]);
    document.querySelectorAll('button[data-ver]').forEach(b =>
      b.onclick = () => fichaProducto(Number(b.dataset.ver)));
  };
  let t;
  document.getElementById('pr-q').oninput = () => { clearTimeout(t); t = setTimeout(cargar, 250); };
  document.getElementById('pr-cat').onchange = cargar;
  document.getElementById('pr-estado').onchange = cargar;
  const nuevo = document.getElementById('pr-nuevo');
  if (nuevo) nuevo.onclick = () => formularioProducto({}, cargar);
  await cargar();
};

async function fichaProducto(id) {
  const p = await api('/api/productos/' + id);
  const html = `
  ${p.imagen ? `<div class="ficha-img"><img src="${p.imagen}" alt="${esc(p.nombre)}"></div>` : ''}
  <div class="grilla g3" style="margin-bottom:1rem">
    ${indicador('Stock', numero(p.stock) + ' ' + esc(p.unidad), 'Minimo ' + numero(p.stock_minimo))}
    ${indicador('Costo', moneda(p.costo_pesos), 'Margen ' + numero(p.margen_actual, 1) + '%')}
    ${indicador('Venta', moneda(p.precio_pesos), 'Ganancia ' + moneda(p.ganancia_unitaria))}
  </div>
  <p style="color:var(--tinta-suave);font-size:.9rem">${esc(p.codigo_barras || 'sin codigo')} -
    ${esc(p.marca || 'sin marca')} - ${esc(p.categoria || 'sin categoria')} -
    ${esc(p.proveedor || 'sin proveedor')}</p>
  <h4>Ultimas compras</h4>
  ${tabla(['Fecha', 'Proveedor', 'Cantidad', 'Costo unit.'], p.compras.map(c =>
    [esc(c.fecha.slice(0, 16)), esc(c.proveedor || '-'), numero(c.cantidad), moneda(c.costo_unit_pesos)]),
    [false, false, true, true])}
  <h4>Historial de precios</h4>
  ${tabla(['Fecha', 'Tipo', 'Antes', 'Despues', 'Motivo', 'Usuario'], p.precios.map(h =>
    [esc(h.fecha.slice(0, 16)), esc(h.tipo), moneda(h.valor_anterior_pesos),
     moneda(h.valor_nuevo_pesos), esc(h.motivo || '-'), esc(h.usuario || '-')]),
    [false, false, true, true, false, false])}
  <h4>Movimientos de stock</h4>
  ${tabla(['Fecha', 'Tipo', 'Entrada', 'Salida', 'Resultado', 'Usuario'], p.movimientos.map(m =>
    [esc(m.fecha.slice(0, 16)), esc(m.tipo), m.entrada ? numero(m.entrada) : '',
     m.salida ? numero(m.salida) : '', numero(m.stock_result), esc(m.usuario || '-')]),
    [false, false, true, true, true, false])}`;

  const botones = [];
  if (puede('producto.editar')) botones.push({ texto: 'Editar', clase: 'primario',
    accion: () => { formularioProducto(p, () => ir('productos')); return true; } });
  if (puede('stock.ajustar')) botones.push({ texto: 'Ajustar stock',
    accion: () => { ajustarStock(p); return true; } });
  modal(p.nombre, html, botones);
}

function formularioProducto(p, alGuardar) {
  const c = Estado.catalogos;
  let imagenPendiente = p.imagen || null;
  const html = `
  <div class="grilla g2">
    <div class="campo"><label for="f-nombre">Nombre</label>
      <input id="f-nombre" value="${esc(p.nombre || '')}"></div>
    <div class="campo"><label for="f-codigo">Codigo de barras</label>
      <input id="f-codigo" value="${esc(p.codigo_barras || '')}"></div>
    <div class="campo"><label for="f-qr">Codigo QR</label>
      <input id="f-qr" value="${esc(p.codigo_qr || '')}"></div>
    <div class="campo"><label for="f-marca">Marca</label>
      <select id="f-marca">${opciones(c.marcas, p.marca_id, 'nombre', 'Sin marca')}</select></div>
    <div class="campo"><label for="f-cat">Categoria</label>
      <select id="f-cat">${opciones(c.categorias, p.categoria_id, 'nombre', 'Sin categoria')}</select></div>
    <div class="campo"><label for="f-sub">Subcategoria</label>
      <select id="f-sub">${opciones(c.subcategorias, p.subcategoria_id, 'nombre', 'Sin subcategoria')}</select></div>
    <div class="campo"><label for="f-unidad">Unidad</label>
      <select id="f-unidad">${c.unidades.map(u =>
        `<option value="${u.codigo}" ${u.codigo === (p.unidad || 'UN') ? 'selected' : ''}>${esc(u.descripcion)}</option>`).join('')}</select></div>
    <div class="campo"><label for="f-prov">Proveedor</label>
      <select id="f-prov"><option value="">Sin proveedor</option></select></div>
    <div class="campo"><label for="f-costo">Precio de costo</label>
      <input id="f-costo" type="number" step="0.01" min="0" value="${p.costo_pesos || 0}"></div>
    <div class="campo"><label for="f-precio">Precio de venta</label>
      <input id="f-precio" type="number" step="0.01" min="0" value="${p.precio_pesos || ''}"></div>
    <div class="campo"><label for="f-margen">Margen propio % (vacio = usa el de la categoria)</label>
      <input id="f-margen" type="number" step="0.1" value="${p.margen !== null && p.margen !== undefined ? p.margen : ''}"></div>
    <div class="campo"><label for="f-iva">IVA %</label>
      <input id="f-iva" type="number" step="0.1" value="${p.iva !== undefined ? p.iva : Estado.config['precios.iva_default']}"></div>
    <div class="campo"><label for="f-stock">${p.id ? 'Stock (se registra como ajuste)' : 'Stock inicial'}</label>
      <input id="f-stock" type="number" step="0.001" min="0" value="${p.stock || 0}"></div>
    <div class="campo"><label for="f-min">Stock minimo</label>
      <input id="f-min" type="number" step="0.001" min="0" value="${p.stock_minimo || 0}"></div>
  </div>
  <div class="campo"><label>Imagen del producto</label>
    <div class="fila">
      <img id="f-imagen-prev" class="thumb grande" alt="" hidden>
      <div style="flex:1;min-width:200px">
        <div class="fila" style="gap:.4rem">
          ${p.id ? '<button type="button" class="btn" id="f-imagen-auto">Buscar por codigo</button>' : ''}
          <label class="btn" style="cursor:pointer;margin:0">Elegir archivo
            <input type="file" id="f-imagen-archivo" accept="image/*" hidden></label>
          <button type="button" class="btn" id="f-imagen-quitar">Quitar</button>
        </div>
        <small class="ayu">Con internet, "Buscar por codigo" encuentra la foto sola usando el codigo de barras. Tambien podes subir una imagen del equipo.</small>
      </div>
    </div>
  </div>
  <div class="campo"><label for="f-desc">Descripcion</label>
    <textarea id="f-desc" rows="2">${esc(p.descripcion || '')}</textarea></div>
  <div class="fila">
    <label><input type="checkbox" id="f-auto" ${p.margen_auto === 0 ? '' : 'checked'}>
      Recalcular el precio de venta cuando cambie el costo</label>
    <label><input type="checkbox" id="f-activo" ${p.activo === 0 ? '' : 'checked'}> Producto activo</label>
  </div>`;

  modal(p.id ? 'Editar ' + p.nombre : 'Nuevo producto', html, [
    { texto: p.id ? 'Guardar cambios' : 'Crear producto', clase: 'primario', accion: async () => {
      const datos = {
        nombre: valor('f-nombre'), codigo_barras: valor('f-codigo'), codigo_qr: valor('f-qr'),
        marca_id: valor('f-marca') || null, categoria_id: valor('f-cat') || null,
        subcategoria_id: valor('f-sub') || null, unidad: valor('f-unidad'),
        proveedor_id: valor('f-prov') || null, costo: valor('f-costo') || 0,
        precio: valor('f-precio') === '' ? null : valor('f-precio'),
        margen: valor('f-margen') === '' ? null : valor('f-margen'),
        iva: valor('f-iva') || 21, stock: valor('f-stock') || 0,
        stock_minimo: valor('f-min') || 0, descripcion: valor('f-desc'),
        margen_auto: marcado('f-auto') ? 1 : 0, activo: marcado('f-activo') ? 1 : 0,
        imagen: imagenPendiente,
      };
      if (datos.precio === null) delete datos.precio;
      if (p.id) await api('/api/productos/' + p.id, { method: 'PUT', body: datos });
      else await api('/api/productos', { method: 'POST', body: datos });
      aviso('Producto guardado');
      if (alGuardar) alGuardar();
    } }]);

  api('/api/proveedores').then(r => {
    const sel = document.getElementById('f-prov');
    if (sel) sel.innerHTML = opciones(r.proveedores, p.proveedor_id, 'nombre', 'Sin proveedor');
  });

  const prev = document.getElementById('f-imagen-prev');
  const mostrar = () => {
    if (!prev) return;
    if (imagenPendiente) { prev.src = imagenPendiente; prev.hidden = false; }
    else { prev.removeAttribute('src'); prev.hidden = true; }
  };
  mostrar();
  const btnAuto = document.getElementById('f-imagen-auto');
  if (btnAuto) btnAuto.onclick = async () => {
    try {
      const guardado = await api(`/api/productos/${p.id}/imagen-auto`, { method: 'POST' });
      imagenPendiente = guardado.imagen || null;
      mostrar();
      aviso('Imagen encontrada y cargada');
    } catch (e) { error(e); }
  };
  const archivo = document.getElementById('f-imagen-archivo');
  if (archivo) archivo.onchange = (ev) => {
    const f = ev.target.files && ev.target.files[0];
    if (!f) return;
    const lector = new FileReader();
    lector.onload = () => {
      if (String(lector.result).length > 1500000) {
        aviso('La imagen es muy grande (maximo 1,5 MB)', 'error'); return;
      }
      imagenPendiente = lector.result;
      mostrar();
    };
    lector.readAsDataURL(f);
  };
  const quitar = document.getElementById('f-imagen-quitar');
  if (quitar) quitar.onclick = () => { imagenPendiente = null; mostrar(); };
}

/* ============================== STOCK ============================== */
Vistas.stock = async (main) => {
  main.innerHTML = encabezado('Stock', 'Control de inventario y movimientos') + `
  <div class="grilla g4" id="st-indicadores" style="margin-bottom:1rem"></div>
  <div class="panel" style="margin-bottom:1rem"><h3>Productos que necesitan atencion</h3>
    <div id="st-criticos"></div></div>
  <div class="panel"><h3>Movimientos recientes</h3>
    <div class="fila" style="margin-bottom:.75rem">
      <div><label for="st-desde">Desde</label><input id="st-desde" type="date" value="${primerDiaMes()}"></div>
      <div><label for="st-hasta">Hasta</label><input id="st-hasta" type="date" value="${hoy()}"></div>
      <div><label for="st-tipo">Tipo</label><select id="st-tipo"><option value="">Todos</option>
        <option>compra</option><option>venta</option><option>ajuste</option>
        <option>devolucion</option><option>anulacion</option><option>alta</option></select></div>
      <div style="align-self:flex-end"><button class="btn" id="st-buscar">Buscar</button></div>
    </div>
    <div id="st-movimientos"></div></div>`;

  const resumen = await api('/api/reportes/resumen?periodo=mes').catch(() => null);
  const productos = (await api('/api/productos?estado=stock_bajo&limite=100')).productos
    .concat((await api('/api/productos?estado=sin_stock&limite=100')).productos);
  if (resumen) {
    const i = resumen.inventario;
    document.getElementById('st-indicadores').innerHTML =
      indicador('Valor a costo', moneda(i.valor_inventario_costo)) +
      indicador('Valor a venta', moneda(i.valor_inventario_venta)) +
      indicador('Ganancia potencial', moneda(i.ganancia_potencial)) +
      indicador('Productos criticos', numero(i.sin_stock + i.stock_bajo));
  }
  document.getElementById('st-criticos').innerHTML = tabla(
    ['Producto', 'Stock', 'Minimo', 'Proveedor', ''],
    productos.map(p => [esc(p.nombre), numero(p.stock), numero(p.stock_minimo),
      esc(p.proveedor || '-'),
      puede('stock.ajustar') ? `<button class="btn" data-aj="${p.id}">Ajustar</button>` : '']),
    [false, true, true, false, false]);
  document.querySelectorAll('button[data-aj]').forEach(b => b.onclick = async () =>
    ajustarStock(await api('/api/productos/' + b.dataset.aj)));

  const cargarMovs = async () => {
    const r = await api(`/api/stock/movimientos?desde=${valor('st-desde')}&hasta=${valor('st-hasta')}` +
      `&tipo=${valor('st-tipo')}&limite=300`);
    document.getElementById('st-movimientos').innerHTML = tabla(
      ['Fecha', 'Producto', 'Tipo', 'Entrada', 'Salida', 'Stock resultante', 'Motivo', 'Usuario'],
      r.movimientos.map(m => [esc(m.fecha.slice(0, 16)), esc(m.producto), esc(m.tipo),
        m.entrada ? numero(m.entrada) : '', m.salida ? numero(m.salida) : '',
        numero(m.stock_result), esc(m.motivo || '-'), esc(m.usuario || '-')]),
      [false, false, false, true, true, true, false, false]);
  };
  document.getElementById('st-buscar').onclick = cargarMovs;
  await cargarMovs();
};

function ajustarStock(p) {
  modal('Ajustar stock de ' + p.nombre, `
    <p>Stock actual: <strong class="numero">${numero(p.stock)}</strong> ${esc(p.unidad)}</p>
    <div class="campo"><label for="aj-final">Stock contado (cantidad real)</label>
      <input id="aj-final" type="number" step="0.001" min="0" value="${p.stock}"></div>
    <div class="campo"><label for="aj-motivo">Motivo (obligatorio)</label>
      <input id="aj-motivo" placeholder="Rotura, vencimiento, error de carga..."></div>
    <hr style="border:0;border-top:1px solid var(--linea);margin:1rem 0">
    <div class="campo"><label for="aj-dev">Devolucion de cliente (unidades que vuelven)</label>
      <input id="aj-dev" type="number" step="0.001" min="0" value="0"></div>`, [
    { texto: 'Guardar ajuste', clase: 'primario', accion: async () => {
        const dev = Number(valor('aj-dev'));
        if (dev > 0) {
          await api('/api/stock/devolucion', { method: 'POST', body: {
            producto_id: p.id, cantidad: dev, motivo: valor('aj-motivo') } });
        } else {
          await api('/api/stock/ajuste', { method: 'POST', body: {
            producto_id: p.id, cantidad_final: Number(valor('aj-final')),
            motivo: valor('aj-motivo') } });
        }
        aviso('Stock actualizado');
        ir(Estado.vista);
      } }]);
}

/* ============================== PRECIOS ============================ */
Vistas.precios = async (main) => {
  const provs = (await api('/api/proveedores')).proveedores;
  main.innerHTML = encabezado('Precios', 'Aumentos por porcentaje con vista previa antes de confirmar') + `
  <div class="grilla g2" style="align-items:start">
    <div class="panel">
      <h3>Aplicar aumento</h3>
      <div class="grilla g2">
        <div class="campo"><label for="pc-pct">Porcentaje de aumento</label>
          <input id="pc-pct" type="number" step="0.1" value="10"></div>
        <div class="campo"><label for="pc-sobre">Se aplica sobre</label>
          <select id="pc-sobre"><option value="ambos">Costo y precio de venta</option>
            <option value="costo">Solo el costo (recalcula la venta por margen)</option>
            <option value="venta">Solo el precio de venta</option></select></div>
        <div class="campo"><label for="pc-alcance">Alcance</label>
          <select id="pc-alcance"><option value="todos">Todos los productos</option>
            <option value="categoria">Una categoria</option>
            <option value="proveedor">Un proveedor</option>
            <option value="marca">Una marca</option></select></div>
        <div class="campo" id="pc-filtro-cont"></div>
      </div>
      <div class="campo"><label for="pc-motivo">Motivo (queda en el historial)</label>
        <input id="pc-motivo" placeholder="Lista nueva del proveedor, aumento mensual..."></div>
      <div class="fila">
        <button class="btn primario" id="pc-preview">Ver vista previa</button>
        <button class="btn" id="pc-recalcular">Recalcular ventas por margen</button>
      </div>
    </div>
    <div class="panel"><h3>Ultimos cambios de precio</h3><div id="pc-historial"></div></div>
  </div>
  <div class="panel" style="margin-top:1rem"><h3>Vista previa</h3><div id="pc-preview-tabla">
    <p class="vacio">Configura el aumento y presiona "Ver vista previa". Nada se modifica hasta confirmar.</p>
  </div></div>`;

  const filtro = () => {
    const a = valor('pc-alcance');
    const cont = document.getElementById('pc-filtro-cont');
    if (a === 'categoria') cont.innerHTML = `<label for="pc-filtro">Categoria</label>
      <select id="pc-filtro">${opciones(Estado.catalogos.categorias, '', 'nombre')}</select>`;
    else if (a === 'proveedor') cont.innerHTML = `<label for="pc-filtro">Proveedor</label>
      <select id="pc-filtro">${opciones(provs, '', 'nombre')}</select>`;
    else if (a === 'marca') cont.innerHTML = `<label for="pc-filtro">Marca</label>
      <select id="pc-filtro">${opciones(Estado.catalogos.marcas, '', 'nombre')}</select>`;
    else cont.innerHTML = '';
  };
  document.getElementById('pc-alcance').onchange = filtro;
  filtro();

  const cuerpo = () => {
    const a = valor('pc-alcance');
    const b = { porcentaje: Number(valor('pc-pct')), aplicar_a: valor('pc-sobre'),
      alcance: a, motivo: valor('pc-motivo') };
    const f = Number(valor('pc-filtro')) || null;
    if (a === 'categoria') b.categoria_id = f;
    if (a === 'proveedor') b.proveedor_id = f;
    if (a === 'marca') b.marca_id = f;
    return b;
  };

  document.getElementById('pc-preview').onclick = async () => {
    try {
      const r = await api('/api/precios/preview', { method: 'POST', body: cuerpo() });
      const cont = document.getElementById('pc-preview-tabla');
      if (!r.cantidad) { cont.innerHTML = '<p class="vacio">Ningun producto cambia con ese criterio.</p>'; return; }
      cont.innerHTML = `<p>${r.cantidad} producto(s) cambian. Revisa y confirma.</p>` + tabla(
        ['Producto', 'Costo anterior', 'Costo nuevo', 'Precio anterior', 'Precio nuevo', 'Margen'],
        r.productos.map(p => [esc(p.nombre), moneda(p.costo_anterior), moneda(p.costo_nuevo),
          moneda(p.precio_anterior), `<strong>${moneda(p.precio_nuevo)}</strong>`,
          numero(p.margen_nuevo, 1) + '%']),
        [false, true, true, true, true, true]) +
        `<button class="btn primario grande" id="pc-confirmar" style="margin-top:1rem">
          Confirmar aumento de ${numero(r.porcentaje, 1)}% en ${r.cantidad} producto(s)</button>`;
      document.getElementById('pc-confirmar').onclick = async () => {
        try {
          const res = await api('/api/precios/aplicar', { method: 'POST', body: cuerpo() });
          aviso(`Aumento aplicado a ${res.actualizados} producto(s)`);
          ir('precios');
        } catch (e) { error(e); }
      };
    } catch (e) { error(e); }
  };

  document.getElementById('pc-recalcular').onclick = async () => {
    if (!confirm('Recalcular el precio de venta de los productos segun su margen configurado?')) return;
    try {
      const r = await api('/api/precios/recalcular', { method: 'POST', body: cuerpo() });
      aviso(r.actualizados + ' precio(s) recalculados');
      ir('precios');
    } catch (e) { error(e); }
  };

  const h = await api('/api/precios/historial?limite=60');
  document.getElementById('pc-historial').innerHTML = tabla(
    ['Fecha', 'Producto', 'Tipo', 'Antes', 'Despues', 'Usuario'],
    h.historial.map(x => [esc(x.fecha.slice(0, 16)), esc(x.producto), esc(x.tipo),
      moneda(x.valor_anterior_pesos), moneda(x.valor_nuevo_pesos), esc(x.usuario || '-')]),
    [false, false, false, true, true, false]);
};

/* ============================ PROVEEDORES ========================== */
Vistas.proveedores = async (main) => {
  main.innerHTML = encabezado('Proveedores', 'Datos, productos y precios pagados',
    puede('proveedor.editar') ? '<button class="btn primario" id="pv-nuevo">Nuevo proveedor</button>' : '') +
    '<div class="panel" id="pv-tabla"></div>';
  const r = await api('/api/proveedores');
  document.getElementById('pv-tabla').innerHTML = tabla(
    ['Proveedor', 'CUIT', 'Telefono', 'Email', ''],
    r.proveedores.map(p => [esc(p.nombre), esc(p.cuit || '-'), esc(p.telefono || '-'),
      esc(p.email || '-'), `<button class="btn" data-pv="${p.id}">Ver</button>`]));
  document.querySelectorAll('button[data-pv]').forEach(b =>
    b.onclick = () => fichaProveedor(Number(b.dataset.pv)));
  const nuevo = document.getElementById('pv-nuevo');
  if (nuevo) nuevo.onclick = () => formularioProveedor({});
};

async function fichaProveedor(id) {
  const p = await api('/api/proveedores/' + id);
  const html = `
  <p style="color:var(--tinta-suave)">${esc(p.cuit || 'sin CUIT')} - ${esc(p.telefono || 'sin telefono')}
    - ${esc(p.email || 'sin email')}<br>${esc(p.direccion || '')}</p>
  <h4>Ultimo precio pagado por producto</h4>
  ${tabla(['Producto', 'Costo', 'Fecha'], p.ultimos_precios.map(u =>
    [esc(u.nombre), moneda(u.costo_unit_pesos), esc((u.fecha || '').slice(0, 10))]),
    [false, true, false])}
  <h4>Compras registradas</h4>
  ${tabla(['Fecha', 'Comprobante', 'Total'], p.compras.map(c =>
    [esc(c.fecha.slice(0, 16)), esc(c.comprobante || '-'), moneda(c.total_pesos)]),
    [false, false, true])}
  <h4>Productos asociados</h4>
  ${tabla(['Producto', 'Stock', 'Costo', 'Venta'], p.productos.map(x =>
    [esc(x.nombre), numero(x.stock), moneda(x.costo_pesos), moneda(x.precio_pesos)]),
    [false, true, true, true])}`;
  const botones = puede('proveedor.editar')
    ? [{ texto: 'Editar', clase: 'primario', accion: () => { formularioProveedor(p); return true; } }]
    : [];
  modal(p.nombre, html, botones);
}

function formularioProveedor(p) {
  modal(p.id ? 'Editar proveedor' : 'Nuevo proveedor', `
    <div class="grilla g2">
      <div class="campo"><label for="pv-nombre">Nombre</label><input id="pv-nombre" value="${esc(p.nombre || '')}"></div>
      <div class="campo"><label for="pv-cuit">CUIT</label><input id="pv-cuit" value="${esc(p.cuit || '')}"></div>
      <div class="campo"><label for="pv-tel">Telefono</label><input id="pv-tel" value="${esc(p.telefono || '')}"></div>
      <div class="campo"><label for="pv-email">Email</label><input id="pv-email" value="${esc(p.email || '')}"></div>
    </div>
    <div class="campo"><label for="pv-dir">Direccion</label><input id="pv-dir" value="${esc(p.direccion || '')}"></div>
    <div class="campo"><label for="pv-notas">Notas</label><textarea id="pv-notas" rows="2">${esc(p.notas || '')}</textarea></div>`,
    [{ texto: 'Guardar', clase: 'primario', accion: async () => {
      const datos = { nombre: valor('pv-nombre'), cuit: valor('pv-cuit'), telefono: valor('pv-tel'),
        email: valor('pv-email'), direccion: valor('pv-dir'), notas: valor('pv-notas') };
      if (p.id) await api('/api/proveedores/' + p.id, { method: 'PUT', body: datos });
      else await api('/api/proveedores', { method: 'POST', body: datos });
      aviso('Proveedor guardado');
      ir('proveedores');
    } }]);
}

/* ============================== CAJA =============================== */
Vistas.caja = async (main) => {
  main.innerHTML = encabezado('Caja', 'Apertura, control y cierre del efectivo') +
    '<div id="cj-accion"></div>' +
    '<div class="panel" style="margin-top:1rem"><h3>Cierres anteriores</h3>' +
    '<div id="cj-historial"></div></div>';

  const pintarHistorial = async () => {
    const h = await api('/api/caja/historial?limite=30');
    const filas = h.cajas.map(x => {
      const abierta = x.estado === 'abierta';
      const dif = x.diferencia_pesos || 0;
      return [esc((x.abierta_en || '').slice(0, 16)),
        abierta ? '<span class="chip">abierta</span>' : esc((x.cerrada_en || '').slice(0, 16)),
        esc(x.abre || '-'), esc(abierta ? '-' : (x.cierra || '-')),
        moneda(x.monto_inicial_pesos), moneda(x.ventas_total_pesos),
        moneda(x.monto_esperado_pesos),
        abierta ? '-' : moneda(x.monto_contado_pesos),
        abierta ? '-' : `<span class="${dif >= 0 ? 'pos' : 'neg'}">${moneda(dif)}</span>`];
    });
    document.getElementById('cj-historial').innerHTML = tabla(
      ['Apertura', 'Cierre', 'Abrio', 'Cerro', 'Fondo', 'Ventas turno',
       'Esperado', 'Contado', 'Diferencia'], filas,
      [false, false, false, false, true, true, true, true, true]);
  };

  const pintar = async () => {
    const est = await api('/api/caja');
    document.getElementById('cj-accion').innerHTML = est.abierta ? `
      <div class="grilla g4" style="margin-bottom:1rem">
        ${indicador('Estado de la caja', 'Abierta', 'Desde ' + esc((est.caja.abierta_en || '').slice(0, 16)))}
        ${indicador('Fondo inicial', moneda(est.caja.monto_inicial_pesos))}
        ${indicador('Ventas del turno', moneda(est.caja.ventas_total_pesos), est.ventas.cantidad + ' comprobantes')}
        ${indicador('Total esperado', moneda(est.caja.monto_esperado_pesos), 'Fondo + ventas')}
      </div>
      <div class="panel">
        <h3>Cerrar caja</h3>
        <div class="fila">
          <div style="flex:1;min-width:200px"><label for="cj-contado">Dinero contado en la caja</label>
            <input id="cj-contado" type="number" step="0.01" min="0" placeholder="Ingresa el total fisico"></div>
          <div style="flex:2;min-width:220px"><label for="cj-obs">Observaciones</label>
            <input id="cj-obs" placeholder="Opcional (ej: corte del dia, retiros...)"></div>
          <div style="align-self:flex-end"><button class="btn primario grande" id="cj-cerrar">Cerrar caja</button></div>
        </div>
        <p style="font-size:.88rem;color:var(--tinta-suave);margin:.8rem 0 0">
          Esperado: <strong>${moneda(est.caja.monto_esperado_pesos)}</strong>
          = fondo ${moneda(est.caja.monto_inicial_pesos)} + ventas ${moneda(est.caja.ventas_total_pesos)}</p>
      </div>` : `
      <div class="panel apertura">
        <h3 style="color:#fff;margin-bottom:.4rem">Abrir la caja</h3>
        <p style="color:#cfe3d7;margin:0 0 1rem">Indica el dinero que hay en la caja al empezar (fondo inicial).</p>
        <div class="fila">
          <div style="flex:1;min-width:200px"><label for="cj-inicial" style="color:#cfe3d7">Fondo inicial</label>
            <input id="cj-inicial" type="number" step="0.01" min="0" placeholder="0,00"></div>
          <div style="align-self:flex-end"><button class="btn grande claro" id="cj-abrir">Abrir caja</button></div>
        </div>
      </div>`;
    const abrirBtn = document.getElementById('cj-abrir');
    if (abrirBtn) abrirBtn.onclick = async () => {
      try {
        await api('/api/caja/abrir', { method: 'POST',
          body: { monto_inicial: Number(valor('cj-inicial')) || 0 } });
        aviso('Caja abierta');
        pintar();
      } catch (e) { error(e); }
    };
    const cerrarBtn = document.getElementById('cj-cerrar');
    if (cerrarBtn) cerrarBtn.onclick = async () => {
      try {
        const r = await api('/api/caja/cerrar', { method: 'POST',
          body: { monto_contado: Number(valor('cj-contado')) || 0,
                  observaciones: valor('cj-obs') } });
        const dif = r.diferencia_pesos || 0;
        aviso('Caja cerrada. Diferencia: ' + moneda(dif));
        if (dif !== 0) aviso(dif < 0 ? 'Faltan ' + moneda(-dif) + ' en la caja' : 'Sobran ' + moneda(dif) + ' en la caja', 'error');
        pintar();
      } catch (e) { error(e); }
    };
    await pintarHistorial();
  };
  await pintar();
};

/* ============================== REPORTES =========================== */
Vistas.reportes = async (main) => {
  main.innerHTML = encabezado('Reportes y Excel', 'Descarga la informacion en planillas .xlsx reales') + `
  <div class="grilla g2" style="align-items:start">
    <div class="panel">
      <h3>Generar planilla Excel</h3>
      <div class="campo"><label>Que queres exportar</label>
        <div class="fila">
          ${['resumen', 'stock', 'ventas', 'compras', 'movimientos', 'precios'].map(t =>
            `<label style="display:flex;gap:.35rem;align-items:center;margin:0">
              <input type="checkbox" class="rp-tipo" value="${t}" checked> ${t}</label>`).join('')}
        </div></div>
      <div class="fila">
        <div style="flex:1"><label for="rp-periodo">Periodo</label>
          <select id="rp-periodo"><option value="dia">Hoy</option><option value="ayer">Ayer</option>
            <option value="semana">Esta semana</option><option value="mes" selected>Este mes</option>
            <option value="anio">Este ano</option><option value="todo">Todo</option>
            <option value="personalizado">Rango de fechas</option></select></div>
        <div><label for="rp-desde">Desde</label><input id="rp-desde" type="date" value="${primerDiaMes()}"></div>
        <div><label for="rp-hasta">Hasta</label><input id="rp-hasta" type="date" value="${hoy()}"></div>
      </div>
      <button class="btn primario grande" id="rp-excel" style="width:100%;margin-top:1rem">
        Descargar Excel</button>
    </div>
    <div class="panel"><h3>Resultado del periodo</h3><div id="rp-resumen"></div></div>
  </div>
  <div class="panel" style="margin-top:1rem"><h3>Margen por categoria</h3><div id="rp-margenes"></div></div>
  <div class="panel" style="margin-top:1rem"><h3>Ventas del periodo</h3><div id="rp-ventas"></div></div>`;

  const cargar = async () => {
    const p = valor('rp-periodo');
    const q = `periodo=${p}&desde=${valor('rp-desde')}&hasta=${valor('rp-hasta')}`;
    const r = await api('/api/reportes/resumen?' + q);
    document.getElementById('rp-resumen').innerHTML = `
      <div class="renglon"><span>Periodo</span><span>${esc(r.desde)} al ${esc(r.hasta)}</span></div>
      <div class="renglon"><span>Comprobantes</span><span class="numero">${numero(r.ventas.cantidad)}</span></div>
      <div class="renglon"><span>Total vendido</span><span class="numero">${moneda(r.ventas.total)}</span></div>
      <div class="renglon"><span>Costo de lo vendido</span><span class="numero">${moneda(r.ventas.costo)}</span></div>
      <div class="renglon"><strong>Ganancia</strong><strong class="numero">${moneda(r.ventas.ganancia)}</strong></div>`;
    const m = await api(`/api/reportes/margenes?desde=${r.desde}&hasta=${r.hasta}`);
    document.getElementById('rp-margenes').innerHTML = tabla(
      ['Categoria', 'Venta', 'Costo', 'Ganancia', 'Margen'],
      m.categorias.map(c => [esc(c.categoria), moneda(c.venta), moneda(c.costo),
        moneda(c.ganancia), numero(c.margen, 1) + '%']),
      [false, true, true, true, true]);
    const v = await api(`/api/ventas?desde=${r.desde}&hasta=${r.hasta}&limite=100`);
    document.getElementById('rp-ventas').innerHTML = tabla(
      ['Comprobante', 'Fecha', 'Items', 'Total', 'Ganancia', 'Pago', 'Estado', ''],
      v.ventas.map(x => [esc(x.numero), esc(x.fecha.slice(0, 16)), numero(x.items),
        moneda(x.total_pesos), moneda(x.ganancia_pesos), esc(x.forma_pago || '-'),
        x.estado === 'anulada' ? '<span class="chip malo">anulada</span>' : '<span class="chip">ok</span>',
        `<button class="btn" data-vt="${x.id}">Ver</button>`]),
      [false, false, true, true, true, false, false, false]);
    document.querySelectorAll('button[data-vt]').forEach(b =>
      b.onclick = () => verVenta(Number(b.dataset.vt)));
  };
  document.getElementById('rp-periodo').onchange = cargar;
  document.getElementById('rp-desde').onchange = cargar;
  document.getElementById('rp-hasta').onchange = cargar;
  document.getElementById('rp-excel').onclick = () => {
    const tipos = [...document.querySelectorAll('.rp-tipo:checked')].map(c => c.value);
    if (!tipos.length) { aviso('Elegi al menos un reporte', 'error'); return; }
    const url = `/api/reportes/excel?tipos=${tipos.join(',')}&periodo=${valor('rp-periodo')}` +
      `&desde=${valor('rp-desde')}&hasta=${valor('rp-hasta')}&token=${encodeURIComponent(Estado.token)}`;
    window.location.href = url;
    aviso('Generando la planilla...');
  };
  await cargar();
};

async function verVenta(id) {
  const v = await api('/api/ventas/' + id);
  const html = tabla(['Producto', 'Cantidad', 'Precio', 'Subtotal'],
    v.items.map(i => [esc(i.descripcion), numero(i.cantidad), moneda(i.precio_unit_pesos),
      moneda(i.subtotal_pesos)]), [false, true, true, true]) +
    `<p style="margin-top:1rem"><strong>Total ${moneda(v.total_pesos)}</strong> -
      ${esc(v.forma_pago || 'sin forma de pago')} - ${esc(v.usuario || '')} - ${esc(v.estado)}</p>`;
  const botones = [{ texto: 'Ver ticket', accion: () => { mostrarTicket(id); return true; } }];
  if (puede('venta.anular') && v.estado === 'confirmada') {
    botones.push({ texto: 'Anular venta', clase: 'peligro', accion: async () => {
      const motivo = prompt('Motivo de la anulacion:');
      if (motivo === null) return false;
      await api(`/api/ventas/${id}/anular`, { method: 'POST', body: { motivo } });
      aviso('Venta anulada, el stock volvio al inventario');
      ir(Estado.vista);
    } });
  }
  modal('Venta ' + v.numero, html, botones);
}

/* ============================== HISTORIAL ========================== */
Vistas.auditoria = async (main) => {
  main.innerHTML = encabezado('Historial', 'Todo lo que paso en el sistema, con usuario y fecha') + `
  <div class="panel"><div class="fila" style="margin-bottom:.75rem">
    <div><label for="au-desde">Desde</label><input id="au-desde" type="date" value="${primerDiaMes()}"></div>
    <div><label for="au-hasta">Hasta</label><input id="au-hasta" type="date" value="${hoy()}"></div>
    <div style="align-self:flex-end"><button class="btn" id="au-buscar">Buscar</button></div>
  </div><div id="au-tabla"></div></div>`;
  const cargar = async () => {
    const r = await api(`/api/auditoria?desde=${valor('au-desde')}&hasta=${valor('au-hasta')}&limite=400`);
    document.getElementById('au-tabla').innerHTML = tabla(
      ['Fecha', 'Usuario', 'Operacion', 'Entidad', 'Detalle', 'Antes', 'Despues'],
      r.auditoria.map(a => [esc(a.fecha.slice(0, 16)), esc(a.usuario_nombre || '-'),
        esc(a.operacion), esc((a.entidad || '') + ' ' + (a.entidad_id || '')),
        esc(a.detalle || ''), esc((a.valor_anterior || '').slice(0, 60)),
        esc((a.valor_nuevo || '').slice(0, 60))]));
  };
  document.getElementById('au-buscar').onclick = cargar;
  await cargar();
};

/* ============================== USUARIOS =========================== */
Vistas.usuarios = async (main) => {
  const r = await api('/api/usuarios');
  main.innerHTML = encabezado('Usuarios', 'Quien puede hacer que cosa',
    '<button class="btn primario" id="us-nuevo">Nuevo usuario</button>') + `
  <div class="panel" style="margin-bottom:1rem">${tabla(
    ['Usuario', 'Nombre', 'Rol', 'Estado', 'Ultimo acceso', ''],
    r.usuarios.map(u => [esc(u.usuario), esc(u.nombre), esc(u.rol),
      u.activo ? '<span class="chip">activo</span>' : '<span class="chip malo">inactivo</span>',
      esc(u.ultimo_acceso || 'nunca'), `<button class="btn" data-us="${u.id}">Editar</button>`]))}</div>
  <div class="panel"><h3>Permisos por rol</h3><div id="us-roles"></div></div>`;

  document.getElementById('us-roles').innerHTML = r.roles.map(rol => `
    <details style="margin-bottom:.6rem"><summary style="cursor:pointer;padding:.4rem 0">
      <strong>${esc(rol.nombre)}</strong> - ${rol.permisos.length} permisos</summary>
    <div class="grilla g3" style="padding:.6rem 0">
      ${Object.entries(r.permisos).map(([codigo, desc]) => `<label style="display:flex;gap:.4rem;align-items:center">
        <input type="checkbox" data-rol="${rol.id}" value="${codigo}"
          ${rol.permisos.includes(codigo) ? 'checked' : ''}> ${esc(desc)}</label>`).join('')}
    </div>
    <button class="btn" data-guardar-rol="${rol.id}">Guardar permisos de ${esc(rol.nombre)}</button>
    </details>`).join('');

  document.querySelectorAll('button[data-guardar-rol]').forEach(b => b.onclick = async () => {
    const id = b.dataset.guardarRol;
    const permisos = [...document.querySelectorAll(`input[data-rol="${id}"]:checked`)].map(c => c.value);
    try {
      await api(`/api/roles/${id}/permisos`, { method: 'PUT', body: { permisos } });
      aviso('Permisos actualizados');
    } catch (e) { error(e); }
  });
  document.querySelectorAll('button[data-us]').forEach(b => b.onclick = () => {
    const u = r.usuarios.find(x => String(x.id) === b.dataset.us);
    formularioUsuario(u, r.roles);
  });
  document.getElementById('us-nuevo').onclick = () => formularioUsuario({}, r.roles);
};

function formularioUsuario(u, roles) {
  modal(u.id ? 'Editar ' + u.usuario : 'Nuevo usuario', `
    <div class="grilla g2">
      <div class="campo"><label for="us-usuario">Usuario</label>
        <input id="us-usuario" value="${esc(u.usuario || '')}" ${u.id ? 'disabled' : ''}></div>
      <div class="campo"><label for="us-nombre">Nombre y apellido</label>
        <input id="us-nombre" value="${esc(u.nombre || '')}"></div>
      <div class="campo"><label for="us-rol">Rol</label>
        <select id="us-rol">${roles.map(r =>
          `<option ${r.nombre === u.rol ? 'selected' : ''}>${esc(r.nombre)}</option>`).join('')}</select></div>
      <div class="campo"><label for="us-pass">Contrasena ${u.id ? '(dejar vacio para no cambiarla)' : ''}</label>
        <input id="us-pass" type="password"></div>
    </div>
    <label><input type="checkbox" id="us-activo" ${u.activo === 0 ? '' : 'checked'}> Usuario activo</label>`,
    [{ texto: 'Guardar', clase: 'primario', accion: async () => {
      const datos = { nombre: valor('us-nombre'), rol: valor('us-rol'), activo: marcado('us-activo') };
      if (valor('us-pass')) datos.password = valor('us-pass');
      if (u.id) await api('/api/usuarios/' + u.id, { method: 'PUT', body: datos });
      else await api('/api/usuarios', { method: 'POST', body: {
        ...datos, usuario: valor('us-usuario'), password: valor('us-pass') } });
      aviso('Usuario guardado');
      ir('usuarios');
    } }]);
}

/* ============================ CONFIGURACION ======================== */
const GRUPOS_CONFIG = [
  ['negocio', 'Datos del negocio'],
  ['moneda', 'Moneda'],
  ['precios', 'Precios y margenes'],
  ['ventas', 'Ventas y caja'],
  ['factura', 'Facturacion e impresora'],
  ['alertas', 'Alertas'],
  ['backup', 'Copias de seguridad'],
];

Vistas.config = async (main) => {
  const cfg = await api('/api/config');
  const fact = await api('/api/facturacion');
  const desc = cfg.descripciones;
  Estado.config = cfg.valores;

  const campos = (prefijo) => Object.keys(desc).filter(k => k.startsWith(prefijo + '.'))
    .map(k => {
      const v = cfg.valores[k] || '';
      if (k === 'factura.adaptador') {
        return `<div class="campo"><label for="cf-${k}">${esc(desc[k])}</label>
          <select id="cf-${k}">${fact.adaptadores.map(a =>
            `<option value="${a.nombre}" ${a.nombre === v ? 'selected' : ''}>${esc(a.nombre)} - ${esc(a.descripcion)}</option>`).join('')}</select></div>`;
      }
      const esBooleano = ['1', '0'].includes(String(v)) && /automatico|auto|incluye_iva|recalculo|stock_bajo/.test(k);
      if (esBooleano) {
        return `<div class="campo"><label style="display:flex;gap:.4rem;align-items:center">
          <input type="checkbox" id="cf-${k}" ${v === '1' ? 'checked' : ''}> ${esc(desc[k])}</label></div>`;
      }
      return `<div class="campo"><label for="cf-${k}">${esc(desc[k])}</label>
        <input id="cf-${k}" value="${esc(v)}"></div>`;
    }).join('');

  main.innerHTML = encabezado('Configuracion', 'Todo lo que identifica al negocio se guarda en la base de datos') +
    GRUPOS_CONFIG.map(([p, titulo]) => `<div class="panel" style="margin-bottom:1rem">
      <h3>${titulo}</h3><div class="grilla g2">${campos(p)}</div>
      ${p === 'factura' ? `<p style="font-size:.88rem;color:var(--tinta-suave)">
        Estado del adaptador: ${fact.prueba.ok ? '' : '⚠ '}${esc(fact.prueba.mensaje)}</p>` : ''}
    </div>`).join('') + `
    <div class="panel" style="margin-bottom:1rem"><h3>Formas de pago</h3>
      <div id="cf-pagos"></div>
      <div class="fila" style="margin-top:.75rem">
        <input id="cf-pago-nombre" placeholder="Nombre de la forma de pago" style="flex:2">
        <input id="cf-pago-recargo" type="number" step="0.1" value="0" placeholder="Recargo %" style="flex:1">
        <button class="btn" id="cf-pago-agregar">Agregar</button></div></div>
    <div class="panel" style="margin-bottom:1rem"><h3>Categorias y margenes</h3>
      <div id="cf-categorias"></div>
      <div class="fila" style="margin-top:.75rem">
        <input id="cf-cat-nombre" placeholder="Nueva categoria" style="flex:2">
        <input id="cf-cat-margen" type="number" step="0.1" placeholder="Margen %" style="flex:1">
        <button class="btn" id="cf-cat-agregar">Agregar</button></div></div>
    <div class="panel" style="margin-bottom:1rem"><h3>Copias de seguridad</h3>
      <div id="cf-backups"></div>
      <button class="btn primario" id="cf-backup" style="margin-top:.75rem">Crear copia ahora</button></div>
    <button class="btn primario grande" id="cf-guardar">Guardar configuracion</button>`;

  document.getElementById('cf-guardar').onclick = async () => {
    const valores = {};
    Object.keys(desc).forEach(k => {
      const el = document.getElementById('cf-' + k);
      if (!el) return;
      valores[k] = el.type === 'checkbox' ? (el.checked ? '1' : '0') : el.value;
    });
    try {
      const r = await api('/api/config', { method: 'PUT', body: valores });
      Estado.config = r.valores;
      actualizarMarca();
      aviso('Configuracion guardada');
    } catch (e) { error(e); }
  };

  const pintarPagos = async () => {
    const r = await api('/api/formas-pago?todas=1');
    Estado.formasPago = r.formas_pago.filter(f => f.activo);
    document.getElementById('cf-pagos').innerHTML = tabla(
      ['Forma de pago', 'Recargo %', 'Estado', ''],
      r.formas_pago.map(f => [esc(f.nombre), numero(f.recargo, 1),
        f.activo ? 'activa' : 'inactiva',
        `<button class="btn" data-fp="${f.id}" data-activo="${f.activo}">
          ${f.activo ? 'Desactivar' : 'Activar'}</button>`]), [false, true, false, false]);
    document.querySelectorAll('button[data-fp]').forEach(b => b.onclick = async () => {
      const f = r.formas_pago.find(x => String(x.id) === b.dataset.fp);
      await api('/api/formas-pago', { method: 'POST', body: {
        id: f.id, nombre: f.nombre, recargo: f.recargo, activo: !f.activo } });
      pintarPagos();
    });
  };
  document.getElementById('cf-pago-agregar').onclick = async () => {
    try {
      await api('/api/formas-pago', { method: 'POST', body: {
        nombre: valor('cf-pago-nombre'), recargo: Number(valor('cf-pago-recargo')) } });
      document.getElementById('cf-pago-nombre').value = '';
      pintarPagos();
    } catch (e) { error(e); }
  };
  await pintarPagos();

  const pintarCategorias = async () => {
    const c = await api('/api/catalogos');
    Estado.catalogos = c;
    document.getElementById('cf-categorias').innerHTML = tabla(
      ['Categoria', 'Margen %', ''],
      c.categorias.map(x => [esc(x.nombre),
        `<input type="number" step="0.1" value="${x.margen === null ? '' : x.margen}" data-cat="${x.id}" style="width:90px;text-align:right">`,
        `<button class="btn" data-cat-guardar="${x.id}">Guardar</button>`]), [false, true, false]);
    document.querySelectorAll('button[data-cat-guardar]').forEach(b => b.onclick = async () => {
      const id = b.dataset.catGuardar;
      const inp = document.querySelector(`input[data-cat="${id}"]`);
      await api('/api/categorias/' + id, { method: 'PUT', body: { margen: inp.value } });
      aviso('Margen de la categoria actualizado');
    });
  };
  document.getElementById('cf-cat-agregar').onclick = async () => {
    try {
      await api('/api/categorias', { method: 'POST', body: {
        nombre: valor('cf-cat-nombre'), margen: valor('cf-cat-margen') } });
      document.getElementById('cf-cat-nombre').value = '';
      pintarCategorias();
    } catch (e) { error(e); }
  };
  await pintarCategorias();

  if (puede('backup.ejecutar')) {
    const pintarBackups = async () => {
      const r = await api('/api/backups');
      document.getElementById('cf-backups').innerHTML =
        `<p style="font-size:.88rem;color:var(--tinta-suave)">Carpeta: ${esc(r.directorio)}</p>` +
        tabla(['Copia', 'Fecha', 'Tamano', ''], r.backups.slice(0, 15).map(b =>
          [esc(b.nombre), esc(b.fecha), numero(b.bytes / 1024) + ' KB',
           `<button class="btn peligro" data-rest="${b.nombre}">Restaurar</button>`]),
          [false, false, true, false]);
      document.querySelectorAll('button[data-rest]').forEach(b => b.onclick = async () => {
        if (!confirm('Restaurar ' + b.dataset.rest + '? Se creara una copia del estado actual antes.')) return;
        try {
          const res = await api('/api/backups/restaurar', { method: 'POST', body: { nombre: b.dataset.rest } });
          aviso('Base restaurada. Copia previa: ' + res.copia_previa);
        } catch (e) { error(e); }
      });
    };
    document.getElementById('cf-backup').onclick = async () => {
      try { const b = await api('/api/backups', { method: 'POST', body: { motivo: 'manual' } });
        aviso('Copia creada: ' + b.nombre); pintarBackups(); } catch (e) { error(e); }
    };
    await pintarBackups();
  } else {
    document.getElementById('cf-backups').innerHTML = '<p class="vacio">Sin permiso para copias de seguridad.</p>';
  }
};
