"""Pruebas automaticas de las funciones criticas del sistema."""
import gc
import json
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
import warnings
import zipfile
from io import BytesIO
from pathlib import Path

# Las conexiones SQLite se cierran al ser recolectadas (ciclos de referencias);
# que Python avise "unclosed database" es esperado en este diseno.
warnings.filterwarnings("ignore", message="unclosed database",
                        category=ResourceWarning)

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import db, seed, security  # noqa: E402
from app.db import ErrorNegocio  # noqa: E402
from app.services import (backup, caja, compras, config, facturacion, precios,  # noqa: E402
                          productos, proveedores, reportes, stock, ventas)


class BaseTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        db.set_db_path(Path(self.tmp.name) / "test.db")
        seed.inicializar("admin", "admin1234", "Almacen de Prueba")
        self.admin = security.login("admin", "admin1234")["usuario"]

    def tearDown(self):
        db.cerrar()
        # Las conexiones de hilos ya terminados pueden quedar atrapadas en
        # ciclos de referencias del modulo sqlite3; sin este collect quedarian
        # abiertas y Windows no podria borrar la base temporal (WinError 32).
        gc.collect()
        self.tmp.cleanup()

    def crear_producto(self, **kw):
        datos = {"codigo_barras": "7790000000001", "nombre": "Gaseosa 2.25 L",
                 "costo": 1500, "precio": 2200, "stock": 0, "stock_minimo": 5}
        datos.update(kw)
        return productos.crear(datos, self.admin)


class TestProductos(BaseTest):
    def test_alta_y_busqueda_por_codigo(self):
        p = self.crear_producto()
        self.assertEqual(p["costo_pesos"], 1500.0)
        self.assertEqual(p["precio_pesos"], 2200.0)
        encontrado = productos.buscar_por_codigo("7790000000001")
        self.assertEqual(encontrado["id"], p["id"])
        self.assertIsNone(productos.buscar_por_codigo("999"))

    def test_no_permite_codigo_duplicado(self):
        self.crear_producto()
        with self.assertRaises(ErrorNegocio):
            self.crear_producto(nombre="Otro")

    def test_precio_calculado_por_margen(self):
        cat = productos.crear_categoria("Bebidas frias", 50, self.admin)
        p = self.crear_producto(codigo_barras="111", precio=None,
                                categoria_id=cat["id"], costo=1000)
        self.assertEqual(p["precio_pesos"], 1500.0)

    def test_stock_inicial_genera_movimiento(self):
        p = self.crear_producto(stock=10)
        movs = stock.movimientos(p["id"])
        self.assertEqual(len(movs), 1)
        self.assertEqual(movs[0]["tipo"], "alta")
        self.assertEqual(movs[0]["stock_result"], 10)


class TestCompras(BaseTest):
    def test_compra_suma_stock_una_sola_carga(self):
        p = self.crear_producto(stock=0)
        compra = compras.registrar(
            {"items": [{"producto_id": p["id"], "cantidad": 30, "costo_unit": 1500}]},
            self.admin)
        self.assertEqual(compra["total_pesos"], 45000.0)
        self.assertEqual(productos.obtener(p["id"])["stock"], 30)

    def test_compra_actualiza_costo_y_recalcula_venta(self):
        p = self.crear_producto(costo=1000, precio=1300, stock=0)
        productos.actualizar(p["id"], {"margen": 30}, self.admin)
        compras.registrar(
            {"items": [{"producto_id": p["id"], "cantidad": 5, "costo_unit": 2000}]},
            self.admin)
        actualizado = productos.obtener(p["id"])
        self.assertEqual(actualizado["costo_pesos"], 2000.0)
        self.assertEqual(actualizado["precio_pesos"], 2600.0)
        hist = precios.historial(p["id"])
        self.assertTrue(any(h["tipo"] == "costo" and h["valor_nuevo"] == 200000
                            for h in hist))

    def test_compra_invalida_no_deja_rastro(self):
        p = self.crear_producto(stock=0)
        with self.assertRaises(ErrorNegocio):
            compras.registrar({"items": [
                {"producto_id": p["id"], "cantidad": 5, "costo_unit": 100},
                {"producto_id": 9999, "cantidad": 1, "costo_unit": 100}]}, self.admin)
        self.assertEqual(productos.obtener(p["id"])["stock"], 0)
        self.assertEqual(compras.listar(), [])


class TestVentas(BaseTest):
    def test_venta_descuenta_stock_y_calcula_total(self):
        p = self.crear_producto(stock=10, costo=1000, precio=1500)
        fp = ventas.formas_pago()[0]
        v = ventas.registrar({"items": [{"codigo": "7790000000001", "cantidad": 3}],
                              "forma_pago_id": fp["id"]}, self.admin)
        self.assertEqual(v["total_pesos"], 4500.0)
        self.assertEqual(v["ganancia_pesos"], 1500.0)
        self.assertEqual(productos.obtener(p["id"])["stock"], 7)

    def test_venta_sin_stock_suficiente_se_revierte_completa(self):
        p1 = self.crear_producto(stock=5)
        p2 = self.crear_producto(codigo_barras="222", nombre="Fideos", stock=1,
                                 costo=500, precio=800)
        with self.assertRaises(ErrorNegocio) as ctx:
            ventas.registrar({"items": [
                {"producto_id": p1["id"], "cantidad": 2},
                {"producto_id": p2["id"], "cantidad": 5}]}, self.admin)
        self.assertIn("Stock insuficiente", str(ctx.exception))
        # NADA debe haber cambiado
        self.assertEqual(productos.obtener(p1["id"])["stock"], 5)
        self.assertEqual(productos.obtener(p2["id"])["stock"], 1)
        self.assertEqual(ventas.listar(), [])

    def test_stock_nunca_queda_negativo_con_ventas_concurrentes(self):
        p = self.crear_producto(stock=10, costo=100, precio=200)
        errores, exitos = [], []

        def vender():
            try:
                db.set_db_path(db.get_db_path())  # conexion propia del hilo
                ventas.registrar({"items": [{"producto_id": p["id"], "cantidad": 1}]},
                                 self.admin)
                exitos.append(1)
            except Exception as e:
                errores.append(e)

        hilos = [threading.Thread(target=vender) for _ in range(15)]
        for h in hilos:
            h.start()
        for h in hilos:
            h.join()
        final = productos.obtener(p["id"])["stock"]
        self.assertGreaterEqual(final, 0)
        self.assertEqual(final, 10 - len(exitos))

    def test_anulacion_devuelve_stock(self):
        p = self.crear_producto(stock=10)
        v = ventas.registrar({"items": [{"producto_id": p["id"], "cantidad": 4}]},
                             self.admin)
        self.assertEqual(productos.obtener(p["id"])["stock"], 6)
        ventas.anular(v["id"], "prueba", self.admin)
        self.assertEqual(productos.obtener(p["id"])["stock"], 10)
        self.assertEqual(ventas.obtener(v["id"])["estado"], "anulada")

    def test_producto_sin_precio_no_se_vende(self):
        p = self.crear_producto(precio=0, costo=0, stock=5)
        with self.assertRaises(ErrorNegocio):
            ventas.registrar({"items": [{"producto_id": p["id"], "cantidad": 1}]},
                             self.admin)

    def test_iva_incluido_se_discrimina(self):
        self.crear_producto(stock=5, costo=1000, precio=1210, iva=21)
        v = ventas.registrar({"items": [{"codigo": "7790000000001", "cantidad": 1}]},
                             self.admin)
        self.assertEqual(v["total_pesos"], 1210.0)
        self.assertAlmostEqual(v["impuestos_pesos"], 210.0, places=1)


class TestPrecios(BaseTest):
    def test_preview_no_modifica_nada(self):
        p = self.crear_producto(costo=1000, precio=2000)
        vista = precios.previsualizar(10, "ambos", "todos")
        self.assertEqual(vista["productos"][0]["precio_nuevo"], 2200.0)
        self.assertEqual(productos.obtener(p["id"])["precio_pesos"], 2000.0)

    def test_aplicar_aumento_guarda_historial(self):
        p = self.crear_producto(costo=1000, precio=2000)
        res = precios.aplicar(10, "ambos", "todos", "Aumento general", self.admin)
        self.assertEqual(res["actualizados"], 1)
        actualizado = productos.obtener(p["id"])
        self.assertEqual(actualizado["precio_pesos"], 2200.0)
        self.assertEqual(actualizado["costo_pesos"], 1100.0)
        hist = precios.historial(p["id"])
        self.assertEqual(len([h for h in hist if h["lote_id"] == res["lote_id"]]), 2)
        anterior = [h for h in hist if h["tipo"] == "venta"][0]
        self.assertEqual(anterior["valor_anterior_pesos"], 2000.0)

    def test_aumento_por_categoria_no_toca_otras(self):
        cat = productos.crear_categoria("Limpieza hogar", None, self.admin)
        a = self.crear_producto(categoria_id=cat["id"], precio=1000, costo=800)
        b = self.crear_producto(codigo_barras="333", nombre="Otro", precio=1000,
                                costo=800)
        precios.aplicar(20, "venta", "categoria", usuario=self.admin,
                        categoria_id=cat["id"])
        self.assertEqual(productos.obtener(a["id"])["precio_pesos"], 1200.0)
        self.assertEqual(productos.obtener(b["id"])["precio_pesos"], 1000.0)

    def test_aumento_de_costo_recalcula_venta_por_margen(self):
        p = self.crear_producto(costo=1000, precio=1300, margen=30)
        precios.aplicar(10, "costo", "todos", usuario=self.admin)
        actualizado = productos.obtener(p["id"])
        self.assertEqual(actualizado["costo_pesos"], 1100.0)
        self.assertEqual(actualizado["precio_pesos"], 1430.0)

    def test_historial_nunca_se_sobrescribe(self):
        p = self.crear_producto(costo=1000, precio=2000)
        precios.aplicar(10, "venta", "todos", usuario=self.admin)
        precios.aplicar(10, "venta", "todos", usuario=self.admin)
        hist = [h for h in precios.historial(p["id"]) if h["tipo"] == "venta"]
        self.assertEqual(len(hist), 3)  # alta + 2 aumentos

    def test_redondeo_configurable(self):
        config.guardar({"precios.redondeo": "10"})
        # $1000 + 33,5% = $1335 -> se redondea al proximo multiplo de $10
        self.assertEqual(precios.precio_desde_costo(100000, 33.5), 134000)
        config.guardar({"precios.redondeo": "0"})
        self.assertEqual(precios.precio_desde_costo(100000, 33.5), 133500)


class TestStock(BaseTest):
    def test_ajuste_manual_registra_usuario_y_motivo(self):
        p = self.crear_producto(stock=10)
        stock.ajustar(p["id"], cantidad_final=7, motivo="Rotura", usuario=self.admin)
        self.assertEqual(productos.obtener(p["id"])["stock"], 7)
        mov = stock.movimientos(p["id"])[0]
        self.assertEqual(mov["tipo"], "ajuste")
        self.assertEqual(mov["motivo"], "Rotura")
        self.assertEqual(mov["usuario"], "admin")

    def test_ajuste_no_puede_dejar_stock_negativo(self):
        p = self.crear_producto(stock=2)
        with self.assertRaises(ErrorNegocio):
            stock.ajustar(p["id"], delta=-5, motivo="error", usuario=self.admin)
        self.assertEqual(productos.obtener(p["id"])["stock"], 2)

    def test_devolucion_suma_stock(self):
        p = self.crear_producto(stock=1)
        stock.devolucion(p["id"], 2, "cliente devolvio", self.admin)
        self.assertEqual(productos.obtener(p["id"])["stock"], 3)

    def test_alertas_detectan_stock_bajo_y_sin_precio(self):
        self.crear_producto(stock=1, stock_minimo=5)
        self.crear_producto(codigo_barras="444", nombre="Sin precio", costo=0,
                            precio=0, stock=3)
        tipos = {a["tipo"] for a in stock.alertas()}
        self.assertIn("stock_bajo", tipos)
        self.assertIn("sin_precio", tipos)


class TestUsuariosPermisos(BaseTest):
    def test_login_y_password_incorrecta(self):
        self.assertIn("token", security.login("admin", "admin1234"))
        with self.assertRaises(ErrorNegocio):
            security.login("admin", "mala")

    def test_vendedor_no_puede_cambiar_precios(self):
        security.crear_usuario("juan", "Juan", "1234", "Vendedor")
        u = security.login("juan", "1234")["usuario"]
        security.exigir(u, "venta.crear")          # puede vender
        with self.assertRaises(ErrorNegocio) as ctx:
            security.exigir(u, "precio.editar")
        self.assertEqual(ctx.exception.codigo, 403)

    def test_sesion_invalida(self):
        self.assertIsNone(security.usuario_de_token("token-falso"))


class TestExcel(BaseTest):
    def test_exporta_xlsx_valido(self):
        p = self.crear_producto(stock=10)
        ventas.registrar({"items": [{"producto_id": p["id"], "cantidad": 2}]},
                         self.admin)
        compras.registrar({"items": [{"producto_id": p["id"], "cantidad": 5,
                                      "costo_unit": 1500}]}, self.admin)
        nombre, datos = reportes.exportar_excel(
            ["resumen", "stock", "ventas", "compras", "movimientos", "precios"],
            "mes")
        self.assertTrue(nombre.endswith(".xlsx"))
        with zipfile.ZipFile(BytesIO(datos)) as z:
            self.assertIsNone(z.testzip())
            nombres = z.namelist()
            self.assertIn("xl/workbook.xml", nombres)
            self.assertIn("xl/worksheets/sheet2.xml", nombres)
            hoja = z.read("xl/worksheets/sheet2.xml").decode()
            self.assertIn("Gaseosa", hoja)


class TestFacturacion(BaseTest):
    def test_ticket_interno_genera_comprobante(self):
        p = self.crear_producto(stock=5)
        v = ventas.registrar({"items": [{"producto_id": p["id"], "cantidad": 1}]},
                             self.admin)
        comp = facturacion.emitir(v["id"], "TICKET", self.admin)
        self.assertEqual(comp["estado"], "emitido")
        self.assertIn("Almacen de Prueba", Path(comp["archivo"]).read_text())

    def test_adaptador_fiscal_no_implementado_avisa_claro(self):
        config.guardar({"factura.adaptador": "fiscal_externo"})
        p = self.crear_producto(stock=5)
        v = ventas.registrar({"items": [{"producto_id": p["id"], "cantidad": 1}]},
                             self.admin)
        with self.assertRaises(ErrorNegocio) as ctx:
            facturacion.emitir(v["id"], usuario=self.admin)
        self.assertEqual(ctx.exception.codigo, 501)


class TestBackup(BaseTest):
    def test_backup_y_restauracion(self):
        p = self.crear_producto(stock=10)
        copia = backup.crear("prueba", self.admin)
        self.assertTrue(Path(copia["archivo"]).exists())
        stock.ajustar(p["id"], cantidad_final=1, motivo="cambio", usuario=self.admin)
        self.assertEqual(productos.obtener(p["id"])["stock"], 1)
        backup.restaurar(copia["nombre"], self.admin)
        self.assertEqual(productos.obtener(p["id"])["stock"], 10)


class TestConfiguracion(BaseTest):
    def test_nombre_del_negocio_se_guarda_en_base(self):
        config.guardar({"negocio.nombre": "Almacen Don Jose",
                        "negocio.cuit": "20-12345678-9"}, self.admin)
        self.assertEqual(config.obtener("negocio.nombre"), "Almacen Don Jose")
        db.cerrar()
        self.assertEqual(config.obtener("negocio.cuit"), "20-12345678-9")


class TestCaja(BaseTest):
    def test_abrir_cerrar_con_ventas(self):
        p = self.crear_producto(stock=10, costo=1000, precio=1500)
        caja.abrir(5000, self.admin)
        v = ventas.registrar(
            {"items": [{"producto_id": p["id"], "cantidad": 2}]}, self.admin)
        self.assertIsNotNone(v["caja_id"])
        est = caja.estado()
        self.assertTrue(est["abierta"])
        self.assertEqual(est["ventas"]["cantidad"], 1)
        self.assertEqual(est["caja"]["ventas_total_pesos"], v["total_pesos"])
        res = caja.cerrar(8000, "cierre de prueba", self.admin)  # 5000 + 3000
        self.assertEqual(res["diferencia_pesos"], 0.0)
        self.assertEqual(res["observaciones"], "cierre de prueba")
        self.assertFalse(caja.estado()["abierta"])

    def test_no_se_puede_abrir_dos_veces(self):
        caja.abrir(0, self.admin)
        with self.assertRaises(ErrorNegocio):
            caja.abrir(100, self.admin)
        caja.cerrar(0, "", self.admin)
        with self.assertRaises(ErrorNegocio):
            caja.cerrar(0, "", self.admin)

    def test_exigir_caja_abierta_bloquea_venta(self):
        config.guardar({"ventas.exigir_caja_abierta": "1"})
        p = self.crear_producto(stock=5)
        with self.assertRaises(ErrorNegocio) as ctx:
            ventas.registrar({"items": [{"producto_id": p["id"], "cantidad": 1}]},
                             self.admin)
        self.assertIn("caja", str(ctx.exception).lower())
        caja.abrir(0, self.admin)
        ventas.registrar({"items": [{"producto_id": p["id"], "cantidad": 1}]},
                         self.admin)
        self.assertEqual(ventas.listar()[0]["caja_id"] is not None, True)


class TestDescuentos(BaseTest):
    def test_descuento_porcentual_y_maximo(self):
        p = self.crear_producto(stock=10, costo=1000, precio=10000)
        config.guardar({"ventas.descuento_maximo": "10"})
        v = ventas.registrar(
            {"items": [{"producto_id": p["id"], "cantidad": 2}],
             "descuento_pct": 10}, self.admin)
        self.assertEqual(v["descuento_pct"], 10)
        self.assertEqual(v["descuento_pesos"], 2000.0)
        self.assertEqual(v["total_pesos"], 18000.0)
        with self.assertRaises(ErrorNegocio) as ctx:
            ventas.registrar(
                {"items": [{"producto_id": p["id"], "cantidad": 1}],
                 "descuento_pct": 15}, self.admin)
        self.assertIn("maximo", str(ctx.exception).lower())

    def test_descuento_negativo_no_se_acepta(self):
        p = self.crear_producto(stock=5)
        with self.assertRaises(ErrorNegocio):
            ventas.registrar(
                {"items": [{"producto_id": p["id"], "cantidad": 1}],
                 "descuento_pct": -5}, self.admin)

    def test_vendedor_no_puede_descontar(self):
        security.crear_usuario("ana", "Ana", "1234", "Vendedor")
        vendedor = security.login("ana", "1234")["usuario"]
        p = self.crear_producto(stock=5)
        with self.assertRaises(ErrorNegocio) as ctx:
            ventas.registrar(
                {"items": [{"producto_id": p["id"], "cantidad": 1}],
                 "descuento_pct": 5}, vendedor)
        self.assertIn("permiso", str(ctx.exception).lower())
        # sin descuento, la venta del vendedor es normal
        ventas.registrar({"items": [{"producto_id": p["id"], "cantidad": 1}]},
                         vendedor)
        self.assertEqual(ventas.listar()[0]["descuento"], 0)


class TestImagenProducto(BaseTest):
    def test_guardar_y_quitar_imagen(self):
        p = self.crear_producto()
        dato = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUg=="
        guardado = productos.guardar_imagen(p["id"], dato, self.admin)
        self.assertEqual(guardado["imagen"], dato)
        sin_img = productos.guardar_imagen(p["id"], None, self.admin)
        self.assertIsNone(sin_img["imagen"])

    def test_imagen_invalida_se_rechaza(self):
        p = self.crear_producto()
        with self.assertRaises(ErrorNegocio):
            productos.guardar_imagen(p["id"], "no-es-una-imagen", self.admin)


class TestAPI(BaseTest):
    """Prueba el servidor HTTP de punta a punta."""

    def setUp(self):
        super().setUp()
        from app import server
        self.httpd = server.crear_servidor("127.0.0.1", 0)
        self.puerto = self.httpd.server_address[1]
        self.hilo = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.hilo.start()
        self.token = self.pedir("POST", "/api/login",
                                {"usuario": "admin", "password": "admin1234"})["token"]

    def tearDown(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        self.hilo.join(timeout=5)
        super().tearDown()

    def pedir(self, metodo, ruta, cuerpo=None, token=None):
        url = f"http://127.0.0.1:{self.puerto}{ruta}"
        datos = json.dumps(cuerpo).encode() if cuerpo is not None else None
        req = urllib.request.Request(url, data=datos, method=metodo)
        req.add_header("Content-Type", "application/json")
        if token:
            req.add_header("Authorization", f"Bearer {token}")
        with urllib.request.urlopen(req) as r:
            return json.loads(r.read().decode())

    def test_api_requiere_token(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.pedir("GET", "/api/productos")
        self.assertEqual(ctx.exception.code, 401)

    def test_flujo_completo_por_api(self):
        prod = self.pedir("POST", "/api/productos",
                          {"codigo_barras": "7791111111111", "nombre": "Yerba 1kg",
                           "costo": 3200, "precio": 4500, "stock": 0,
                           "stock_minimo": 5}, self.token)
        self.pedir("POST", "/api/compras",
                   {"items": [{"codigo": "7791111111111", "cantidad": 30,
                               "costo_unit": 3200}]}, self.token)
        buscado = self.pedir("GET", "/api/productos/codigo?codigo=7791111111111",
                             token=self.token)
        self.assertEqual(buscado["stock"], 30)
        venta = self.pedir("POST", "/api/ventas",
                           {"items": [{"codigo": "7791111111111", "cantidad": 2}]},
                           self.token)
        self.assertEqual(venta["total_pesos"], 9000.0)
        ficha = self.pedir("GET", f"/api/productos/{prod['id']}", token=self.token)
        self.assertEqual(ficha["stock"], 28)
        tablero = self.pedir("GET", "/api/dashboard", token=self.token)
        self.assertEqual(tablero["hoy"]["cantidad"], 1)

    def test_descarga_excel_por_http(self):
        url = (f"http://127.0.0.1:{self.puerto}/api/reportes/excel"
               f"?tipos=stock&periodo=mes&token={self.token}")
        with urllib.request.urlopen(url) as r:
            contenido = r.read()
            self.assertTrue(r.headers["Content-Disposition"].endswith('.xlsx"'))
        self.assertEqual(contenido[:2], b"PK")


if __name__ == "__main__":
    unittest.main(verbosity=2)
