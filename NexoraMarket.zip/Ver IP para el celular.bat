@echo off
title Minimercado - direccion para el celular
cd /d "%~dp0"
echo.
echo   ============================================================
echo     Direccion para entrar desde el celular
echo     (el servidor debe estar ya iniciado en esta PC)
echo   ============================================================
echo.
ipconfig | findstr "IPv4"
echo.
echo   En el celular abra:  http://IP-DE-ARRIBA:8080
echo.
echo   Para instalarlo como app en Android:
echo     Chrome -menu-^> "Agregar a pantalla de inicio" (o "Instalar app").
echo   Para instalarlo en el iPhone:
echo     Safari -compartir-^> "Agregar a pantalla de inicio".
echo.
pause