@echo off
title Minimercado - Sistema de gestion
cd /d "%~dp0"
setlocal

if exist "%~dp0Minimercado.exe" goto exe

set "PY_EXE="
where python >nul 2>nul && set "PY_EXE=python"
if not defined PY_EXE (
  if exist "%LocalAppData%\Programs\Python\Python313\python.exe" (
    set "PY_EXE=%LocalAppData%\Programs\Python\Python313\python.exe"
  )
)
if not defined PY_EXE (
  echo.
  echo   No se encontro Python. Instalalo desde https://www.python.org/downloads/
  echo   (marcar "Add python.exe to PATH") y abra de nuevo este archivo.
  echo.
  pause
  exit /b 1
)

echo.
echo   ============================================================
echo      MINIMERCADO - Sistema de gestion
echo      (no cierre esta ventana mientras este usando el sistema)
echo   ============================================================
echo.

if not exist "datos\minimarket.db" (
  echo   Primera vez: se crea la base con el usuario admin / admin1234...
  "%PY_EXE%" run.py iniciar-base --usuario admin --password admin1234
  if errorlevel 1 (
    echo.
    echo   No se pudo crear la base. Revise el mensaje anterior.
    echo.
    pause
    exit /b 1
  )
)

echo   Levantando el sistema en la red local (PC y celulares)...
echo   Se abre el navegador en unos segundos.
echo.
echo   Para usar desde el CELULAR: conectelo a la misma red Wi-Fi
echo   que esta PC y abra la IP que aparece abajo agregandole ":8080"
echo.
ipconfig | findstr "IPv4"
echo.
echo   Ejemplo: si la IP es 192.168.1.20, en el celular abra
echo            http://192.168.1.20:8080
echo.

start "" "http://localhost:8080"
"%PY_EXE%" run.py servidor --red
goto fin

:exe
echo.
echo   ============================================================
echo      MINIMERCADO - Sistema de gestion (version instalada)
echo      (no cierre esta ventana mientras este usando el sistema)
echo   ============================================================
echo.
echo   Levantando el sistema en la red local (PC y celulares)...
echo   Se abre el navegador en unos segundos.
echo.
echo   Para usar desde el CELULAR: conectelo a la misma red Wi-Fi
echo   que esta PC y abra la IP que aparece abajo agregandole ":8080"
echo.
ipconfig | findstr "IPv4"
echo.
echo   Ejemplo: si la IP es 192.168.1.20, en el celular abra
echo            http://192.168.1.20:8080
echo.

start "" "http://localhost:8080"
start "" /wait "%~dp0Minimercado.exe"

:fin
echo.
echo   El sistema se detuvo. Para apagar, cierre esta ventana.
echo.
pause